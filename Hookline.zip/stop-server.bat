@echo off
title Hookline: stop server
powershell -NoProfile -Command "$c = Get-NetTCPConnection -LocalPort 3000 -State Listen -ErrorAction SilentlyContinue; if ($c) { Stop-Process -Id $c[0].OwningProcess -Force; Write-Host 'Hookline server stopped.' } else { Write-Host 'Hookline server was not running.' }"
pause
