![Hookline: spot the hook before you bite](assets/hookline-social.png)

# Hookline by Studidevelops

Hookline helps people spot scam texts, emails, and phone calls. It has a scam detector, a scam-awareness library, a spot-the-scam quiz, a feed of narrated shorts, a community board, and a map of scam reports by area.

This folder holds the **self-hosted version**, with its own account system: people create a username and password, and their progress, posts, and reports are saved on the Hookline server.

## Start it

1. Double-click **`start.bat`**.
2. Your browser opens **http://localhost:3000**. Keep the black server window open while you use Hookline.
3. To stop the server, close that window or press `Ctrl+C` in it.

Or, from a terminal in this folder: `npm start`

You need Node.js 22.5 or newer (https://nodejs.org). No other installs are required.

## Install it as an app

Hookline is a Progressive Web App, so it installs like a regular app with its own window and icon.

- **On this computer:** with Hookline open at `http://localhost:3000` in Edge or Chrome, click **Install app** in the top bar (or the install icon in the address bar). Hookline then shows up in your Start menu and can be pinned to the taskbar.
- **Have it always ready:** double-click **`autostart-on.bat`** once. The server then runs quietly in the background whenever you sign in to Windows, so the app opens without `start.bat`. Undo it with **`autostart-off.bat`**, and stop the background server anytime with **`stop-server.bat`**.
- **On phones:** once Hookline is hosted online with HTTPS, open it in Chrome (Android) and tap **Install app**, or in Safari (iPhone) tap **Share → Add to Home Screen**.
- The installed app still opens when you're offline. The detector, articles, quiz, and shorts keep working; accounts and the community need the server.

## Good to know

- **The first account created is the moderator.** It can remove anyone's posts, replies, and reports. Create your own account first.
- **Passwords are never stored as plain text.** They're scrambled with scrypt, so nobody, including you, can read them from the database.
- **All data lives in `data/hookline.db`.** Back it up to keep accounts and posts. Never share it or upload it anywhere.
- **Voice works here.** The microphone button and Live call mode work in Chrome or Edge at `http://localhost:3000`.
- **AI features are hidden** in this version (deep scan, AI articles, AI quiz, AI answers), since they need Claude.
- **Opening `public/index.html` directly won't work.** Accounts and the community need the server running. Always use `start.bat`.

## Letting other people use it

Right now Hookline only runs on your computer. For others to use it from their own devices, it has to be hosted on a service that runs Node.js. When you get there:

- Pick a host with a **persistent disk** (some free tiers erase files on every restart, which would delete every account).
- Set `DATA_DIR` to a folder on that persistent disk, and the host's `PORT` if it gives you one.
- Make sure the site uses **HTTPS**, which most hosts handle for you.
- If classmates or other students will make accounts, **check with a teacher or DCS IT first**, especially if any users are under 13.

## What's in this folder

| Path | What it is |
| --- | --- |
| `start.bat` | Double-click to run Hookline |
| `autostart-on.bat` / `autostart-off.bat` | Start (or stop starting) the server in the background with Windows |
| `stop-server.bat` | Stop a server running in the background |
| `tools/` | Helper scripts used by the autostart files |
| `server.js` | Accounts, saved progress, community board, and scam reports |
| `public/` | The app itself (page, design, content, code, app manifest, service worker, and icons) |
| `assets/` | Logo images: square icon and the GitHub social preview banner |
| `data/` | Created on first run; holds the database (keep private) |
| `claude-version/` | The version that runs on Claude at the original link |
