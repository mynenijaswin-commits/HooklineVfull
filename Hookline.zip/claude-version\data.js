/* Hookline content: articles, alerts, quiz bank, shorts, examples */
window.HL_DATA = (() => {

const states = [
  ['AL','Alabama',7,6],['AK','Alaska',0,0],['AZ','Arizona',2,5],['AR','Arkansas',5,5],['CA','California',1,4],
  ['CO','Colorado',3,4],['CT','Connecticut',10,3],['DE','Delaware',10,4],['DC','District of Columbia',9,5],['FL','Florida',9,7],
  ['GA','Georgia',8,6],['HI','Hawaii',0,7],['ID','Idaho',2,2],['IL','Illinois',6,2],['IN','Indiana',6,3],
  ['IA','Iowa',5,3],['KS','Kansas',4,5],['KY','Kentucky',6,4],['LA','Louisiana',5,6],['ME','Maine',11,0],
  ['MD','Maryland',9,4],['MA','Massachusetts',11,2],['MI','Michigan',8,2],['MN','Minnesota',5,2],['MS','Mississippi',6,6],
  ['MO','Missouri',5,4],['MT','Montana',3,2],['NE','Nebraska',4,4],['NV','Nevada',2,3],['NH','New Hampshire',11,1],
  ['NJ','New Jersey',9,3],['NM','New Mexico',3,5],['NY','New York',9,2],['NC','North Carolina',7,5],['ND','North Dakota',4,2],
  ['OH','Ohio',7,3],['OK','Oklahoma',4,6],['OR','Oregon',1,3],['PA','Pennsylvania',8,3],['RI','Rhode Island',10,2],
  ['SC','South Carolina',8,5],['SD','South Dakota',4,3],['TN','Tennessee',6,5],['TX','Texas',4,7],['UT','Utah',2,4],
  ['VT','Vermont',10,1],['VA','Virginia',8,4],['WA','Washington',1,2],['WV','West Virginia',7,4],['WI','Wisconsin',7,2],
  ['WY','Wyoming',3,3]
].map(([code, name, x, y]) => ({ code, name, x, y }));

const scamTypes = [
  'Toll or ticket text', 'Package delivery', 'Bank or card alert', 'Government impostor', 'Tech support',
  'Family emergency / voice clone', 'Job or task scam', 'Investment / crypto', 'Romance', 'Prize or sweepstakes',
  'Online shopping', 'Utility shutoff', 'Phishing email', 'Other'
];

const interests = [
  { id: 'texts', label: 'Scam texts' },
  { id: 'calls', label: 'Phone calls' },
  { id: 'email', label: 'Email & phishing' },
  { id: 'family', label: 'Protecting family' },
  { id: 'money', label: 'Money & crypto' },
  { id: 'jobs', label: 'Jobs & shopping' },
  { id: 'romance', label: 'Romance & social' },
  { id: 'tech', label: 'Tech support' },
  { id: 'teens', label: 'Teens online' }
];

const forumCats = [
  { id: 'calls', label: 'Phone calls' },
  { id: 'texts', label: 'Texts' },
  { id: 'email', label: 'Email' },
  { id: 'shopping', label: 'Shopping & jobs' },
  { id: 'money', label: 'Money & crypto' },
  { id: 'help', label: 'I got scammed' },
  { id: 'general', label: 'General' }
];

const alerts = [
  { date: 'Mar 2025', src: 'FTC', tag: 'Nationwide',
    title: 'Reported fraud losses reach $12.5 billion',
    body: 'People told the Federal Trade Commission they lost more than $12.5 billion to fraud in 2024, about 25% more than the year before. Investment scams caused the largest losses, followed by impostor scams.',
    url: 'https://consumer.ftc.gov/consumer-alerts' },
  { date: 'Apr 2025', src: 'FBI IC3', tag: 'Nationwide',
    title: 'Internet crime losses top $16 billion',
    body: 'The FBI’s Internet Crime Complaint Center reported $16.6 billion in losses for 2024. People over 60 reported the most losses of any age group, close to $4.9 billion.',
    url: 'https://www.ic3.gov/PSA' },
  { date: '2024–2025', src: 'FBI IC3', tag: 'Texts',
    title: 'Unpaid toll texts keep spreading',
    body: 'Texts claiming you owe a few dollars in tolls, with a link to pay, have hit drivers in nearly every state. Toll agencies say to check your balance only in their official app or website.',
    url: 'https://www.ic3.gov/PSA' },
  { date: '2025', src: 'State DMVs', tag: 'Texts',
    title: 'Fake DMV and traffic ticket texts',
    body: 'Many state motor vehicle agencies warned about texts threatening license suspension over unpaid tickets. DMVs don’t demand payment by text link.',
    url: 'https://consumer.ftc.gov/consumer-alerts' },
  { date: 'May 2025', src: 'FBI', tag: 'Calls',
    title: 'AI voice messages impersonating officials',
    body: 'The FBI warned that criminals were sending texts and AI-generated voice messages pretending to be senior government officials to build trust and steal account access.',
    url: 'https://www.ic3.gov/PSA' },
  { date: '2024', src: 'FTC', tag: 'Jobs',
    title: 'Task-based job scams surged',
    body: 'The FTC reported a sharp rise in “task” job scams, where people are paid small amounts to rate products online and then told to deposit their own money, often crypto, to keep earning.',
    url: 'https://consumer.ftc.gov/consumer-alerts' }
];

const articles = [
{ id: 'anatomy-scam-text', cat: 'Texts', tags: ['texts'], mins: 4,
  title: 'The anatomy of a scam text',
  dek: 'Six tells that give away almost every smishing message.',
  body: `Scam texts (also called smishing) work because a text feels personal and urgent. Most of them are built from the same handful of parts. Once you can name the parts, the message stops working on you.

## 1. A reason to panic
An unpaid toll, a package that can't be delivered, a locked bank account, a suspicious charge. The story is designed to make you feel that something bad is already happening.

## 2. A deadline
"Within 24 hours." "Today only." "Final notice." Real organizations send reminders, but they rarely threaten you with a countdown in a text message.

## 3. A link you didn't ask for
Look at the actual web address. Scammers use lookalike domains such as **usps-redelivery.info** or **ezpass-toll.top**. The real sites are usps.com and the toll agency's own site. When in doubt, don't tap. Open the official app or type the address yourself.

## 4. A small amount of money
A $3.95 toll or a $1.99 redelivery fee feels too small to question. The real goal is your card number, which gets used for much bigger charges.

## 5. A sender that doesn't fit
Big companies usually send alerts from 5- or 6-digit short codes. A text "from your bank" that arrives from a random 10-digit number, an international number, or an email address deserves a second look.

## 6. A request for information
No legitimate company needs you to reply with a password, a PIN, your Social Security number, or a verification code.

> Forward scam texts to **7726** (it spells SPAM). Your carrier uses those reports to block future messages. Then delete the text.

## The 10-second check
- Did I expect this message?
- Is it pushing me to act right now?
- Does it want money, a code, or a click?

If the answer to any of these is yes, stop and verify through a channel you already trust.` },

{ id: 'toll-package', cat: 'Texts', tags: ['texts', 'money'], mins: 3,
  title: 'Toll and package texts: why they keep coming',
  dek: 'The two most common scam texts of recent years, and how to shut them down.',
  body: `If you drive or shop online, you've probably seen one of these: a text saying you owe a few dollars in unpaid tolls, or that a package is stuck because of an incomplete address. Federal agencies, including the FBI's Internet Crime Complaint Center, have repeatedly warned about both.

## Why they work
Almost everyone has used a toll road or is waiting on a package. Scammers send millions of messages knowing a fraction of people will be expecting exactly that.

## How the scam plays out
- You tap the link and land on a page that copies the real agency's logo and colors.
- You enter your name, address, and card number to pay a tiny fee.
- The scammers use or sell your card details, and sometimes ask for a "verification code" that lets them add your card to their own phone wallet.

## What the real ones look like
Toll agencies don't text payment links unless you signed up for alerts with them. The U.S. Postal Service says it won't text or email you about a delivery unless you requested updates with a tracking number, and those messages won't include a link. If you think you might owe a toll, sign in to your toll account directly or call the number on your statement.

## If you already paid
1. Call your card issuer using the number on the back of your card and dispute the charge.
2. Ask for a new card number.
3. Report it at ReportFraud.ftc.gov and forward the text to 7726.` },

{ id: 'voice-cloning', cat: 'Family', tags: ['family', 'calls'], mins: 4,
  title: 'AI voice cloning and the “grandparent” call',
  dek: 'It sounds exactly like someone you love. Here’s how to tell it isn’t.',
  body: `It sounds exactly like your grandson. He's crying, he's been in an accident, and he needs money for bail right now. Please don't tell Mom.

Family emergency scams are old, but AI has made them more convincing. A few seconds of audio from a social media video can be enough to imitate someone's voice.

## The pattern
- An urgent emergency: arrest, accident, hospital, stranded abroad.
- A handoff to a "lawyer" or "officer" who explains how to pay.
- Payment that's hard to reverse: cash, gift cards, wire transfers, payment apps, or crypto. Some scammers even send a courier to pick up cash.
- A plea for secrecy so you won't check with anyone.

## Your best defense: a family safe word
Pick a word or phrase that only your family knows and that wouldn't show up online. If someone calls claiming to be family and asking for money, ask for the safe word. A real family member will know it. A voice clone won't.

## If you get the call
1. Stay calm and don't commit to anything.
2. Hang up and call the person directly at the number you already have.
3. Call another relative to confirm.
4. Never send money while the caller is still on the line.

> Use the Family Shield tool on your Profile to generate a safe word in one tap.` },

{ id: 'government-impostors', cat: 'Calls', tags: ['calls'], mins: 3,
  title: 'IRS, Social Security, and jury duty impostors',
  dek: 'What real agencies do, what they never do, and how to hang up with confidence.',
  body: `Government impostors rely on fear: of arrest, of losing benefits, of being in trouble with the law. Here's what real agencies do and don't do.

## What real agencies don't do
- The IRS doesn't call, text, or email demanding immediate payment, and it never asks for payment by gift card, crypto, or wire transfer. It normally contacts you first by mail.
- The Social Security Administration won't threaten to arrest you or suspend your Social Security number.
- Courts don't call to say you'll be arrested for missing jury duty unless you pay right now over the phone.
- Medicare won't call out of the blue asking for your Medicare number to send a "new card."

## The tells
- Caller ID that shows a government agency. Caller ID can be faked.
- Badge numbers and official-sounding names, used to sound legitimate.
- Instructions to stay on the line, not tell anyone, or drive to a store to buy gift cards.

## What to do
Hang up. If you're worried it might be real, look up the agency's official number yourself (for example on irs.gov or ssa.gov) and call. Report impostors at ReportFraud.ftc.gov, and Social Security impostors at oig.ssa.gov.` },

{ id: 'tech-support', cat: 'Tech', tags: ['tech', 'calls'], mins: 4,
  title: 'Tech support pop-ups and remote access traps',
  dek: 'Microsoft isn’t calling you. Here’s what to do when a warning takes over your screen.',
  body: `A pop-up freezes your screen and flashes a warning: your computer is infected, call this number now. Or a caller says they're from Microsoft or Apple and they've detected a virus. Both are the opening move of a tech support scam.

## How it works
1. You call (or they call you) and a friendly "technician" asks you to install a remote access app such as AnyDesk or TeamViewer.
2. They "find" problems and charge you to fix them, or claim they accidentally refunded you too much and ask you to send the difference back.
3. While connected, they can see your screen, open your banking, and install software.

## Know this
- Microsoft and Apple don't make unsolicited calls about viruses.
- Real security warnings never tell you to call a phone number.
- A legitimate refund never requires you to send money back with gift cards or crypto.

## If a pop-up takes over your screen
Close the browser. On Windows, press Ctrl+Shift+Esc to open Task Manager and end the browser task. On a Mac, press Cmd+Option+Esc. Don't call the number.

## If you gave someone access
- Disconnect from the internet.
- Uninstall the remote access app and run a security scan.
- Change passwords from a different device, starting with email and banking.
- Call your bank if you signed in to an account while they were connected.` },

{ id: 'payment-red-flags', cat: 'Money', tags: ['money'], mins: 3,
  title: 'Gift cards, crypto, and wires: the payment test',
  dek: 'One question catches a huge share of scams: how do they want you to pay?',
  body: `Here's one rule that catches a huge share of scams: **pay attention to how someone wants you to pay.**

Scammers prefer payment methods that are fast, hard to trace, and nearly impossible to reverse. Legitimate businesses and government agencies have other options and don't insist on these.

## Big red flags
- **Gift cards.** No government agency or real business will demand payment in gift cards. If someone asks you to read the numbers off the back, it's a scam.
- **Cryptocurrency and Bitcoin ATMs.** Nobody legitimate will tell you to withdraw cash and feed it into a crypto ATM to "protect" your money.
- **Wire transfers and money transfer services.** Sending a wire is like sending cash.
- **Payment apps like Zelle, Venmo, and Cash App.** They're designed for friends and family. Once you send money, it's often gone.
- **Cash pickup.** A courier coming to your door to collect cash for a relative or an agency is a scam.

## Safer ways to pay
Credit cards offer the strongest protection for purchases because you can dispute charges. Pay businesses through their official website or app, never through a link someone sent you.

## If you already paid
Contact the company you used immediately (the gift card brand, your bank, the wire service, or the app) and ask them to stop or reverse the payment. Speed matters. Then report it at ReportFraud.ftc.gov.` },

{ id: 'pig-butchering', cat: 'Money', tags: ['money', 'texts', 'romance'], mins: 4,
  title: 'Wrong-number texts and investment scams',
  dek: 'The friendly stranger who texted by mistake may be running a months-long con.',
  body: `"Hi, is this Jason? It's Mia from the dinner last week." You reply to say they have the wrong number. They apologize, they're charming, and the conversation keeps going.

This is often the start of a long con sometimes called "pig butchering," where scammers build trust over weeks before introducing an investment. In FTC data, investment scams caused more reported losses than any other category in 2024.

## The stages
1. **Contact.** A wrong-number text, a dating app match, or a message on social media.
2. **Trust.** Daily chats, photos of a glamorous life, and lots of attention.
3. **The pitch.** They mention a crypto or trading platform that's made them rich and offer to teach you.
4. **Small wins.** A fake app shows your money growing. You may even be allowed to withdraw a little.
5. **The trap.** When you try to take out more, there are "taxes" or "fees" to pay first. The money never comes back.

## Protect yourself
- Don't reply to wrong-number texts. Just delete them.
- Be wary of anyone you've never met in person who brings up investing.
- Never move money into a platform someone you met online recommends.
- Beware of "recovery services" that promise to get your money back for a fee. That's often a second scam.` },

{ id: 'job-scams', cat: 'Jobs', tags: ['jobs', 'money'], mins: 4,
  title: 'Fake jobs, task scams, and the overpayment trick',
  dek: 'If a job pays you to send money back, it isn’t a job.',
  body: `Job scams target people who are actively looking for work, which makes them especially cruel. They often arrive by text, on job sites, or through messaging apps like Telegram and WhatsApp.

## Common versions
- **Task scams.** You're paid to "rate products" or "boost apps" on an online platform. Early tasks pay a little, then you're told to deposit your own money, often crypto, to unlock bigger tasks.
- **Fake checks.** A new "employer" mails you a check to buy equipment from their vendor. You deposit it, send money to the vendor, and the check bounces days later. You owe the bank.
- **Reshipping.** You receive packages and ship them elsewhere. You may be moving stolen goods.
- **Upfront fees.** You're asked to pay for training, background checks, or starter kits.

## Red flags
- You were offered a job you never applied for.
- The pay is high for easy work with no experience needed.
- The interview happens only by text or chat.
- They ask you to pay anything, deposit a check and send money back, or share bank login details.

## Before you accept
Search the company name plus "scam," look up the company's official careers page, and contact them through information you find yourself.` },

{ id: 'romance-scams', cat: 'Romance', tags: ['romance', 'money'], mins: 3,
  title: 'Romance scams: when love asks for money',
  dek: 'The relationship feels real. The emergencies never stop.',
  body: `Romance scammers create convincing profiles on dating apps and social media, then shower targets with attention. The relationship can feel completely real, and that's what makes it so painful.

## Warning signs
- They profess strong feelings very quickly.
- They can never video chat, or the camera is always "broken."
- They live far away: working on an oil rig, deployed overseas, or traveling for work.
- Plans to meet keep falling through at the last minute.
- Eventually there's an emergency, a medical bill, a customs fee, or a ticket to come see you, and they need money.

## Check it
- Run a reverse image search on their profile photos.
- Talk to a friend or family member you trust. Scammers often try to isolate their targets.
- Never send money, gift cards, or crypto to someone you haven't met in person.

## If it happened to you
It's not your fault. These are professional criminals. Stop contact, save your messages, report the profile to the app or site, and report it at ReportFraud.ftc.gov. If you sent money, contact your bank right away.` },

{ id: 'teens-online', cat: 'Teens', tags: ['teens', 'family'], mins: 4,
  title: 'Scams that target teens',
  dek: 'Free skins, impossible deals, and new “friends” who aren’t who they say.',
  body: `Teens are online constantly, and scammers know it. Some of the most common scams aimed at young people look like games, giveaways, or new friends.

## Gaming and giveaway scams
Offers of free in-game currency, skins, or gift cards often lead to fake login pages that steal your account. Only buy or claim items through the official game or store.

## Fake shopping deals
Sneakers, concert tickets, and electronics at impossible prices, sold through social media ads or DMs. Use trusted stores and avoid paying through payment apps or gift cards.

## Sextortion
The FBI has warned about a sharp rise in sextortion targeting teens, especially boys. A scammer pretends to be someone your age, builds trust, asks for photos, then threatens to share them unless you pay.

If this happens: **stop responding, don't pay, and tell a trusted adult.** It is not your fault, and you are not in trouble. Save the messages, block the account, and report it to the platform and to the FBI at tips.fbi.gov. The National Center for Missing & Exploited Children's free **Take It Down** service (takeitdown.ncmec.org) can help remove images.

## Quick rules
- Never share a login code with anyone, even a friend.
- If a deal or a new online friend seems too good to be true, ask someone you trust.` },

{ id: 'security-checklist', cat: 'Basics', tags: ['tech', 'family'], mins: 3,
  title: 'The 15-minute scam-proof setup',
  dek: 'A short checklist that makes you a much harder target.',
  body: `You don't need to be a tech expert to make yourself a much harder target. Set aside 15 minutes and work through this list.

## Accounts
- Turn on **two-step verification** for email, banking, and social media. An authenticator app or passkey is stronger than text messages.
- Use a **password manager** so every account has a unique password.
- Secure your email first. Whoever controls your email can reset everything else.

## Phone
- Turn on your carrier's free **spam call blocking** and your phone's "silence unknown callers" setting.
- Add a **PIN or passcode to your mobile account** with your carrier to help prevent SIM swaps.

## Money
- **Freeze your credit** with Equifax, Experian, and TransUnion. It's free and stops criminals from opening new accounts in your name. You can lift it any time you apply for credit.
- Set up **transaction alerts** with your bank and card issuers.

## Family
- Agree on a **family safe word** for emergencies.
- Talk to older relatives and teens about the scams in this app. Scammers count on silence and embarrassment.` },

{ id: 'first-hour', cat: 'Basics', tags: ['money', 'family'], mins: 3,
  title: 'Got scammed? What to do in the first hour',
  dek: 'Speed matters. Here’s the order to do things in.',
  body: `If you think you've been scammed, act quickly. Speed can make the difference between getting money back and losing it. And remember: it happens to smart, careful people every day.

## 1. Stop the bleeding
- Stop all contact with the scammer. Don't send any more money, even if they promise a refund.
- If they have remote access to your device, disconnect it from the internet.

## 2. Call your bank or payment company
Use the number on the back of your card or on the official website. Ask them to stop or reverse the payment and to watch your account. For gift cards, call the number on the card. For wires, contact the wire service right away.

## 3. Secure your accounts
Change passwords for any account you shared, starting with email and banking, and turn on two-step verification. If you gave out a code, assume that account is compromised.

## 4. Protect your identity
If you shared your Social Security number, go to IdentityTheft.gov for a recovery plan, and freeze your credit with all three bureaus.

## 5. Report it
- ReportFraud.ftc.gov for most scams
- ic3.gov for internet crime
- Your local police, if you lost money (some banks ask for a report)

> Watch out for "recovery" scams. Anyone who contacts you offering to get your money back for a fee is likely another scammer.

Use the **Got scammed?** button at the top of Hookline for a personalized checklist.` }
];

/* Quiz bank. [[text|why]] marks a red flag; [[+text|why]] marks a good sign. */
const quiz = [
{ ch: 'text', from: '+1 (209) 555-0182', scam: true, type: 'Toll text scam',
  msg: 'TOLL NOTICE: [[You have an unpaid toll balance of $4.15|A tiny amount makes you pay without thinking]]. [[Pay within 24 hours|An artificial deadline]] to avoid a [[$65 late fee|A threatened penalty]]: [[ezpass-paytoll.top/pay|Not an official toll site; the .top ending is a giveaway]]',
  why: 'Toll agencies don’t text payment links from random numbers. Check your balance in the official app instead.' },
{ ch: 'text', from: '72166', scam: false, type: 'Login code',
  msg: 'First Harbor Bank: Your sign-in code is 552918. It expires in 10 minutes. [[+We will never call or text asking for this code.|Real code texts warn you not to share them]]',
  why: 'A code you requested yourself, from a short code, with a warning not to share it. Just never read it to anyone who calls you.' },
{ ch: 'call', from: 'Caller ID: County Sheriff', scam: true, type: 'Government impostor',
  msg: 'This is Officer Daniels with the Sheriff’s Office. [[There is a warrant for your arrest|A frightening threat]] for missing jury duty. [[You can clear it today by paying the fine with gift cards|No court or police department takes gift cards]]. [[Do not hang up or talk to anyone|Isolating you so nobody can warn you]] until this is resolved.',
  why: 'Courts don’t call demanding payment, and caller ID can be faked. Gift cards plus a threat is always a scam.' },
{ ch: 'email', from: 'billing@netflix-accounts-support.com', subject: 'Your membership is on hold', scam: true, type: 'Phishing email',
  msg: '[[Dear Customer|A generic greeting]], we were unable to process your last payment. [[Update your payment details within 48 hours|A deadline]] or your account will be [[permanently closed|A threat]]. [[Update now: netflix-accounts-support.com/billing|A lookalike domain, not netflix.com]]',
  why: 'The sender’s domain isn’t the company’s real one. Open the app or type the site yourself to check your account.' },
{ ch: 'text', from: 'Coach Rivera', scam: false, type: 'Normal message',
  msg: 'Practice moved to 5:30 today because they’re painting the field lines. Bring water! [[+No links, money, or logins requested|Nothing is being asked of you]]',
  why: 'A saved contact sharing information with nothing to click, pay, or share.' },
{ ch: 'text', from: '+1 (305) 555-0199', scam: true, type: 'Wrong-number investment scam',
  msg: '[[Hi, is this Jessica?|The classic wrong-number opener]] It’s Amy from yoga class! [[Sorry, maybe wrong number. You seem nice though|Keeping a stranger talking]] 😊 What do you do for work?',
  why: 'Wrong-number texts that keep chatting are often the first step of a long investment scam. Don’t reply.' },
{ ch: 'email', from: 'alerts@northwindcu.org', subject: 'Was this you?', scam: false, type: 'Real fraud alert',
  msg: 'We noticed a $482.10 purchase on your card ending in 4471. If you don’t recognize it, [[+sign in to the Northwind app or call the number on the back of your card|Sends you to a channel you already trust]]. [[+We will never ask for your PIN or full card number.|Real banks say this]]',
  why: 'It doesn’t push a link or ask for details, and it points you to the app or the number on your card.' },
{ ch: 'text', from: '+44 7700 900123', scam: true, type: 'Prize scam',
  msg: '[[Congratulations!|An unexpected prize]] Your number was [[selected to receive a $1,000 store gift card|A contest you never entered]]. [[Claim in the next 30 minutes|A countdown]]: [[bit.ly/claim-1k-now|A shortened link hides where it goes]]',
  why: 'You can’t win a contest you didn’t enter. The international number and short link are extra red flags.' },
{ ch: 'call', from: 'Unknown caller', scam: true, type: 'Tech support scam',
  msg: 'Hi, this is the Microsoft security department. [[We detected a virus on your computer|Microsoft doesn’t call people about viruses]]. [[Please download AnyDesk|A remote access app gives them control]] so our technician can [[connect to your computer|They want inside your device]] and fix it right now.',
  why: 'Tech companies don’t cold-call you. Installing remote access hands a stranger your computer.' },
{ ch: 'text', from: 'Unknown (new number)', scam: true, type: 'Family emergency scam',
  msg: 'Grandma it’s Leo, [[I broke my phone so this is my new number|An excuse for the strange number]]. [[I got in a car accident and need $2,000 for bail|An emergency plus a money request]]. [[Please don’t tell Mom|Secrecy stops you from checking]]. Can you [[send it by Zelle|A payment that’s hard to reverse]]?',
  why: 'Call your grandson at his real number or check with family. A safe word stops this cold.' },
{ ch: 'text', from: '47392', scam: false, type: 'Pharmacy reminder',
  msg: 'Riverbend Pharmacy: Your prescription is ready for pickup at our Main St location. [[+Questions? Call the store.|No link or payment requested]] Reply STOP to opt out.',
  why: 'Informational, from a short code, and asks nothing of you.' },
{ ch: 'text', from: '+1 (480) 555-0136', scam: true, type: 'Package delivery scam',
  msg: 'USPS: [[Your package could not be delivered due to an incomplete address|Classic delivery bait]]. [[Update within 12 hours|A deadline]] or it will be returned: [[usps-redeliver.info/track|Not usps.com]]',
  why: 'USPS doesn’t text links unless you signed up with a tracking number. Track packages at usps.com yourself.' },
{ ch: 'email', from: 'hr.talentdesk@gmail.com', subject: 'Job offer: Remote Data Entry', scam: true, type: 'Job scam',
  msg: '[[We found your resume online|You never applied]] and would like to offer you a [[remote position paying $45/hr, no experience needed|Too good to be true]]. [[We will mail you a check to buy equipment from our approved vendor|The fake check trick]].',
  why: 'Real employers don’t hire without an interview or send checks for you to forward. The check will bounce.' },
{ ch: 'text', from: 'Lakeside High', scam: false, type: 'School alert',
  msg: 'Lakeside High: School will dismiss 2 hours early today due to weather. Buses will run on the early schedule. [[+Details are posted on the district website.|Points you to an official source without a link]]',
  why: 'An informational alert with no link, no money, and no personal info requested.' },
{ ch: 'call', from: 'Dr. Patel’s Office', scam: false, type: 'Appointment reminder',
  msg: 'Hi, this is Dana from Dr. Patel’s office confirming your appointment Thursday at 2:15. [[+Please call the office if you need to reschedule.|No payment or personal info requested]]',
  why: 'A simple reminder. If you’re unsure, call the office number you already have.' },
{ ch: 'text', from: '+1 (202) 555-0164', scam: true, type: 'Government impostor',
  msg: 'IRS: [[You are eligible for a tax refund of $1,284.50|The IRS doesn’t text you about refunds]]. [[Verify your identity|They want your personal info]] at [[irs-refund-gov.com|The real IRS site is irs.gov]]',
  why: 'The IRS contacts people by mail first and never texts refund links.' },
{ ch: 'text', from: '@crypto.mentor.amy', scam: true, type: 'Investment scam',
  msg: 'Hey! Saw your profile — I [[made $12,000 last month with this trading platform|Investment bait]]. My uncle is an analyst and it’s [[guaranteed returns|No real investment guarantees returns]]. [[I can teach you, just start with $500|A small first deposit to hook you]].',
  why: 'Strangers who bring up investing online are a top source of losses. Guaranteed returns don’t exist.' },
{ ch: 'email', from: 'no-reply@accounts.google.com', subject: 'Security alert: new sign-in', scam: false, type: 'Real security alert',
  msg: 'New sign-in on Windows. If this was you, you don’t need to do anything. If not, we’ll help you secure your account. [[+Check activity at myaccount.google.com|The official domain, which you can visit yourself]]',
  why: 'Real alerts don’t demand anything. Even so, it’s safest to open your account settings directly rather than through an email.' },
{ ch: 'text', from: '+1 (888) 555-0123', scam: true, type: 'Fake purchase scam',
  msg: 'Amazon: [[A $1,499 iPhone purchase was placed on your account|A scary charge you didn’t make]]. If this wasn’t you, [[call 1-888-555-0123 immediately|The number connects you to the scammer]].',
  why: 'Check your orders in the official app. The phone number in the text leads straight to the scammer.' },
{ ch: 'call', from: 'Caller ID: Electric Co.', scam: true, type: 'Utility shutoff scam',
  msg: 'This is your electric company. [[Your power will be shut off in 30 minutes|Extreme urgency]] for an overdue balance unless you [[pay with a prepaid card at a nearby store|Utilities don’t demand prepaid cards]].',
  why: 'Utilities send written notices and offer normal payment options. Hang up and call the number on your bill.' },
{ ch: 'text', from: 'Sam (friend)', scam: true, type: 'Code theft',
  msg: 'Hey, it’s Sam — [[can you send me the 6-digit code you just got? I sent it to your number by mistake|This code unlocks YOUR account]]',
  why: 'Your friend’s account may be hacked. That code lets someone take over your account. Never share it.' },
{ ch: 'text', from: 'Marketplace buyer', scam: true, type: 'Marketplace scam',
  msg: 'I’ll take the bike! [[Before I pay, I need to verify you’re real. I’m sending a code, just read it back to me|A verification code request]].',
  why: 'Buyers asking for a code are usually setting up an account in your name. Real buyers just pay.' },
{ ch: 'email', from: 'notices@riverbendlibrary.org', subject: 'Items due soon', scam: false, type: 'Library notice',
  msg: 'Your item "The Martian" is due on Oct 10. [[+You can renew online through your library account.|No link pressure or payment demand]]',
  why: 'A routine notice that asks for nothing.' },
{ ch: 'text', from: '24273', scam: false, type: 'Login code',
  msg: 'Your Northwind verification code is 840221. It expires in 10 minutes. [[+Never share this code with anyone, even if they say they’re from Northwind.|A warning not to share]]',
  why: 'If you just tried to sign in, this is expected. If you didn’t, ignore it and change your password.' }
];

/* Narrated vertical shorts, rendered in the app */
const shorts = [
{ id: 'toll-text', title: 'The $3.95 toll text', tags: ['texts', 'money'], hue: 24, yt: 'toll text scam shorts',
  scenes: [
    { k: 'hook', big: 'This text costs way more than $3.95.', say: 'This text says you owe three ninety five. It could cost you a lot more.' },
    { k: 'sms', from: '+1 (209) 555-0182', text: 'TOLL SERVICES: You have an unpaid toll of $3.95. Pay today to avoid a $50 late fee: ezpass-pay.top', say: 'An unpaid toll, a tiny amount, a late fee threat, and a strange link.' },
    { k: 'list', title: 'The tells', items: ['A tiny amount so you don’t think twice', 'A deadline of “today”', 'A link ending in .top'], say: 'A tiny amount. A same day deadline. And a link that is not the official site.' },
    { k: 'rule', pre: 'The rule', big: 'Never pay from a text link.', sub: 'Open the toll app or type the official site yourself.', say: 'Never pay from a text link. Open the official app instead.' },
    { k: 'end', say: 'Pause. Verify. Then act.' } ] },
{ id: 'grandma-call', title: '“Grandma, it’s me”', tags: ['family', 'calls'], hue: 340, yt: 'grandparent scam AI voice clone shorts',
  scenes: [
    { k: 'call', caller: 'Unknown', line: '“Grandma, it’s me. I’m in trouble and I need money for bail.”', say: 'Grandma, it is me. I am in trouble and I need money for bail.' },
    { k: 'hook', big: 'That voice might be a clone.', say: 'That voice might not be your grandson. AI can copy a voice from a few seconds of video.' },
    { k: 'list', title: 'Listen for', items: ['An emergency with a deadline', '“Don’t tell Mom”', 'Gift cards, wires, or cash pickup'], say: 'Listen for an emergency, a request for secrecy, and hard to trace payment.' },
    { k: 'rule', pre: 'Your defense', big: 'A family safe word.', sub: 'Ask for it. A clone won’t know it.', say: 'Set up a family safe word. Ask for it. A clone will not know it.' },
    { k: 'end', say: 'Hang up, and call them back on their real number.' } ] },
{ id: 'gift-cards', title: 'Gift cards are for gifts', tags: ['money', 'calls'], hue: 48, yt: 'gift card scam shorts',
  scenes: [
    { k: 'hook', big: 'Who wants payment in gift cards?', say: 'Who asks to be paid with gift cards?' },
    { k: 'stat', value: '0', label: 'government agencies that accept gift cards as payment', say: 'Zero government agencies. Zero real businesses.' },
    { k: 'list', title: 'If someone asks you to', items: ['Buy gift cards for a bill or fine', 'Read the numbers off the back', 'Keep it secret from the cashier'], say: 'If someone wants gift card numbers read over the phone, it is a scam. Every time.' },
    { k: 'rule', pre: 'The rule', big: 'Gift card payment = scam.', sub: 'Already sent? Call the card company now.', say: 'If you already sent them, call the gift card company right away.' },
    { k: 'end', say: 'Pause. Verify. Then act.' } ] },
{ id: 'six-digits', title: 'Never read a code out loud', tags: ['texts', 'tech'], hue: 200, yt: 'verification code scam shorts',
  scenes: [
    { k: 'sms', from: '24273', text: 'Your verification code is 840221. Never share this code.', say: 'You just got a verification code you did not ask for.' },
    { k: 'call', caller: '“Your bank”', line: '“To stop the fraud, read me the code we just sent.”', say: 'Then someone calls and asks you to read it to them.' },
    { k: 'hook', big: 'That code is the key to your account.', say: 'That code is the key to your account. They are logging in as you right now.' },
    { k: 'rule', pre: 'The rule', big: 'Codes are for typing, never telling.', sub: 'No real company will ask you to read one back.', say: 'Codes are for typing, never for telling.' },
    { k: 'end', say: 'Hang up and call the number on your card.' } ] },
{ id: 'wrong-number', title: 'The friendly wrong number', tags: ['texts', 'money', 'romance'], hue: 160, yt: 'wrong number text scam pig butchering shorts',
  scenes: [
    { k: 'sms', from: '+1 (305) 555-0199', text: 'Hi, is this Jessica? It’s Amy from yoga!', say: 'Hi, is this Jessica? A wrong number. Or is it?' },
    { k: 'hook', big: 'Replying starts a months-long con.', say: 'Replying can start a long con that ends with a fake investment.' },
    { k: 'list', title: 'How it goes', items: ['Weeks of friendly chat', 'A “sure thing” crypto app', 'Fake profits, then fees to withdraw'], say: 'Weeks of chatting, then a crypto app, then fake profits you can never withdraw.' },
    { k: 'rule', pre: 'The rule', big: 'Don’t reply. Delete.', sub: 'Report it by forwarding to 7726.', say: 'Do not reply. Delete it, or forward it to seven seven two six.' },
    { k: 'end', say: 'Pause. Verify. Then act.' } ] },
{ id: 'package-hold', title: 'Your package is “on hold”', tags: ['texts', 'jobs'], hue: 210, yt: 'USPS package text scam shorts',
  scenes: [
    { k: 'sms', from: '+1 (480) 555-0136', text: 'USPS: Your package is on hold due to an incomplete address. Update within 12 hours: usps-redeliver.info', say: 'Your package is on hold. Update your address within twelve hours.' },
    { k: 'list', title: 'Spot it', items: ['A random 10-digit sender', 'A 12-hour deadline', 'A site that isn’t usps.com'], say: 'A random number, a deadline, and a site that is not usps dot com.' },
    { k: 'rule', pre: 'The rule', big: 'Track it yourself.', sub: 'Paste the tracking number into the carrier’s real site.', say: 'Track packages yourself on the carrier’s real website.' },
    { k: 'end', say: 'Pause. Verify. Then act.' } ] },
{ id: 'tech-call', title: 'Microsoft isn’t calling', tags: ['tech', 'calls'], hue: 262, yt: 'tech support scam call shorts',
  scenes: [
    { k: 'call', caller: 'Windows Support', line: '“We detected a virus. Please install AnyDesk so we can fix it.”', say: 'We detected a virus on your computer. Please install this app so we can fix it.' },
    { k: 'hook', big: 'Remote access = handing over your keys.', say: 'Installing that app hands a stranger your computer, your email, and your bank.' },
    { k: 'list', title: 'Remember', items: ['Tech companies don’t cold-call', 'Real warnings never list a phone number', 'Refunds never need gift cards'], say: 'Tech companies do not cold call. Real warnings never ask you to call a number.' },
    { k: 'rule', pre: 'The rule', big: 'Hang up. Don’t install.', sub: 'Pop-up stuck? Close the browser.', say: 'Hang up. Do not install anything.' },
    { k: 'end', say: 'Pause. Verify. Then act.' } ] },
{ id: 'jury-duty', title: 'The jury duty warrant', tags: ['calls'], hue: 8, yt: 'jury duty scam call shorts',
  scenes: [
    { k: 'call', caller: 'Sheriff’s Office', line: '“You missed jury duty. There’s a warrant for your arrest.”', say: 'You missed jury duty. There is a warrant for your arrest.' },
    { k: 'hook', big: 'Fear is the whole strategy.', say: 'Fear is the whole strategy. It stops you from thinking.' },
    { k: 'list', title: 'Real courts', items: ['Send notices by mail', 'Never take gift cards or crypto', 'Never demand payment on the phone'], say: 'Real courts send mail. They never demand gift cards or payment over the phone.' },
    { k: 'rule', pre: 'The rule', big: 'Hang up. Call the court yourself.', sub: 'Find the number on the court’s official site.', say: 'Hang up and call the court using a number you look up yourself.' },
    { k: 'end', say: 'Pause. Verify. Then act.' } ] },
{ id: 'fake-job', title: 'The job that pays you to pay', tags: ['jobs', 'money', 'teens'], hue: 130, yt: 'fake job task scam shorts',
  scenes: [
    { k: 'sms', from: 'Recruiter Linda', text: 'Remote job! $300/day rating products. No experience needed. Reply YES.', say: 'Three hundred dollars a day rating products. No experience needed.' },
    { k: 'hook', big: 'Then they ask for a deposit.', say: 'Then they ask you to deposit your own money to unlock bigger tasks.' },
    { k: 'list', title: 'Job scam tells', items: ['You never applied', 'Pay that’s too good to be true', 'You pay them, or forward a check'], say: 'You never applied. The pay is too good. And somehow, you end up paying them.' },
    { k: 'rule', pre: 'The rule', big: 'Real jobs pay you. Period.', sub: 'Never deposit money to earn money.', say: 'Real jobs pay you. Never pay to get paid.' },
    { k: 'end', say: 'Pause. Verify. Then act.' } ] },
{ id: 'romance', title: 'When love asks for crypto', tags: ['romance', 'money'], hue: 320, yt: 'romance scam warning signs shorts',
  scenes: [
    { k: 'hook', big: 'They’re perfect. They’re far away. They need money.', say: 'They are perfect. They live far away. And now they need money.' },
    { k: 'list', title: 'Warning signs', items: ['Feelings that move very fast', 'Never available for video', 'An emergency only you can fix'], say: 'Fast feelings, no video calls, and an emergency only you can fix.' },
    { k: 'rule', pre: 'The rule', big: 'Never send money to someone you haven’t met.', sub: 'Reverse-search their photos.', say: 'Never send money to someone you have not met in person.' },
    { k: 'end', say: 'It is not your fault. Talk to someone you trust.' } ] },
{ id: 'qr-codes', title: 'The sticker on the parking meter', tags: ['tech', 'money'], hue: 186, yt: 'QR code parking scam shorts',
  scenes: [
    { k: 'hook', big: 'That QR code might be a sticker.', say: 'That QR code on the parking meter might be a sticker placed by a scammer.' },
    { k: 'list', title: 'Before you scan', items: ['Look for a sticker over the real code', 'Check the web address before paying', 'Use the city’s official parking app'], say: 'Look for stickers. Check the address. Use the official app.' },
    { k: 'rule', pre: 'The rule', big: 'Scan, then check the URL.', sub: 'If it’s not the official site, close it.', say: 'Scan, then check the web address before you pay anything.' },
    { k: 'end', say: 'Pause. Verify. Then act.' } ] },
{ id: 'first-hour', title: 'Scammed? The first hour', tags: ['money', 'family'], hue: 0, yt: 'what to do if you get scammed shorts',
  scenes: [
    { k: 'hook', big: 'You got scammed. Move fast.', say: 'If you got scammed, the first hour matters most.' },
    { k: 'list', title: 'Do this now', items: ['Call your bank or card company', 'Change passwords, email first', 'Report at ReportFraud.ftc.gov'], say: 'Call your bank. Change your passwords, starting with email. Report it to the FTC.' },
    { k: 'stat', value: '1 hr', label: 'the window where banks can most often stop a payment', say: 'The sooner you call, the better your chances of stopping the payment.' },
    { k: 'rule', pre: 'Watch out', big: '“Recovery” offers are scam #2.', sub: 'Nobody legit charges to get your money back.', say: 'Watch out for anyone offering to recover your money for a fee.' },
    { k: 'end', say: 'It happens to smart people. Act fast and tell someone.' } ] }
];

const examples = [
  { label: 'Unpaid toll text', mode: 'text', from: '+1 (209) 555-0182',
    text: 'TOLL SERVICES NOTICE: You have an unpaid toll balance of $3.95. To avoid a $50.00 late fee and license suspension, pay within 24 hours: https://ezpass-tollpay.top/pay' },
  { label: '“Grandson” emergency call', mode: 'call', from: '',
    text: 'Grandma, it’s me. I was in a car accident and I’m in jail. I need $2,000 for bail right away. Please don’t tell Mom. A lawyer will call you and tell you how to send it with gift cards.' },
  { label: 'Tech support call', mode: 'call', from: '',
    text: 'Hello, this is Microsoft technical department. We detected a virus on your computer and your bank account may be compromised. Please download AnyDesk so our technician can connect to your computer. Do not hang up.' },
  { label: 'Too-good job email', mode: 'email', from: 'hr.talentdesk.jobs@gmail.com', subject: 'Remote position offer',
    text: 'Dear Candidate, we found your resume online and are pleased to offer you a remote Data Entry Clerk position paying $45/hour. No experience needed. We will mail you a check to purchase equipment from our approved vendor. Reply with your full name, address and bank account number to get started.' },
  { label: 'Pharmacy reminder (legit)', mode: 'text', from: '47392',
    text: 'Riverbend Pharmacy: Your prescription is ready for pickup at our Main St location. Questions? Call the store. Reply STOP to opt out.' },
  { label: 'Bank fraud alert (legit)', mode: 'email', from: 'alerts@northwindcu.org', subject: 'Did you make this purchase?',
    text: 'We noticed a $482.10 purchase on your debit card ending in 4471. If you recognize it, no action is needed. If not, sign in to the Northwind app or call the number on the back of your card. We will never ask for your PIN, password, or full card number.' }
];

const callQuestions = [
  { id: 'pay', q: 'Did they ask you to pay with gift cards, crypto, a wire, or a payment app like Zelle?', w: 30, flag: 'Asked for hard-to-reverse payment' },
  { id: 'code', q: 'Did they ask for a code sent to your phone, a password, or your Social Security number?', w: 26, flag: 'Asked for codes or personal info' },
  { id: 'remote', q: 'Did they ask you to install an app or let them control your computer or phone?', w: 26, flag: 'Wanted remote access' },
  { id: 'threat', q: 'Did they threaten arrest, a lawsuit, or shutting off an account or service?', w: 22, flag: 'Used threats' },
  { id: 'secret', q: 'Did they tell you to keep it secret or stay on the line?', w: 20, flag: 'Demanded secrecy' },
  { id: 'family', q: 'Did the caller say they were a family member in trouble who needed money?', w: 20, flag: 'Family emergency story' },
  { id: 'rush', q: 'Did they pressure you to act right now?', w: 14, flag: 'Pressure to act fast' },
  { id: 'brand', q: 'Did they claim to be from the government, your bank, or a big tech company?', w: 10, flag: 'Claimed to be a trusted organization' },
  { id: 'unexpected', q: 'Was the call unexpected (you didn’t contact them first)?', w: 8, flag: 'Unexpected call' }
];

const resources = [
  { name: 'Report fraud to the FTC', value: 'ReportFraud.ftc.gov', url: 'https://reportfraud.ftc.gov' },
  { name: 'Identity theft recovery plan', value: 'IdentityTheft.gov', url: 'https://www.identitytheft.gov' },
  { name: 'FBI Internet Crime Complaint Center', value: 'ic3.gov', url: 'https://www.ic3.gov' },
  { name: 'Forward scam texts', value: '7726', copy: '7726' },
  { name: 'National Elder Fraud Hotline', value: '1-833-372-8311', copy: '1-833-372-8311' },
  { name: 'AARP Fraud Watch Helpline', value: '1-877-908-3360', copy: '1-877-908-3360' },
  { name: 'Freeze credit: Equifax', value: '1-888-298-0045', copy: '1-888-298-0045' },
  { name: 'Freeze credit: Experian', value: '1-888-397-3742', copy: '1-888-397-3742' },
  { name: 'Freeze credit: TransUnion', value: '1-888-909-8872', copy: '1-888-909-8872' }
];

const safeWords = {
  a: ['amber', 'brisk', 'copper', 'dusty', 'fuzzy', 'golden', 'hidden', 'jolly', 'lucky', 'mellow', 'nimble', 'quiet', 'rusty', 'silver', 'sleepy', 'tangy', 'velvet', 'wobbly'],
  b: ['badger', 'cactus', 'dolphin', 'falcon', 'gecko', 'hedgehog', 'iguana', 'koala', 'lantern', 'marble', 'noodle', 'otter', 'pickle', 'quokka', 'rocket', 'teapot', 'walrus', 'yo-yo']
};

return { states, scamTypes, interests, forumCats, alerts, articles, quiz, shorts, examples, callQuestions, resources, safeWords };
})();
