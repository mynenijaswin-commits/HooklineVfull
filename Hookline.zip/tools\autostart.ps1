# Turns "start Hookline with Windows" on or off. Run through autostart-on.bat / autostart-off.bat.
param([ValidateSet('On', 'Off')][string]$Action = 'On')

$root = Split-Path -Parent $PSScriptRoot
$vbs = Join-Path $PSScriptRoot 'background-start.vbs'
$wscript = Join-Path $env:WINDIR 'System32\wscript.exe'
$link = Join-Path ([Environment]::GetFolderPath('Startup')) 'Hookline server.lnk'

if ($Action -eq 'On') {
  $shortcut = (New-Object -ComObject WScript.Shell).CreateShortcut($link)
  $shortcut.TargetPath = $wscript
  $shortcut.Arguments = '"' + $vbs + '"'
  $shortcut.WorkingDirectory = $root
  $shortcut.Description = 'Starts the Hookline server in the background'
  $shortcut.Save()
  Start-Process -FilePath $wscript -ArgumentList ('"' + $vbs + '"')
  Write-Host ''
  Write-Host '  Done. Hookline is running in the background now, and will start'
  Write-Host '  by itself whenever you sign in to Windows.'
  Write-Host ''
} else {
  if (Test-Path $link) { Remove-Item $link -Force }
  Write-Host ''
  Write-Host '  Done. Hookline will no longer start with Windows.'
  Write-Host '  To stop the copy running right now, double-click stop-server.bat.'
  Write-Host ''
}
