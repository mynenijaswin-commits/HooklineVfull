@echo off
title Hookline: stop starting with Windows
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\autostart.ps1" -Action Off
pause
