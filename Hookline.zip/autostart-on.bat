@echo off
title Hookline: start with Windows
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\autostart.ps1" -Action On
pause
