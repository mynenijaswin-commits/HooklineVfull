@echo off
title Hookline server
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js isn't installed. Download it from https://nodejs.org and run this again.
  pause
  exit /b 1
)
rem The server opens your browser itself once it's ready.
set OPEN_BROWSER=1
node server.js
pause
