/* Hookline: scam detector, learning library, quiz, shorts feed, community, and area activity. */
(() => {
'use strict';

const D = window.HL_DATA;

/* ================= Utilities ================= */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const newId = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
const clone = (o) => JSON.parse(JSON.stringify(o));
const store = {
  get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* storage blocked */ } },
  del(k) { try { localStorage.removeItem(k); } catch (e) { /* storage blocked */ } }
};
const todayKey = (d = new Date()) => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
function ago(ts) {
  const s = Math.max(0, (Date.now() - ts) / 1000);
  if (s < 60) return 'just now';
  if (s < 3600) return Math.floor(s / 60) + 'm ago';
  if (s < 86400) return Math.floor(s / 3600) + 'h ago';
  if (s < 604800) return Math.floor(s / 86400) + 'd ago';
  return new Date(ts).toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
}
const stateName = (c) => (D.states.find((s) => s.code === c) || {}).name || c || '';
function hashStr(s) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
function seededShuffle(arr, seed) {
  const a = arr.slice(); let s = seed || 1;
  for (let i = a.length - 1; i > 0; i--) { s = (Math.imul(s, 1664525) + 1013904223) >>> 0; const j = s % (i + 1); [a[i], a[j]] = [a[j], a[i]]; }
  return a;
}
const shuffle = (arr) => seededShuffle(arr, (Math.random() * 4294967295) >>> 0);
const view = (html) => { $('#view').innerHTML = html; };
const DEFAULT_AVATAR = $('#meAvatar').getAttribute('src');
const PII_RE = /\b\d{3}-\d{2}-\d{4}\b|\b(?:\d[ -]?){15,16}\b/;

/* Small, safe Markdown: headings, lists, quotes, bold, italics, links. */
function md(src) {
  const inline = (s) => s
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/(^|[^*])\*([^*\s][^*]*?)\*(?!\*)/g, '$1<em>$2</em>')
    .replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
  const lines = esc(src).split(/\r?\n/);
  let html = '', list = null, para = [];
  const flushPara = () => { if (para.length) { html += '<p>' + inline(para.join(' ')) + '</p>'; para = []; } };
  const closeList = () => { if (list) { html += '</' + list + '>'; list = null; } };
  for (const raw of lines) {
    const line = raw.trim(); let m;
    if (!line) { flushPara(); closeList(); continue; }
    if ((m = line.match(/^(#{1,3})\s+(.*)$/))) { flushPara(); closeList(); const tag = m[1].length === 3 ? 'h3' : 'h2'; html += `<${tag}>${inline(m[2])}</${tag}>`; continue; }
    if ((m = line.match(/^[-*•]\s+(.*)$/))) { flushPara(); if (list !== 'ul') { closeList(); html += '<ul>'; list = 'ul'; } html += '<li>' + inline(m[1]) + '</li>'; continue; }
    if ((m = line.match(/^\d+[.)]\s+(.*)$/))) { flushPara(); if (list !== 'ol') { closeList(); html += '<ol>'; list = 'ol'; } html += '<li>' + inline(m[1]) + '</li>'; continue; }
    if ((m = line.match(/^&gt;\s?(.*)$/))) { flushPara(); closeList(); html += '<blockquote>' + inline(m[1]) + '</blockquote>'; continue; }
    closeList(); para.push(line);
  }
  flushPara(); closeList();
  return html;
}

/* ================= Icons ================= */
const IC = {
  home: '<path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V21h5v-6h4v6h5V9.5"/>',
  shield: '<path d="M12 3l8 3v6c0 4.6-3.4 8.4-8 9-4.6-.6-8-4.4-8-9V6z"/><path d="m9 12 2 2 4-4"/>',
  book: '<path d="M4 19.5V5a2 2 0 0 1 2-2h14v16H6.5A2.5 2.5 0 0 0 4 21.5z"/><path d="M8 7h8M8 11h6"/>',
  quiz: '<circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.6.3-1 .9-1 1.6V14"/><path d="M12 17.5h.01"/>',
  play: '<rect x="5" y="2.5" width="14" height="19" rx="3"/><path d="m10.5 9 4 3-4 3z"/>',
  tri: '<path d="M8 5.5v13l10.5-6.5z" fill="currentColor"/>',
  chat: '<path d="M20 12a8 8 0 0 1-11.7 7.1L4 20l1-4.1A8 8 0 1 1 20 12z"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
  alert: '<path d="M12 3 2 20h20z"/><path d="M12 10v4M12 17h.01"/>',
  mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',
  heart: '<path d="M12 20s-7.5-4.6-7.5-10.2A4.3 4.3 0 0 1 12 7a4.3 4.3 0 0 1 7.5 2.8C19.5 15.4 12 20 12 20z"/>',
  bookmark: '<path d="M6 3h12v18l-6-4.5L6 21z"/>',
  share: '<path d="M4 13v6a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-6"/><path d="M12 3v12M7.5 7.5 12 3l4.5 4.5"/>',
  vol: '<path d="M4 9.5h3.5L12 6v12l-4.5-3.5H4z"/><path d="M15.5 9a4 4 0 0 1 0 6M18 6.5a7.5 7.5 0 0 1 0 11"/>',
  mute: '<path d="M4 9.5h3.5L12 6v12l-4.5-3.5H4z"/><path d="m16 9.5 5 5M21 9.5l-5 5"/>',
  spark: '<path d="M12 3.5l1.9 5.1 5.1 1.9-5.1 1.9L12 17.5l-1.9-5.1L5 10.5l5.1-1.9z"/><path d="M19 16v4M17 18h4"/>',
  pin: '<path d="M12 21s-6.5-5.7-6.5-11a6.5 6.5 0 0 1 13 0c0 5.3-6.5 11-6.5 11z"/><circle cx="12" cy="10" r="2.3"/>',
  check: '<path d="m5 12.5 4.5 4.5L19 7.5"/>',
  x: '<path d="M6 6l12 12M18 6 6 18"/>',
  arrowR: '<path d="M5 12h14M13 6l6 6-6 6"/>',
  arrowL: '<path d="M19 12H5M11 6l-6 6 6 6"/>',
  search: '<circle cx="11" cy="11" r="6.5"/><path d="m16 16 4.5 4.5"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  phone: '<path d="M5 3.5h3.5l1.8 4.6-2.4 1.5a11 11 0 0 0 6.5 6.5l1.5-2.4 4.6 1.8V19a1.5 1.5 0 0 1-1.6 1.5A16.5 16.5 0 0 1 3.5 5.1 1.5 1.5 0 0 1 5 3.5z"/>',
  mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3.5 6.5 8.5 6.5 8.5-6.5"/>',
  msg: '<path d="M4 5h16v11H9l-5 4z"/>',
  trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
  logout: '<path d="M15 4h4v16h-4M10 8l-4 4 4 4M6 12h10"/>',
  flag: '<path d="M5 21V4M5 4h12l-2 4 2 4H5"/>',
  copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/>',
  thumb: '<path d="M7 11v9H4v-9zM7 11l4-8c1.7 0 2.6 1.2 2.3 2.8L12.8 9H19a2 2 0 0 1 2 2.3l-1.2 6.6A2.5 2.5 0 0 1 17.3 20H7"/>',
  refresh: '<path d="M20 11a8 8 0 0 0-14.6-4.5L4 8M4 4v4h4M4 13a8 8 0 0 0 14.6 4.5L20 16M20 20v-4h-4"/>',
  stop: '<rect x="6" y="6" width="12" height="12" rx="2"/>',
  ext: '<path d="M14 4h6v6M20 4l-9 9M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/>',
  lock: '<rect x="5" y="10.5" width="14" height="10" rx="2"/><path d="M8 10.5V7.5a4 4 0 0 1 8 0v3"/>',
  bolt: '<path d="M13 3 5 13.5h6L10 21l8-10.5h-6z"/>',
  award: '<circle cx="12" cy="9" r="5.5"/><path d="m8.5 13.5-1.5 7.5 5-2.5 5 2.5-1.5-7.5"/>',
  key: '<circle cx="8" cy="15" r="4"/><path d="m11 12 9-9M17 6l3 3M15 8l2 2"/>',
  eye: '<path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z"/><circle cx="12" cy="12" r="3"/>'
};
const icon = (n, cls = '') => `<svg class="ic ${cls}" viewBox="0 0 24 24" aria-hidden="true">${IC[n] || ''}</svg>`;
const hookMark = (cls = '') => `<svg class="${cls}" viewBox="0 0 32 32" aria-hidden="true"><circle cx="20" cy="7.6" r="1.9" fill="none" stroke="currentColor" stroke-width="2.2"/><path d="M20 9.6V19a5.5 5.5 0 0 1-11 0v-3.2l3.4 3" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
const signalBars = (n, cls = '') => `<span class="signal ${cls}" data-n="${n}" aria-hidden="true"><i></i><i></i><i></i><i></i></span>`;

/* ================= State ================= */
const S = {
  route: 'home', article: null, aiArticle: null, thread: null,
  learnCat: 'All', learnQuery: '', commCat: 'all', commSort: 'latest', commQuery: '',
  detMode: 'text', callStyle: 'describe', callAnswers: {}, lastResult: null, lastInput: null,
  followTurns: [], aiContext: '', aiCtl: null, pendingScan: null,
  feedTab: 'foryou', feedJump: null, sound: false,
  caps: { user: null, db: null, sample: null }, capsReady: false,
  uid: null, me: null, isOwner: false, canWrite: null,
  session: store.get('hl.session', null),
  cloud: false, profileRef: null, profile: null, profileUnsub: null,
  forum: new Map(), reports: new Map(), forumReady: false, reportsReady: false, forumErr: false, subscribed: false,
  forumQ: Promise.resolve(), reportQ: Promise.resolve(),
  aiOff: false, qz: null, modalClose: null, lastAiArticle: null
};

const LEVELS = [[0, 'Rookie'], [100, 'Aware'], [300, 'Sharp-Eyed'], [600, 'Scam Spotter'], [1000, 'Fraud Fighter'], [2000, 'Hookline Guardian']];
const BADGES = [
  { id: 'first-scan', name: 'First Check', desc: 'Ran your first scan', ic: 'shield' },
  { id: 'quiz-ace', name: 'Perfect Round', desc: 'Scored 10/10 in a quiz', ic: 'award' },
  { id: 'streak-5', name: 'On a Roll', desc: '5 right answers in a row', ic: 'bolt' },
  { id: 'reader', name: 'Well Read', desc: 'Finished 5 articles', ic: 'book' },
  { id: 'watcher', name: 'Binge Learner', desc: 'Watched 8 shorts', ic: 'play' },
  { id: 'helper', name: 'Helper', desc: 'Replied in the community', ic: 'chat' },
  { id: 'watchdog', name: 'Watchdog', desc: 'Reported a scam', ic: 'flag' },
  { id: 'safe-word', name: 'Family Shield', desc: 'Made a family safe word', ic: 'key' }
];

/* ================= Profile store ================= */
function defaultProfile() {
  return {
    v: 1, onboarded: false, state: '', city: '', interests: [], protecting: 'me', xp: 0,
    liked: [], saved: [], watched: [], savedArticles: [], readArticles: [], aiArticles: [],
    quiz: { rounds: 0, answered: 0, correct: 0, best: 0, streak: 0, bestStreak: 0 },
    scans: [], badges: [], safeWord: '', days: { last: '', streak: 0 }, daily: { day: '', ok: null },
    createdAt: Date.now(), updatedAt: 0
  };
}
function normalize(p) {
  p = p && typeof p === 'object' ? p : {};
  const d = defaultProfile();
  const out = Object.assign(d, p);
  out.quiz = Object.assign(defaultProfile().quiz, p.quiz || {});
  out.days = Object.assign(defaultProfile().days, p.days || {});
  out.daily = Object.assign(defaultProfile().daily, p.daily || {});
  ['interests', 'liked', 'saved', 'watched', 'savedArticles', 'readArticles', 'aiArticles', 'scans', 'badges'].forEach((k) => { if (!Array.isArray(out[k])) out[k] = []; });
  out.xp = Number(out.xp) || 0;
  return out;
}

let saveTimer = null, saving = false, saveAgain = false, saveRetries = 0;
function saveProfile() {
  S.profile.updatedAt = Date.now();
  if (!S.cloud) { store.set('hl.profile.guest', S.profile); return; }
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => { saveTimer = null; flushProfile(); }, 600);
}
async function flushProfile() {
  if (!S.cloud || !S.profileRef) return;
  if (saving) { saveAgain = true; return; }
  saving = true; saveAgain = false;
  try { await S.profileRef.set(clone(S.profile)); saveRetries = 0; }
  catch (e) { onProfileWriteError(e); }
  saving = false;
  if (saveAgain && S.cloud) flushProfile();
}
function onProfileWriteError(e) {
  const code = e && e.code;
  if ((code === 'unavailable' || code === 'resource_exhausted') && saveRetries < 2) {
    saveRetries++;
    setTimeout(() => { if (S.cloud) flushProfile(); }, 2000 + Math.random() * 2000);
    return;
  }
  S.cloud = false;
  store.set('hl.profile.guest', S.profile);
  toast('Your account can’t save here right now, so progress is kept on this device.', 'alert');
}

function levelOf(xp) {
  let i = 0;
  for (let k = 0; k < LEVELS.length; k++) if (xp >= LEVELS[k][0]) i = k;
  const cur = LEVELS[i], nxt = LEVELS[i + 1];
  return { idx: i, name: cur[1], floor: cur[0], next: nxt ? nxt[0] : null, nextName: nxt ? nxt[1] : null, pct: nxt ? (xp - cur[0]) / (nxt[0] - cur[0]) : 1 };
}
function award(n, why) {
  const before = levelOf(S.profile.xp).idx;
  S.profile.xp += n;
  const after = levelOf(S.profile.xp);
  if (after.idx > before) toast(`Level up! You’re now ${after.name}.`, 'award');
  else if (why) toast(`+${n} XP · ${why}`, 'bolt');
  saveProfile(); updateHeader();
}
function grant(id) {
  if (S.profile.badges.includes(id)) return;
  const b = BADGES.find((x) => x.id === id); if (!b) return;
  S.profile.badges.push(id);
  S.profile.xp += 20;
  toast(`Badge earned: ${b.name} (+20 XP)`, 'award');
  saveProfile(); updateHeader();
}

/* ================= Capabilities ================= */
async function initCaps() {
  const c = window.claude;
  if (!c || typeof c.use !== 'function') { S.capsReady = true; onCapsReady(); return; }
  const get = (n) => Promise.resolve().then(() => c.use(n)).catch(() => null);
  const [user, db, sample] = await Promise.all([get('user'), get('db'), get('sample')]);
  S.caps = { user, db, sample };
  if (user) {
    try { S.me = await user.me(); S.uid = (S.me && S.me.id) || null; S.isOwner = !!(S.me && S.me.isOwner); } catch (e) { /* no identity */ }
    try { S.canWrite = await user.can('data.write'); } catch (e) { S.canWrite = null; }
  }
  document.body.classList.toggle('has-ai', !!sample);
  S.capsReady = true;
  onCapsReady();
}
async function onCapsReady() {
  if (S.caps.db) subscribeShared();
  if (S.session) await resolveSession();
}
// Everyone enters as a guest; when the viewer already has an account here, progress syncs to it quietly.
async function resolveSession() {
  await connectAccount(false);
  if (S.uid && S.caps.db) { S.session = 'account'; await startCloud(); }
  else S.session = 'guest';
  afterProfileReady();
}
// Being signed in to Claude isn't enough: the viewer must also allow this page to use their identity and database.
// Ask for any permission still waiting on an answer; with `interactive`, also open the Permissions panel for denied ones.
async function connectAccount(interactive) {
  const c = window.claude;
  if (!c || typeof c.use !== 'function') return false;
  let perms = null;
  try { perms = await c.use('permissions'); } catch (e) { perms = null; }
  if (perms) {
    try {
      let st = await perms.state();
      const need = ['user', 'db'].filter((n) => st[n] === 'prompt');
      if (need.length) st = Object.assign({}, st, await perms.request(need));
      if (interactive && ['user', 'db'].some((n) => st[n] === 'denied')) {
        try { await perms.manage(); } catch (e) { toast('Open this page’s Permissions menu and allow access, then reload.', 'alert'); }
      }
    } catch (e) { /* permission checks unavailable */ }
  }
  try { if (!S.caps.user) S.caps.user = await c.use('user'); } catch (e) { /* ignore */ }
  try { if (!S.caps.db) S.caps.db = await c.use('db'); } catch (e) { /* ignore */ }
  if (S.caps.user) {
    try { S.me = await S.caps.user.me(); S.uid = (S.me && S.me.id) || null; S.isOwner = !!(S.me && S.me.isOwner); } catch (e) { /* no identity */ }
    try { S.canWrite = await S.caps.user.can('data.write'); } catch (e) { S.canWrite = null; }
  }
  if (S.caps.db) subscribeShared();
  return !!(S.uid && S.caps.db);
}
async function connectFromButton() {
  if (!window.claude) { toast('Open Hookline from its link on Claude to connect your account. The copy in your folder can’t connect.', 'alert'); return; }
  const ok = await connectAccount(true);
  if (ok) {
    closeModal();
    S.session = 'account'; await startCloud(); afterProfileReady();
    toast(S.cloud ? 'Account connected. Your progress now syncs.' : 'Account connected, but saving is blocked here, so progress stays on this device.');
  } else {
    toast('Still not connected. Allow access in this page’s Permissions menu, then reload the page.', 'alert');
  }
}
async function startCloud() {
  S.profileRef = S.caps.db.doc('data/users/' + S.uid + '/profile');
  try {
    const snap = await S.profileRef.get();
    if (snap.exists) S.profile = normalize(clone(snap.data()));
    else {
      S.profile = normalize(store.get('hl.profile.guest', null));
      S.profile.updatedAt = Date.now();
      await S.profileRef.set(clone(S.profile));
    }
    S.cloud = true;
    if (S.profileUnsub) S.profileUnsub();
    S.profileUnsub = S.profileRef.onSnapshot((s) => {
      if (!s.exists || s.metadata.hasPendingWrites || saving || saveTimer) return;
      const d = s.data();
      if ((d.updatedAt || 0) > (S.profile.updatedAt || 0)) {
        S.profile = normalize(clone(d));
        updateHeader();
        if (S.route === 'profile') render();
      }
    }, () => {});
  } catch (e) {
    S.cloud = false;
    S.profile = normalize(store.get('hl.profile.guest', null));
    toast('Your account couldn’t save here, so progress stays on this device.', 'alert');
  }
}
function subscribeShared() {
  if (S.subscribed) return;
  S.subscribed = true;
  const db = S.caps.db;
  try {
    db.collection('forum').onSnapshot((snap) => {
      S.forum = new Map(snap.docs.map((d) => [d.id, d.data()]));
      S.forumReady = true; S.forumErr = false;
      updateCommunity();
    }, () => { S.forumErr = true; updateCommunity(); });
    db.collection('reports').onSnapshot((snap) => {
      S.reports = new Map(snap.docs.map((d) => [d.id, d.data()]));
      S.reportsReady = true;
      if (S.route === 'home') updateHomeActivity();
    }, () => { S.reportsReady = true; if (S.route === 'home') updateHomeActivity(); });
  } catch (e) { S.forumErr = true; }
}
function aiReady() { return !!S.caps.sample && !S.aiOff; }
function aiErr(e) {
  const c = e && e.code;
  if (['not_granted', 'sampling_disabled', 'not_declared', 'capability_disabled', 'capability_removed'].includes(c)) {
    S.aiOff = true; document.body.classList.remove('has-ai');
    return 'AI features are off for this account, so Hookline is using its built-in checks.';
  }
  if (c === 'cancelled') return '';
  if (c === 'rate_limited') return 'You’ve hit the AI limit for now. Try again in a few minutes.';
  if (c === 'refused') return 'The AI declined that request. Try rewording it.';
  if (c === 'session_expired') return 'Your session expired. Reload the page and sign in again.';
  if (c === 'invalid_json') return 'The AI’s answer came back garbled. Try again.';
  if (c === 'prompt_too_large') return 'That’s too much text for one request. Try a shorter excerpt.';
  return 'The AI couldn’t finish. Check your connection and try again.';
}
async function hydrateNames(root) {
  if (!root) return;
  const els = $$('[data-uname],[data-uavatar]', root);
  if (!els.length) return;
  const ids = Array.from(new Set(els.map((e) => e.dataset.uname || e.dataset.uavatar)));
  let ps = {};
  if (S.caps.user) { try { ps = await S.caps.user.profiles(ids); } catch (e) { ps = {}; } }
  els.forEach((e) => {
    const id = e.dataset.uname || e.dataset.uavatar; const p = ps[id];
    if (e.dataset.uname) e.textContent = id === S.uid ? 'You' : ((p && p.name) || 'Hookline member');
    else if (p && p.avatarUrl) e.src = p.avatarUrl;
  });
}

/* ================= Shell ================= */
function updateHeader() {
  if (!S.profile) return;
  $('#meXp').textContent = S.profile.xp + ' XP';
  $('#meAvatar').src = (S.session === 'account' && S.me && S.me.avatarUrl) ? S.me.avatarUrl : DEFAULT_AVATAR;
}
const ROUTES = ['home', 'detect', 'learn', 'quiz', 'feed', 'community', 'profile'];
function hashRoute() { const h = (location.hash || '').replace('#', ''); return ROUTES.includes(h) ? h : 'home'; }
function navigate(r, opts = {}) {
  leaveRoute();
  S.route = r;
  S.article = opts.article || null; S.aiArticle = opts.aiArticle || null; S.thread = opts.thread || null;
  if (location.hash.slice(1) !== r) { try { location.hash = r; } catch (e) { /* ignore */ } }
  render();
  window.scrollTo(0, 0);
  $('#view').focus({ preventScroll: true });
}
function render() {
  $$('[data-route]').forEach((a) => a.classList.toggle('active', a.dataset.route === S.route));
  ({ home: renderHome, detect: renderDetect, learn: renderLearn, quiz: renderQuiz, feed: renderFeed, community: renderCommunity, profile: renderProfile }[S.route] || renderHome)();
}
function leaveRoute() { stopFeed(); stopListening(); clearQuizTimer(); if (S.aiCtl) { try { S.aiCtl.abort(); } catch (e) { /* ignore */ } S.aiCtl = null; } }

function openModal(html, opts = {}) {
  const m = $('#modal');
  m.innerHTML = `<div class="modal-backdrop" data-act="close-modal"></div><div class="modal-card ${opts.wide ? 'wide' : ''}" role="dialog" aria-modal="true">${html}</div>`;
  m.hidden = false;
  S.modalClose = opts.onClose || null;
  const f = m.querySelector('[autofocus]') || m.querySelector('.modal-body input, .modal-body select, .modal-body textarea');
  if (f) setTimeout(() => f.focus(), 40);
}
function closeModal() {
  const m = $('#modal'); if (m.hidden) return;
  m.hidden = true; m.innerHTML = '';
  const cb = S.modalClose; S.modalClose = null; if (cb) cb();
}
const modalHead = (title, sub) => `<div class="modal-head"><div><h2>${title}</h2>${sub ? `<p>${sub}</p>` : ''}</div><button class="btn btn-quiet" type="button" data-act="close-modal" aria-label="Close">${icon('x')}</button></div>`;
function toast(msg, ic = 'check') {
  const box = $('#toasts');
  const t = document.createElement('div'); t.className = 'toast';
  t.innerHTML = icon(ic) + '<span></span>';
  t.querySelector('span').textContent = msg;
  box.appendChild(t);
  while (box.children.length > 3) box.firstChild.remove();
  setTimeout(() => t.remove(), 3800);
}
function copyText(text) {
  try {
    navigator.clipboard.writeText(text).then(() => toast('Copied'), () => toast('Copy was blocked here. Select the text and copy it yourself.', 'alert'));
  } catch (e) { toast('Copy was blocked here. Select the text and copy it yourself.', 'alert'); }
}
const stateOptions = (sel) => '<option value="">Choose a state…</option>' + D.states.slice().sort((a, b) => a.name.localeCompare(b.name)).map((s) => `<option value="${s.code}" ${s.code === sel ? 'selected' : ''}>${esc(s.name)}</option>`).join('');

/* ================= Auth + onboarding ================= */
function showAuth() { $('#auth').hidden = false; $('#app').setAttribute('aria-hidden', 'true'); renderAuth(); }
function hideAuth() { $('#auth').hidden = true; $('#app').removeAttribute('aria-hidden'); }
function renderAuth() {
  $('#auth').innerHTML = `<div class="auth-wrap">
    <section class="auth-brand">
      <span class="brand">${`<svg class="brand-mark" viewBox="0 0 32 32" aria-hidden="true"><rect width="32" height="32" rx="9" fill="#2443D0"/><circle cx="20" cy="7.6" r="1.9" fill="none" stroke="#fff" stroke-width="2.2"/><path d="M20 9.6V19a5.5 5.5 0 0 1-11 0v-3.2l3.4 3" fill="none" stroke="#fff" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>`}<span>Hookline</span></span>
      <h1>Spot the hook <em>before you bite.</em></h1>
      <div class="auth-points">
        <div>${icon('shield')}<span>Check any text, email, or phone call for scam tactics in seconds.</span></div>
        <div>${icon('play')}<span>A personal feed of short, narrated scam-awareness videos.</span></div>
        <div>${icon('pin')}<span>See which scams people are reporting in your area.</span></div>
        <div>${icon('chat')}<span>Ask the community about a message that feels off.</span></div>
      </div>
      <div class="auth-demo" aria-hidden="true">
        <div class="bubble-mini">USPS: Your package is on hold. Update your address within 12 hours: usps-redeliver.info</div>
        <div class="row">${signalBars(4, 'sm')} Likely scam · 86 / 100</div>
      </div>
    </section>
    <section class="auth-side">
      <div class="auth-card">
        <div class="stack-sm"><p class="eyebrow">Welcome</p><h2>Welcome to Hookline</h2><p class="muted">Check suspicious messages, learn the tricks scammers use, and help warn people near you.</p></div>
        <button class="btn btn-primary btn-lg btn-block" type="button" data-act="signin-guest">Continue as guest ${icon('arrowR')}</button>
        <p class="small muted" style="text-align:center">Your feed, saved articles, and quiz progress are saved automatically.</p>
        <div class="auth-note">${icon('lock')}<span>Hookline never asks for a password, your bank details, or your Social Security number. If an app or message does, be suspicious.</span></div>
      </div>
    </section>
  </div>`;
}
function continueAsGuest() {
  store.set('hl.session', 'guest');
  hideAuth();
  if (S.capsReady) resolveSession();
  else { S.session = 'pending'; render(); }
}
function afterProfileReady() {
  const t = todayKey(); const d = S.profile.days;
  if (d.last !== t) {
    const y = todayKey(new Date(Date.now() - 864e5));
    d.streak = d.last === y ? (d.streak || 0) + 1 : 1; d.last = t;
    saveProfile();
  }
  updateHeader(); render(); maybeOnboard();
}
function maybeOnboard() {
  if (!S.capsReady || S.profile.onboarded || !$('#modal').hidden || !$('#auth').hidden) return;
  openPrefs(false);
}
function openPrefs(edit) {
  const p = S.profile;
  const protect = [['me', 'Myself'], ['elders', 'Parents or grandparents'], ['kids', 'Kids or teens'], ['everyone', 'Everyone I know']];
  openModal(`${modalHead(edit ? 'Your preferences' : 'Set up Hookline', 'Three quick choices so your home page and feed fit you.')}
    <form id="prefsForm" class="modal-body">
      <div class="field-row">
        <div class="field"><label for="pfState">Your state</label><select id="pfState">${stateOptions(p.state)}</select></div>
        <div class="field"><label for="pfCity">City or town <span class="muted">(optional)</span></label><input id="pfCity" type="text" maxlength="60" value="${esc(p.city)}" placeholder="e.g. Springfield"></div>
      </div>
      <div class="field"><span class="label">What do you want to learn about?</span>
        <div class="chips" id="pfInterests">${D.interests.map((i) => `<button type="button" class="chip ${p.interests.includes(i.id) ? 'on' : ''}" data-act="toggle-chip" data-val="${i.id}" aria-pressed="${p.interests.includes(i.id)}">${esc(i.label)}</button>`).join('')}</div></div>
      <div class="field"><span class="label">Who are you looking out for?</span>
        <div class="chips" id="pfProtect" data-single="1">${protect.map(([v, l]) => `<button type="button" class="chip ${p.protecting === v ? 'on' : ''}" data-act="toggle-chip" data-val="${v}" aria-pressed="${p.protecting === v}">${l}</button>`).join('')}</div></div>
    </form>
    <div class="modal-foot"><button class="btn btn-quiet" type="button" data-act="close-modal">${edit ? 'Cancel' : 'Skip for now'}</button><button class="btn btn-primary" type="button" data-act="save-prefs">Save</button></div>`,
  { onClose: () => { if (!S.profile.onboarded) { S.profile.onboarded = true; saveProfile(); } } });
}
function savePrefs() {
  const p = S.profile;
  p.state = $('#pfState').value;
  p.city = $('#pfCity').value.trim().slice(0, 60);
  p.interests = $$('#pfInterests .chip.on').map((b) => b.dataset.val);
  const pr = $('#pfProtect .chip.on'); p.protecting = pr ? pr.dataset.val : 'me';
  p.onboarded = true;
  saveProfile(); closeModal(); toast('Preferences saved'); render();
}
function promptSignIn(what) {
  openModal(`${modalHead('You need to have an account to ' + what, 'Connect your account so your name appears with what you share and your progress syncs.')}
    <div class="modal-body"><button class="btn btn-primary btn-lg btn-block" type="button" data-act="connect-account">${icon('user')} Connect account</button>
    <p class="small muted">If nothing happens, open this page’s Permissions menu, allow access, and reload.</p></div>`);
}

/* ================= Scam analysis engine ================= */
const RULES = [
  { id: 'urgency', label: 'Pressure to act fast', w: 14, why: 'Scammers rush you so you don’t stop to check.',
    re: /\b(urgent(ly)?|immediately|right away|right now|within \d{1,2} ?(hours?|hrs?|minutes?|mins?)|in the next \d{1,2} ?(hours?|minutes?)|act now|final (notice|warning|attempt|reminder)|last chance|expires? (today|soon|tonight)|today only|asap|time[- ]sensitive|before it'?s too late|pay (by|before) today|pay today)\b/gi },
  { id: 'threat', label: 'Threats or scary consequences', w: 16, why: 'Fear of arrest, fines, or losing access is used to override your judgment.',
    re: /\b(arrest(ed)?|warrant|lawsuit|legal action|sue you|police|sheriff|deport(ed|ation)?|suspend(ed|sion)?|locked|frozen|terminat(e|ed|ion)|penalt(y|ies)|late fee|jail|prison|court|seiz(e|ed|ure)|compromised|hacked|shut ?off|disconnect(ed)?|permanently (closed|deleted|disabled))\b/gi },
  { id: 'payment', label: 'Asks for hard-to-reverse payment', w: 34, neg: true, why: 'Gift cards, crypto, wires, and payment apps are nearly impossible to get back. Real agencies don’t demand them.',
    re: /\b(gift ?cards?|itunes cards?|google play cards?|steam cards?|bitcoin( atm)?|btc|crypto(currency)?|usdt|tether|ethereum|wire (transfer|the money)|western union|moneygram|zelle|venmo|cash ?app|prepaid (card|debit)|money order|cash (pickup|courier)|send cash|courier will (pick|collect))\b/gi },
  { id: 'creds', label: 'Asks for passwords, codes, or personal info', w: 24, neg: true, why: 'No real company needs your password, PIN, Social Security number, or bank details over text, email, or phone.',
    re: /\b(password|passcode|pin( number)?|social security( number)?|ssn|routing number|(bank )?account number|login (details|info(rmation)?|credentials)|confirm your (identity|account|details|information)|verify your (identity|account|information|details)|card number|cvv|security code|date of birth|mother'?s maiden name)\b/gi },
  { id: 'codeask', label: 'Wants you to share a verification code', w: 34, neg: true, why: 'That code unlocks your account. Anyone asking you to read it back is trying to break in.',
    re: /\b(send|give|tell|read|share|forward|text)( it)?( me| us)?( back)?( the| that| your)?( \d[- ]?digit)? (code|verification code|one[- ]time (pass)?code|otp)\b|\bcode (you|that) (just )?(got|received)\b|\bread it back\b/gi },
  { id: 'impersonation', label: 'Claims to be a trusted organization', w: 10, why: 'Scammers borrow the names of agencies and big companies. Caller ID and sender names can be faked.',
    re: /\b(irs|internal revenue|social security administration|ssa|medicare|fbi|dmv|department of motor vehicles|usps|postal service|ups|fedex|dhl|amazon|apple support|apple id|microsoft|windows support|paypal|netflix|geek squad|norton|mcafee|wells fargo|chase|bank of america|e-?z ?pass|toll services?|sunpass|fastrak|customs|homeland security|sheriff'?s (office|department)|publishers clearing house|tech(nical)? (support|department)|security department)\b/gi },
  { id: 'prize', label: 'A prize, refund, or money you didn’t expect', w: 18, why: 'You can’t win a contest you didn’t enter, and real refunds don’t arrive by surprise message.',
    re: /\b(you('ve| have)? won|winner|congratulations|claim your (prize|reward|refund|gift|money)|lottery|sweepstakes|jackpot|free gift|unclaimed (funds|refund|money)|tax refund|eligible for a (refund|rebate|grant)|cash prize|selected (for|to receive)|government grant)\b/gi },
  { id: 'remote', label: 'Wants remote access to your device', w: 26, neg: true, why: 'Remote access apps let a stranger control your computer and see your bank accounts.',
    re: /\b(anydesk|teamviewer|remote (access|desktop|support app)|screen ?shar(e|ing)|ultraviewer|logmein|quick ?assist|install (this|the|an) app|download (this|the|an) app|connect to your (computer|device|phone|pc))\b/gi },
  { id: 'secrecy', label: 'Asks you to keep it secret', w: 20, why: 'Secrecy stops friends, family, or a bank teller from warning you.',
    re: /\b(don'?t tell (anyone|anybody|your|mom|dad)|do not tell|keep (this|it) (between us|secret|confidential|quiet)|do not (discuss|contact) (anyone|your bank|the bank|family)|stay on the (line|phone)|don'?t hang up|do not hang up|don'?t talk to (anyone|the bank))\b/gi },
  { id: 'family', label: 'Family emergency story', w: 16, why: 'Emergency calls from “family” are a classic scam, now more convincing with AI voice cloning.',
    re: /\b(grandma|grandpa|grandmother|grandfather|it'?s me|in (jail|the hospital|trouble)|car accident|bail( money)?|new (phone )?number|lost my phone|broke my phone|need (money|help) (fast|now|urgently))\b/gi },
  { id: 'job', label: 'Too-good-to-be-true job or income', w: 16, why: 'High pay for easy work with no interview is a hallmark of job and task scams.',
    re: /\b(work from home|earn \$?\d[\d,]*|\$\d[\d,]* ?(per|\/|a) ?(day|hour|hr|week)|daily pay|easy money|no experience (needed|required)|we found your resume|remote (job|position) offer|tasks? (job|platform)|rate products|reshipping|mystery shopper|purchase equipment|approved vendor)\b/gi },
  { id: 'invest', label: 'Investment or “guaranteed” returns', w: 18, why: 'No real investment guarantees returns. Strangers pitching platforms are a top source of losses.',
    re: /\b(guaranteed (returns?|profits?|income)|double your (money|investment)|investment opportunity|trading platform|mining pool|forex|profit of \d+%|passive income|crypto (investment|trading|platform)|my (uncle|mentor|aunt) (is|works))\b/gi },
  { id: 'wrongnum', label: '“Wrong number” opener', w: 12, why: 'Friendly wrong-number texts are often the first step in long investment scams.',
    re: /\b([Ii]s this [A-Z][a-z]+\??|[Ss]orry,? (maybe )?wrong number|[Ww]e met at|from (the )?(yoga|gym|dinner|party))/g },
  { id: 'delivery', label: 'Package problem or fee', w: 14, why: 'Fake delivery problems lure you into entering card details for a small “fee.”',
    re: /\b((package|parcel|shipment|delivery) (could not|cannot|can'?t|was not|failed|is on hold|on hold|is pending|attempt)|redelivery|re-delivery|incomplete address|update (your )?(delivery )?address|customs fee|shipping fee)\b/gi },
  { id: 'toll', label: 'Unpaid toll or ticket notice', w: 16, why: 'Fake toll and DMV texts have hit drivers nationwide. Agencies don’t text payment links.',
    re: /\b(unpaid (toll|balance|ticket|invoice|fine)|outstanding (toll|balance|fine|ticket)|toll (bill|balance|charges?|notice|services?)|traffic (ticket|violation|citation)|parking (ticket|violation))\b/gi },
  { id: 'callback', label: 'Pushes you to call or reply', w: 8, why: 'Phone numbers in scam messages connect you straight to the scammer.',
    re: /\b(call (us|back|this number|now|immediately)|call 1?-?\(?\d{3}\)?[-. ]?\d{3}[-. ]?\d{4}|press 1|reply (yes|y)\b|text back)/gi },
  { id: 'generic', label: 'Generic greeting', w: 6, why: 'Real companies usually address you by name.',
    re: /\b(dear (customer|user|client|sir|madam|member|valued|account holder|candidate)|hello (customer|user))\b/gi },
  { id: 'romance', label: 'Romance or emotional hook', w: 12, why: 'Fast declarations of love paired with a money request are a romance scam pattern.',
    re: /\b(my love|my dear|soulmate|i love you|deployed overseas|oil rig|can'?t video (chat|call)|camera is broken|plane ticket to see you)\b/gi }
];
const GOOD = [
  { id: 'nevershare', label: 'Warns you not to share codes or info', w: -12, re: /\b(never|don'?t|do not) (share|give out|tell anyone)( this| the| your)? (code|pin|password)|\b(we|they) (will )?never (ask|call|text|email)/gi },
  { id: 'trusted', label: 'Points you to a channel you already trust', w: -10, re: /\b(number on the back of your card|sign in to (the|our|your) ([a-z]+ )?app|type the (web )?address yourself|call the number on your (statement|bill)|visit [a-z]+\.(com|gov|org) directly)/gi },
  { id: 'noaction', label: 'Says no action is needed', w: -6, re: /\b(no (action|need) (is )?(needed|required)|you don'?t need to do anything|if (this|it) was you)/gi },
  { id: 'optout', label: 'Standard opt-out language', w: -2, re: /\breply stop\b/gi }
];
const URL_RE = /\b(?:https?:\/\/)?(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+(?:com|net|org|gov|edu|info|top|xyz|io|co|us|vip|cc|click|link|live|shop|site|online|icu|buzz|tk|ml|ga|cf|gq|ly|me|app|biz|ru|cn|support|help|pay|services|world|store|club|win|bid|cam|sbs|cfd|lat|today)\b(?:\/[^\s<>"']*)?/gi;
const SHORTENERS = ['bit.ly', 'tinyurl.com', 't.co', 'rb.gy', 'cutt.ly', 'is.gd', 'goo.gl', 'ow.ly', 'tiny.cc', 'shorturl.at', 't.ly', 'rebrand.ly', 's.id'];
const RISKY_TLDS = ['top', 'xyz', 'vip', 'icu', 'buzz', 'click', 'link', 'shop', 'live', 'cc', 'tk', 'ml', 'ga', 'cf', 'gq', 'online', 'site', 'info', 'support', 'help', 'pay', 'services', 'world', 'win', 'bid', 'cam', 'sbs', 'cfd', 'lat', 'today', 'club', 'store', 'ru', 'cn'];
const BRANDS = {
  usps: ['usps.com'], ups: ['ups.com'], fedex: ['fedex.com'], dhl: ['dhl.com'], amazon: ['amazon.com'], apple: ['apple.com'], icloud: ['icloud.com'],
  microsoft: ['microsoft.com'], paypal: ['paypal.com'], netflix: ['netflix.com'], irs: ['irs.gov'], ssa: ['ssa.gov'], medicare: ['medicare.gov'],
  chase: ['chase.com'], wellsfargo: ['wellsfargo.com'], bankofamerica: ['bankofamerica.com'], google: ['google.com'], facebook: ['facebook.com'],
  instagram: ['instagram.com'], ezpass: ['e-zpassny.com', 'ezpassnj.com', 'ezpassva.com', 'ezpassmd.com', 'ezpassde.com', 'ezpassma.com', 'e-zpassiag.com'],
  sunpass: ['sunpass.com'], fastrak: ['bayareafastrak.org'], walmart: ['walmart.com'], coinbase: ['coinbase.com'], venmo: ['venmo.com'], zelle: ['zellepay.com']
};
const OFFICIAL = [].concat(...Object.values(BRANDS), ['live.com', 'outlook.com', 'youtube.com', 'reportfraud.ftc.gov']);
const FREEMAIL = ['gmail.com', 'yahoo.com', 'outlook.com', 'hotmail.com', 'aol.com', 'icloud.com', 'proton.me', 'protonmail.com', 'gmx.com', 'mail.com', 'yandex.com', 'live.com'];
const TIERS = {
  safe: { label: 'Looks legit', stamp: 'Low risk', n: 1, cls: 'v-safe', tone: 'tone-safe', pill: 'pill-safe' },
  caution: { label: 'Be careful', stamp: 'Some warning signs', n: 2, cls: 'v-caution', tone: 'tone-caution', pill: 'pill-warn' },
  danger: { label: 'Likely a scam', stamp: 'High risk', n: 3, cls: 'v-danger', tone: 'tone-danger', pill: 'pill-danger' },
  crit: { label: 'Almost certainly a scam', stamp: 'Critical risk', n: 4, cls: 'v-crit', tone: 'tone-crit', pill: 'pill-crit' }
};

function negated(s, idx) {
  const before = s.slice(Math.max(0, idx - 60), idx);
  return /\b(never|won'?t|will not|do not|don'?t)\s+(ask|request|call|text|email|share|give|send|need|require)\b[^.!?\n]{0,45}$/i.test(before)
    || /\b(never|won'?t|will not|do not|don'?t)\s*$/i.test(before);
}
function urlReasons(host, full) {
  const list = [];
  const parts = host.split('.'); const tld = parts[parts.length - 1];
  if (OFFICIAL.some((d) => host === d || host.endsWith('.' + d)) || /\.(gov|mil)$/.test(host)) return { official: true, list };
  if (SHORTENERS.includes(host)) list.push('Shortened links hide where they really go.');
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(host)) list.push('The link is a raw IP address instead of a website name.');
  if (RISKY_TLDS.includes(tld)) list.push(`The “.${tld}” ending is common on scam sites and unusual for real companies.`);
  const tokens = host.split(/[.-]/).filter(Boolean);
  const subst = (t) => t.replace(/0/g, 'o').replace(/1/g, 'l').replace(/3/g, 'e').replace(/5/g, 's').replace(/4/g, 'a').replace(/rn/g, 'm');
  outer: for (const b of Object.keys(BRANDS)) {
    for (const t of tokens) {
      const match = (x) => b.length >= 5 ? x.startsWith(b) || x.endsWith(b) : x === b;
      if (match(t)) { list.push(`It uses the name “${b}” but isn’t that company’s real website.`); break outer; }
      if (match(subst(t))) { list.push(`It swaps letters for look-alike numbers to imitate “${b}.”`); break outer; }
    }
  }
  if (/(toll|dmv|redeliver|refund|verify|secure|login|signin|account|billing|support|claim|prize|gift)/.test(host.replace(/[.-]/g, '')) && (host.includes('-') || RISKY_TLDS.includes(tld))) list.push('The address is stitched together from official-sounding words.');
  if (parts.length > 4) list.push('It has an unusually long chain of subdomains.');
  if (/@/.test(full)) list.push('The link contains an “@”, which can disguise the real destination.');
  return { official: false, list: Array.from(new Set(list)) };
}
function analyzeUrls(norm, text) {
  const hits = [], official = [], bad = [], plain = [], reasons = new Set();
  URL_RE.lastIndex = 0; let m;
  while ((m = URL_RE.exec(norm))) {
    const str = m[0].replace(/[.,!?;:)\]]+$/, '');
    const s = m.index, e = s + str.length;
    if (norm[s - 1] === '@' || norm[e] === '@') continue;
    const host = str.replace(/^https?:\/\//i, '').split(/[/?#]/)[0].toLowerCase();
    const r = urlReasons(host, str);
    const rec = { s, e, str: text.slice(s, e) };
    if (r.official) official.push(rec);
    else if (r.list.length) { bad.push(rec); r.list.forEach((x) => reasons.add(x)); }
    else plain.push(rec);
  }
  if (bad.length) hits.push({ id: 'badlink', label: 'Suspicious link', why: Array.from(reasons).join(' '), w: 22 + Math.min(bad.length - 1, 2) * 5, matches: bad });
  if (bad.length || plain.length) hits.push({ id: 'link', label: 'Contains a link', why: 'Links in unexpected messages are the main way scammers steal logins and card numbers.', w: 6, matches: plain });
  const goods = official.length && !bad.length ? [{ id: 'official', label: 'Link goes to an official site', why: 'Still, it’s safest to type the address yourself.', w: -4, matches: official }] : [];
  return { hits, goods };
}
function senderSignals(from, mode, ids) {
  const hits = [], goods = [];
  const f = String(from || '').trim(); if (!f) return { hits, goods };
  const email = f.match(/[^\s@<]+@([^\s@>]+\.[a-z]{2,})/i);
  if (email) {
    const dom = email[1].toLowerCase();
    if (mode === 'text') hits.push({ id: 'smsemail', label: 'Text sent from an email address', why: 'Scammers text from email addresses to slip past carrier spam filters.', w: 10, matches: [] });
    if (FREEMAIL.includes(dom) && ['impersonation', 'job', 'prize', 'creds', 'payment', 'invest'].some((x) => ids.has(x))) hits.push({ id: 'freemail', label: 'Official business using a free email account', why: `Real companies and agencies don’t send official notices from ${dom}.`, w: 16, matches: [] });
    const r = urlReasons(dom, dom);
    if (!r.official && !FREEMAIL.includes(dom) && r.list.length) hits.push({ id: 'baddomain', label: 'Sender’s domain looks fake', why: r.list[0], w: 20, matches: [] });
  } else {
    const compact = f.replace(/[^\d+]/g, ''); const digits = compact.replace(/\D/g, '');
    if (compact.startsWith('+') && !compact.startsWith('+1')) hits.push({ id: 'intl', label: 'International number', why: 'An unexpected message from an overseas number is a common scam sign.', w: 10, matches: [] });
    else if (digits.length >= 10 && mode === 'text' && ['toll', 'delivery', 'impersonation', 'creds'].some((x) => ids.has(x))) hits.push({ id: 'longcode', label: '“Official” alert from a regular phone number', why: 'Banks, toll agencies, and carriers usually send alerts from 5–6 digit short codes, not random 10-digit numbers.', w: 8, matches: [] });
    if (digits.length >= 5 && digits.length <= 6 && !compact.startsWith('+')) goods.push({ id: 'shortcode', label: 'Sent from a business short code', why: 'Short codes are harder for scammers to get, though not impossible.', w: -4, matches: [] });
  }
  return { hits, goods };
}
const softScore = (raw) => Math.round(99 * (1 - Math.exp(-Math.max(0, raw) / 55)));
const tierOf = (score) => score >= 70 ? 'crit' : score >= 45 ? 'danger' : score >= 20 ? 'caution' : 'safe';
function guessType(ids) {
  const order = [['family', 'Family emergency (grandparent) scam'], ['remote', 'Tech support scam'], ['codeask', 'Account takeover attempt'], ['toll', 'Toll or ticket text scam'], ['delivery', 'Package delivery scam'], ['wrongnum', 'Wrong-number investment scam'], ['invest', 'Investment scam'], ['job', 'Job or task scam'], ['romance', 'Romance scam'], ['prize', 'Prize or refund scam']];
  for (const [id, name] of order) if (ids.has(id)) return name;
  if (ids.has('impersonation') && (ids.has('threat') || ids.has('payment'))) return 'Impostor scam';
  if (ids.has('badlink') || ids.has('creds') || ids.has('baddomain')) return 'Phishing attempt';
  return 'Scam';
}
function summaryFor(tier, type) {
  if (tier === 'crit') return `This has the hallmarks of a ${type.toLowerCase()}. Don’t reply, don’t tap links, and don’t send money or codes.`;
  if (tier === 'danger') return `Several classic scam signs showed up, consistent with a ${type.toLowerCase()}. Treat it as a scam unless you can verify it through a channel you already trust.`;
  if (tier === 'caution') return 'A few things here are worth checking. Contact the sender directly, using contact info you look up yourself, before you act.';
  return 'We didn’t find common scam signs. If it involves money or account access, it’s still smart to verify through the official app or website.';
}
function adviceFor(ids, tier, mode) {
  const out = [];
  if (tier === 'safe') {
    out.push('Nothing urgent here. If money or account access comes up later, verify through the official app or website.');
    out.push('Still unsure? Contact the sender using a number or site you find yourself, not one in the message.');
    return out;
  }
  out.push(mode === 'call' || mode === 'live' ? 'Hang up. You can always call back using a number you look up yourself.' : 'Don’t reply, and don’t tap any links in the message.');
  if (ids.has('payment')) out.push('Don’t send money, gift cards, crypto, or payment-app transfers. If you already did, call that company right away.');
  if (ids.has('codeask') || ids.has('creds')) out.push('Never share codes, passwords, or your Social Security number. If you did, change your password now and turn on two-step verification.');
  if (ids.has('remote')) out.push('Don’t install anything. If you already gave access, disconnect from the internet and get the device checked.');
  if (ids.has('family')) out.push('Call your family member directly at the number you already have, or ask for your family safe word.');
  if (['badlink', 'link', 'toll', 'delivery'].some((x) => ids.has(x))) out.push('Go to the real website or app yourself to check your account, toll balance, or package.');
  if (ids.has('impersonation') || ids.has('threat')) out.push('Real agencies and companies don’t threaten you or demand instant payment. Look up their official number to double-check.');
  if (mode === 'text') out.push('Forward scam texts to 7726 (SPAM), then delete and block the sender.');
  out.push('Report it at ReportFraud.ftc.gov, and warn others with “Report to community.”');
  return Array.from(new Set(out)).slice(0, 6);
}
function analyze(raw, opts = {}) {
  const text = String(raw || '');
  const mode = opts.mode || 'text';
  const norm = text.replace(/[‘’ʼ]/g, "'").replace(/[“”]/g, '"');
  const hits = [], goods = [], ranges = [];
  for (const r of RULES) {
    r.re.lastIndex = 0; const ms = []; let m;
    while ((m = r.re.exec(norm))) {
      if (!m[0].length) { r.re.lastIndex++; continue; }
      if (r.neg && negated(norm, m.index)) continue;
      ms.push({ s: m.index, e: m.index + m[0].length });
    }
    if (ms.length) {
      hits.push({ id: r.id, label: r.label, why: r.why, w: r.w + Math.min(ms.length - 1, 2) * Math.round(r.w * 0.25), matches: ms });
      ms.forEach((x) => ranges.push({ s: x.s, e: x.e, kind: 'flag', label: r.label }));
    }
  }
  const u = analyzeUrls(norm, text);
  u.hits.forEach((h) => { hits.push(h); h.matches.forEach((x) => ranges.push({ s: x.s, e: x.e, kind: 'flag', label: h.label })); });
  u.goods.forEach((g) => { goods.push(g); g.matches.forEach((x) => ranges.push({ s: x.s, e: x.e, kind: 'good', label: g.label })); });
  for (const g of GOOD) {
    g.re.lastIndex = 0; const ms = []; let m;
    while ((m = g.re.exec(norm))) { if (!m[0].length) { g.re.lastIndex++; continue; } ms.push({ s: m.index, e: m.index + m[0].length }); }
    if (ms.length) { goods.push({ id: g.id, label: g.label, why: '', w: g.w, matches: ms }); ms.forEach((x) => ranges.push({ s: x.s, e: x.e, kind: 'good', label: g.label })); }
  }
  let ids = new Set(hits.map((h) => h.id));
  const sd = senderSignals(opts.from, mode, ids);
  hits.push(...sd.hits); goods.push(...sd.goods);
  ids = new Set(hits.map((h) => h.id));
  const has = (x) => ids.has(x);
  if (has('impersonation') && (has('badlink') || has('creds') || has('payment') || has('codeask'))) hits.push({ id: 'combo-imp', label: 'Trusted name + a request', why: 'A familiar name combined with a link, payment, or info request is the classic scam formula.', w: 12, matches: [] });
  if (has('threat') && (has('payment') || has('urgency'))) hits.push({ id: 'combo-fear', label: 'Threat + pressure', why: 'Threats paired with urgency or payment demands are designed to make you panic.', w: 10, matches: [] });
  if (has('family') && (has('payment') || has('secrecy'))) hits.push({ id: 'combo-fam', label: 'Emergency + secrecy or payment', why: 'This is the exact shape of the “grandparent” scam.', w: 14, matches: [] });
  if ((has('job') || has('invest') || has('prize')) && (has('payment') || has('creds'))) hits.push({ id: 'combo-money', label: 'Easy money + a request', why: 'Promises of money followed by a request for payment or info are how these scams pay off.', w: 12, matches: [] });
  ids = new Set(hits.map((h) => h.id));
  let rawScore = hits.reduce((a, h) => a + h.w, 0) + goods.reduce((a, g) => a + g.w, 0);
  if ((mode === 'call' || mode === 'live') && hits.length) rawScore += 4;
  const score = clamp(softScore(rawScore), hits.length ? 3 : 1, 99);
  const tier = tierOf(score);
  hits.sort((a, b) => b.w - a.w);
  const type = guessType(ids);
  return { text, mode, from: opts.from || '', score, tier, hits, goods, ranges, type, ids: Array.from(ids), summary: summaryFor(tier, type), advice: adviceFor(ids, tier, mode) };
}
function analyzeChecklist(ans) {
  const map = { pay: 'payment', code: 'creds', remote: 'remote', threat: 'threat', secret: 'secrecy', family: 'family', rush: 'urgency', brand: 'impersonation', unexpected: 'unexpected' };
  const hits = [];
  D.callQuestions.forEach((q) => {
    const v = ans[q.id];
    if (v === 'yes' || v === 'unsure') hits.push({ id: map[q.id], label: q.flag, why: v === 'unsure' ? 'You weren’t sure, so this counts for half.' : '', w: v === 'yes' ? q.w : Math.round(q.w / 2), matches: [] });
  });
  const ids = new Set(hits.map((h) => h.id));
  if (ids.has('threat') && ids.has('payment')) hits.push({ id: 'combo-fear', label: 'Threat + payment demand', why: 'This pairing is almost always a scam.', w: 20, matches: [] });
  const raw = hits.reduce((a, h) => a + h.w, 0);
  const score = clamp(softScore(raw), hits.length ? 3 : 1, 99);
  const tier = tierOf(score); const type = guessType(ids);
  hits.sort((a, b) => b.w - a.w);
  return { text: '', mode: 'call', from: '', score, tier, hits, goods: [], ranges: [], type, ids: Array.from(ids), summary: summaryFor(tier, type), advice: adviceFor(ids, tier, 'call') };
}
function annotate(text, ranges) {
  const rs = ranges.slice().sort((a, b) => a.s - b.s || (b.e - b.s) - (a.e - a.s));
  let out = '', pos = 0;
  for (const r of rs) {
    if (r.s < pos) continue;
    out += esc(text.slice(pos, r.s)) + `<mark class="${r.kind === 'good' ? 'good' : 'flag'}" title="${esc(r.label)}">${esc(text.slice(r.s, r.e))}</mark>`;
    pos = r.e;
  }
  return out + esc(text.slice(pos));
}
const severity = (w) => w <= 0 ? '' : w >= 24 ? 'High' : w >= 14 ? 'Medium' : 'Low';

/* ================= Home ================= */
function dailyItem() { return D.quiz[hashStr(todayKey()) % D.quiz.length]; }
function parseMarked(msg, reveal) {
  const clues = []; const re = /\[\[(\+?)([^|\]]+)\|([^\]]+)\]\]/g;
  let out = '', last = 0, m;
  while ((m = re.exec(msg))) {
    out += esc(msg.slice(last, m.index));
    const good = m[1] === '+';
    clues.push({ good, text: m[2], why: m[3] });
    out += reveal ? `<mark class="${good ? 'good' : 'flag'}" title="${esc(m[3])}">${esc(m[2])}</mark>` : esc(m[2]);
    last = re.lastIndex;
  }
  return { html: out + esc(msg.slice(last)), clues };
}
function mockMessage(it, reveal) {
  const { html } = parseMarked(it.msg, reveal);
  if (it.ch === 'email') return `<div class="mock mock-email"><div class="mock-head"><span class="av">${icon('mail')}</span><div><b>${esc(it.from)}</b><small>Email</small></div></div><div class="mock-body">${it.subject ? `<p class="subj">${esc(it.subject)}</p>` : ''}<p>${html}</p></div></div>`;
  if (it.ch === 'call') return `<div class="mock mock-call"><div class="mock-head"><span class="av">${icon('phone')}</span><div><b>${esc(it.from)}</b><small>Phone call</small></div></div><div class="mock-body"><p class="eyebrow">What the caller said</p><p class="transcript">${html}</p></div></div>`;
  return `<div class="mock mock-text"><div class="mock-head"><span class="av">${icon('user')}</span><div><b>${esc(it.from)}</b><small>Text message</small></div></div><div class="mock-body"><div class="bubble">${html}</div></div></div>`;
}
function renderHome() {
  const p = S.profile; const lv = levelOf(p.xp);
  const first = (S.session === 'account' && S.me && S.me.name) ? S.me.name.split(' ')[0] : '';
  const hr = new Date().getHours();
  const greet = hr < 12 ? 'Good morning' : hr < 18 ? 'Good afternoon' : 'Good evening';
  const acc = p.quiz.answered ? Math.round(100 * p.quiz.correct / p.quiz.answered) + '%' : '—';
  const place = p.state ? (p.city ? `${p.city}, ${p.state}` : stateName(p.state)) : 'you';
  const recArts = D.articles.filter((a) => !p.readArticles.includes(a.id)).sort((a, b) => interestScore(b.tags) - interestScore(a.tags)).slice(0, 3);
  const recShorts = rankedShorts().slice(0, 3);
  view(`
  <section class="home-hero">
    <div class="hero-main">
      <p class="eyebrow">${greet}${first ? ', ' + esc(first) : ''}</p>
      <h1>Got a weird text or call? Check it before you answer.</h1>
      <form class="quick-scan" id="quickScan">
        <label class="sr-only" for="qsText">Message to check</label>
        <textarea id="qsText" maxlength="8000" placeholder="Paste a text, an email, or what the caller said…"></textarea>
        <div class="btn-row"><button class="btn btn-primary btn-lg" type="submit">${icon('shield')} Check it</button><button class="btn btn-ghost" type="button" data-act="qs-example">Try an example</button><span class="small muted">Instant, and only you see it.</span></div>
      </form>
    </div>
    <aside class="shield-card">
      <p class="eyebrow">Your shield level</p>
      <div class="stack-sm"><h2>${esc(lv.name)}</h2><p class="muted small">${lv.next ? `${lv.next - p.xp} XP to ${esc(lv.nextName)}` : 'Top level reached'}</p></div>
      <div class="xpbar"><i style="width:${Math.round(lv.pct * 100)}%"></i></div>
      <div class="mini-stats"><div><b>${p.days.streak || 1}</b><span>day streak</span></div><div><b>${acc}</b><span>quiz accuracy</span></div><div><b>${p.scans.length}</b><span>checks run</span></div></div>
      <a class="btn" href="#quiz">${icon('quiz')} Practice spotting scams</a>
    </aside>
  </section>

  <section class="section area">
    <div class="area-title">
      <h2><span class="live-dot" aria-hidden="true"></span> Scam activity near <span class="where">${esc(place)}</span></h2>
      <div class="btn-row"><button class="btn btn-ghost btn-sm" type="button" data-act="edit-prefs">${icon('pin')} ${p.state ? 'Change area' : 'Set your area'}</button><button class="btn btn-primary btn-sm" type="button" data-act="report">${icon('flag')} Report a scam</button></div>
    </div>
    <div id="areaBody"></div>
  </section>

  <section class="section">
    <div class="section-head"><h2>National scam alerts</h2><p>From public FTC and FBI warnings. Open a source for the latest.</p></div>
    <div class="alerts-grid">${D.alerts.map(alertCard).join('')}</div>
  </section>

  <section class="section daily" id="dailySec">${dailyHtml()}</section>

  <section class="section two-col">
    <div class="panel stack-sm">
      <div class="section-head"><h3>Keep learning</h3><a class="small" href="#learn">All articles</a></div>
      <div class="list-links">${(recArts.length ? recArts : D.articles.slice(0, 3)).map(artLink).join('')}</div>
    </div>
    <div class="panel stack">
      <div class="section-head"><h3>From your feed</h3><a class="small" href="#feed">Open feed</a></div>
      <div class="thumb-row">${recShorts.map((s) => `<button class="short-thumb" type="button" style="--h:${s.hue}" data-act="open-short" data-id="${s.id}">${icon('tri')}<span>${esc(s.title)}</span></button>`).join('')}</div>
    </div>
  </section>`);
  updateHomeActivity();
}
const alertCard = (a) => `<a class="alert-card" href="${a.url}" target="_blank" rel="noopener noreferrer"><div class="top"><span class="pill pill-danger">${esc(a.tag)}</span><span class="mono small muted">${esc(a.date)}</span></div><h3>${esc(a.title)}</h3><p>${esc(a.body)}</p><span class="src">${icon('ext')} ${esc(a.src)}</span></a>`;
const artLink = (a) => `<button class="list-link" type="button" data-act="open-article" data-id="${a.id}"><div><span class="eyebrow">${esc(a.cat)} · ${a.mins} min</span><h4>${esc(a.title)}</h4></div>${icon('arrowR', 'go')}</button>`;
function dailyHtml() {
  const it = dailyItem(); const p = S.profile; const done = p.daily.day === todayKey();
  const date = new Date().toLocaleDateString(undefined, { weekday: 'long', month: 'short', day: 'numeric' });
  let side;
  if (done) {
    const { clues } = parseMarked(it.msg, true);
    side = `<div class="feedback ${p.daily.ok ? 'ok' : 'bad'}"><h3>${icon(p.daily.ok ? 'check' : 'x')} ${p.daily.ok ? 'You got it!' : 'Not this time'}</h3><p><b>It’s ${it.scam ? 'a scam' : 'legit'}.</b> ${esc(it.why)}</p>${clues.length ? `<ul class="clue-list">${clues.slice(0, 3).map((c) => `<li class="${c.good ? 'good' : ''}"><span class="dot"></span><span><b>“${esc(c.text)}”</b> ${esc(c.why)}</span></li>`).join('')}</ul>` : ''}<p class="small muted">Come back tomorrow for a new one.</p></div>`;
  } else {
    side = `<div class="answer-row"><button class="btn btn-danger" type="button" data-act="daily" data-v="scam">${icon('alert')} Scam</button><button class="btn btn-safe" type="button" data-act="daily" data-v="legit">${icon('check')} Legit</button></div>`;
  }
  return `<div class="stack"><div class="stack-sm"><p class="eyebrow">Daily challenge · ${esc(date)}</p><h2>Scam or legit?</h2><p class="muted">One message a day. Answer to earn 10 XP.</p></div>${side}</div><div>${mockMessage(it, done)}</div>`;
}
function allReports() {
  const out = [];
  S.reports.forEach((doc, uid) => { (Array.isArray(doc.items) ? doc.items : []).forEach((r) => { if (r && r.id && r.state) out.push(Object.assign({}, r, { uid, ts: Number(r.ts) || 0 })); }); });
  return out.sort((a, b) => b.ts - a.ts);
}
const CH_ICON = { 'Text message': 'msg', 'Phone call': 'phone', Email: 'mail', 'Social media': 'chat', 'Website or ad': 'ext', 'In person': 'user' };
function reportItem(r) {
  const canRemove = r.uid === S.uid || S.isOwner;
  return `<div class="report-item"><div class="ri-ic">${icon(CH_ICON[r.channel] || 'alert')}</div><div class="stack-sm" style="gap:.3rem;min-width:0">
    <div class="meta"><span class="pill pill-danger">${esc(String(r.type || 'Scam').slice(0, 40))}</span><span>${icon('pin')} ${r.city ? esc(String(r.city).slice(0, 60)) + ', ' : ''}${esc(r.state)}</span><span>${ago(r.ts)}</span>${r.lost ? '<span class="pill pill-crit">Money lost</span>' : ''}</div>
    <p>${esc(String(r.summary || '').slice(0, 400))}</p>
    ${r.sender ? `<p class="small muted mono">Came from: ${esc(String(r.sender).slice(0, 80))}</p>` : ''}
    ${canRemove ? `<div><button class="btn btn-quiet btn-sm" type="button" data-act="remove-report" data-uid="${esc(r.uid)}" data-id="${esc(r.id)}">${icon('trash')} Remove</button></div>` : ''}
  </div></div>`;
}
function updateHomeActivity() {
  const el = $('#areaBody'); if (!el) return;
  const p = S.profile;
  if (!S.capsReady || (S.caps.db && !S.reportsReady)) { el.innerHTML = `<p class="muted"><span class="spinner"></span> Loading community reports…</p>`; return; }
  const all = allReports();
  const since = Date.now() - 30 * 864e5;
  const recent = all.filter((r) => r.ts >= since);
  const local = p.state ? recent.filter((r) => r.state === p.state) : recent;
  const byState = {}; recent.forEach((r) => { byState[r.state] = (byState[r.state] || 0) + 1; });
  const types = {}; local.forEach((r) => { types[r.type] = (types[r.type] || 0) + 1; });
  const top = Object.entries(types).sort((a, b) => b[1] - a[1])[0];
  const week = local.filter((r) => r.ts >= Date.now() - 7 * 864e5).length;
  const max = Math.max(1, ...Object.values(byState));
  const tiles = D.states.map((s) => {
    const n = byState[s.code] || 0; const t = n / max;
    const bg = n ? `background:color-mix(in srgb, var(--danger) ${Math.round(18 + 72 * t)}%, var(--surface-2));` : '';
    return `<div class="tile ${n && t > 0.45 ? 'hot' : ''} ${s.code === p.state ? 'me' : ''}" style="grid-column:${s.x + 1};grid-row:${s.y + 1};${bg}" title="${esc(s.name)}: ${n} report${n === 1 ? '' : 's'} in 30 days">${s.code}</div>`;
  }).join('');
  let list;
  if (local.length) list = local.slice(0, 6).map(reportItem).join('');
  else if (recent.length) list = `<p class="small muted">No reports in ${esc(stateName(p.state))} in the last 30 days. Latest from around the country:</p>` + recent.slice(0, 4).map(reportItem).join('');
  else list = `<div class="empty panel-flat">${icon('flag')}<p><b>No reports yet${p.state ? ' in ' + esc(stateName(p.state)) : ''}.</b><br>Seen a scam? Be the first to warn people near you.</p><button class="btn btn-primary btn-sm" type="button" data-act="report">${icon('flag')} Report a scam</button></div>`;
  const banner = !S.caps.db ? `<div class="banner warn">${icon('alert')}<span>You need to have an account to see community reports. <button class="btn btn-sm btn-ghost" type="button" data-act="connect-account">Connect account</button></span></div>` : '';
  el.innerHTML = `${banner}<div class="area-grid">
    <div class="stack">
      <div class="area-stats">
        <div class="st"><b>${local.length}</b><span>${p.state ? 'reports in ' + esc(p.state) : 'reports nationwide'}, 30 days</span></div>
        <div class="st"><b>${week}</b><span>this week</span></div>
        <div class="st"><b class="txt">${top ? esc(top[0]) : '—'}</b><span>most reported</span></div>
      </div>
      <div><div class="tile-map" role="img" aria-label="Map of community scam reports by state over the last 30 days">${tiles}</div>
      <div class="map-legend"><span>Fewer</span><span class="sw"><i style="background:var(--surface-2)"></i><i style="background:color-mix(in srgb, var(--danger) 35%, var(--surface-2))"></i><i style="background:color-mix(in srgb, var(--danger) 65%, var(--surface-2))"></i><i style="background:var(--danger)"></i></span><span>More reports</span>${p.state ? `<span>· Outlined: ${esc(stateName(p.state))}</span>` : ''}</div></div>
      <div class="ai-brief ai-only"><div class="btn-row" style="justify-content:space-between"><span class="ai-tag">${icon('spark')} AI area briefing</span><button class="btn btn-sm btn-ghost" type="button" data-act="ai-brief">${p.state ? 'Brief me on ' + esc(p.city || stateName(p.state)) : 'Brief me'}</button></div><div id="briefOut" class="prose small"></div></div>
    </div>
    <div class="area-feed"><h3>Latest community reports</h3>${list}</div>
  </div>`;
}
async function aiBrief() {
  if (!aiReady()) return;
  const p = S.profile; const out = $('#briefOut'); if (!out) return;
  const place = p.state ? (p.city ? `${p.city}, ${stateName(p.state)}` : stateName(p.state)) : 'the United States';
  out.innerHTML = '<p class="muted"><span class="spinner"></span> Putting together your briefing…</p>';
  const prompt = `Write a short scam briefing for someone in ${place}. Give exactly 4 bullet points (each starting with "- ") on scam types people there should watch for right now, based on widely reported nationwide patterns such as toll and DMV texts, impostor calls, delivery texts, AI voice clones, and job scams. Do NOT invent specific local incidents, statistics, dates, or news stories. ${p.state ? `You may mention the ${stateName(p.state)} Attorney General's consumer protection office as a place to report.` : ''} Keep it under 130 words, plain language, no headline.`;
  try {
    await S.caps.sample(prompt, { cache: { gcTime: 86400000 }, onText: ({ text }) => { const o = $('#briefOut'); if (o) o.innerHTML = md(text); } });
    const o = $('#briefOut'); if (o) o.insertAdjacentHTML('beforeend', '<p class="small muted">AI-generated from general trends. Check official sources for local alerts.</p>');
  } catch (e) { const o = $('#briefOut'); if (o) o.innerHTML = `<p class="muted">${esc(aiErr(e))}</p>`; }
}

/* ================= Detector ================= */
const MODES = [['text', 'msg', 'Text'], ['email', 'mail', 'Email'], ['call', 'phone', 'Phone call'], ['live', 'mic', 'Live call']];
function renderDetect() {
  view(`<div class="page-head"><div><p class="eyebrow">Scam detector</p><h1>Is it a scam?</h1><p>Paste or speak a text message, an email, or what a caller said. Hookline checks it for the tricks scammers use and tells you what to do next.</p></div></div>
  <div class="detect-grid">
    <section class="panel input-panel">
      <div class="seg" role="tablist" aria-label="What are you checking?">${MODES.map(([m, ic, l]) => `<button type="button" role="tab" aria-selected="${S.detMode === m}" class="${S.detMode === m ? 'on' : ''}" data-act="det-mode" data-mode="${m}">${icon(ic)} ${l}</button>`).join('')}</div>
      <div id="detInput"></div>
    </section>
    <section class="result-panel" id="detResult" aria-live="polite"></section>
  </div>
  <section class="section"><div class="section-head"><h2>Your recent checks</h2><p>Saved privately ${S.cloud ? 'to your account' : 'on this device'}.</p></div><div id="detHistory"></div></section>`);
  renderDetInput(); renderDetResult(); renderHistory();
  if (S.pendingScan) {
    const ps = S.pendingScan; S.pendingScan = null;
    const ta = $('#detText');
    if (ta) { ta.value = ps.text; if (ps.from && $('#detFrom')) $('#detFrom').value = ps.from; if (ps.subject && $('#detSubject')) $('#detSubject').value = ps.subject; updateCount(); runScan(); }
  }
}
function textForm(mode) {
  const isEmail = mode === 'email', isCall = mode === 'call';
  return `<form id="detForm" class="stack">
    <div class="field-row">
      <div class="field"><label for="detFrom">${isCall ? 'Caller ID' : 'From'} <span class="muted">(optional)</span></label><input id="detFrom" type="text" maxlength="120" placeholder="${isEmail ? 'sender@example.com' : isCall ? 'What your phone showed' : 'Phone number or name'}"></div>
      ${isEmail ? '<div class="field"><label for="detSubject">Subject <span class="muted">(optional)</span></label><input id="detSubject" type="text" maxlength="200"></div>' : ''}
    </div>
    <div class="field"><label for="detText">${isEmail ? 'Email text' : isCall ? 'What did the caller say?' : 'Message text'}</label>
      <div class="ta-wrap"><textarea id="detText" maxlength="8000" placeholder="${isCall ? 'e.g. They said they were from my bank and needed the code they just texted me…' : 'Paste the full message here…'}"></textarea>
        <div class="ta-tools"><button type="button" class="mic-btn" data-act="mic" aria-label="Speak instead of typing">${icon('mic')}</button><span class="count" id="detCount">0 / 8000</span></div></div>
    </div>
    <div id="dictateTip"></div>
    <div class="btn-row">
      <button class="btn btn-primary btn-lg" type="submit">${icon('shield')} Check for scams</button>
      <select id="detExample" class="ex-select" aria-label="Load an example"><option value="">Try an example…</option>${D.examples.map((x, i) => `<option value="${i}">${esc(x.label)}</option>`).join('')}</select>
      <button type="button" class="btn btn-quiet" data-act="det-clear">Clear</button>
    </div>
  </form>`;
}
function renderDetInput() {
  const el = $('#detInput'); if (!el) return;
  const m = S.detMode;
  if (m === 'text' || m === 'email') { el.innerHTML = textForm(m); return; }
  if (m === 'call') {
    const styleChips = `<div class="chips">${[['describe', 'Describe the call'], ['checklist', 'Answer quick questions']].map(([v, l]) => `<button type="button" class="chip ${S.callStyle === v ? 'on' : ''}" data-act="call-style" data-v="${v}">${l}</button>`).join('')}</div>`;
    if (S.callStyle === 'describe') { el.innerHTML = styleChips + textForm('call'); return; }
    el.innerHTML = styleChips + `<div class="qlist">${D.callQuestions.map((q) => `<div class="q-item"><p>${esc(q.q)}</p><div class="yn" data-q="${q.id}">${[['yes', 'Yes'], ['no', 'No'], ['unsure', 'Not sure']].map(([v, l]) => `<button type="button" class="${S.callAnswers[q.id] === v ? 'on' : ''}" data-act="yn" data-q="${q.id}" data-v="${v}">${l}</button>`).join('')}</div></div>`).join('')}</div>
      <div class="btn-row"><button class="btn btn-primary btn-lg" type="button" data-act="det-check">${icon('shield')} Check this call</button><button class="btn btn-quiet" type="button" data-act="det-clear">Reset</button></div>`;
    return;
  }
  el.innerHTML = `<div class="live-stage">
    <p class="muted">Put the call on speaker and start listening. Hookline transcribes what it hears and warns you the moment a scam tactic shows up.</p>
    <button class="live-btn" type="button" data-act="live-toggle">${icon('mic')} <span>Start listening</span></button>
    <div id="liveTip"></div>
    <div class="live-alerts" id="liveAlerts"></div>
    <div class="live-transcript" id="liveText"><span class="muted">The transcript appears here as the caller talks.</span></div>
  </div>`;
}
function updateCount() { const ta = $('#detText'), c = $('#detCount'); if (ta && c) c.textContent = ta.value.length + ' / 8000'; }
function renderDetResult(res = S.lastResult) {
  const el = $('#detResult'); if (!el) return;
  if (!res) {
    el.innerHTML = `<div class="panel result-empty"><div class="stack-sm"><span class="signal tone-caution" data-n="0" aria-hidden="true"><i></i><i></i><i></i><i></i></span><h3>Your result appears here</h3><p class="muted">Hookline looks for the tactics behind almost every scam:</p></div>
      <div class="check-grid">${[['bolt', 'Pressure & deadlines'], ['alert', 'Threats & fear'], ['lock', 'Requests for codes or info'], ['ext', 'Fake or risky links'], ['user', 'Impersonation'], ['key', 'Gift card & crypto demands'], ['phone', 'Suspicious senders'], ['chat', 'Secrecy & isolation']].map(([i, t]) => `<div>${icon(i)} ${t}</div>`).join('')}</div></div>`;
    return;
  }
  const T = TIERS[res.tier];
  el.innerHTML = `<div class="panel stack">
    <div class="verdict ${T.cls}">${signalBars(T.n)}<div><p class="stamp">${T.stamp}</p><p class="vtitle">${T.label}</p></div><div class="score"><b>${res.score}</b><span>scam risk / 100</span></div></div>
    <p>${esc(res.summary)}</p>
    ${res.hits.length ? `<div class="stack-sm"><h3>Red flags (${res.hits.length})</h3><ul class="flag-list">${res.hits.map((h) => `<li><span class="dot"></span><div><b>${esc(h.label)}</b>${h.why ? `<span>${esc(h.why)}</span>` : ''}</div><span class="pts">${severity(h.w)}</span></li>`).join('')}</ul></div>` : ''}
    ${res.goods.length ? `<div class="stack-sm"><h3>Good signs</h3><ul class="flag-list">${res.goods.map((g) => `<li class="good"><span class="dot"></span><div><b>${esc(g.label)}</b>${g.why ? `<span>${esc(g.why)}</span>` : ''}</div><span class="pts"></span></li>`).join('')}</ul></div>` : ''}
    ${res.text && res.ranges.length ? `<div class="stack-sm"><h3>The message, annotated</h3><div class="annotated">${annotate(res.text, res.ranges)}</div></div>` : ''}
    <div class="stack-sm"><h3>What to do now</h3><ol class="steps">${res.advice.map((a) => `<li>${esc(a)}</li>`).join('')}</ol></div>
    <div class="btn-row">
      <button class="btn btn-primary ai-only" type="button" data-act="deep-scan">${icon('spark')} Deep AI scan</button>
      <button class="btn btn-ghost" type="button" data-act="report-from-scan">${icon('flag')} Report to community</button>
      <button class="btn btn-quiet" type="button" data-act="copy-result">${icon('copy')} Copy</button>
    </div>
    <div id="aiOut"></div>
  </div>`;
}
function renderHistory() {
  const el = $('#detHistory'); if (!el) return;
  const sc = S.profile.scans;
  if (!sc.length) { el.innerHTML = `<div class="panel empty">${icon('shield')}<p>Checks you run show up here so you can look back at them.</p></div>`; return; }
  el.innerHTML = `<div class="hist">${sc.slice(0, 10).map((h) => { const T = TIERS[h.tier] || TIERS.safe; return `<div class="hist-row">${signalBars(T.n, 'sm ' + T.tone)}<p><b>${T.label}</b> · ${esc(h.snippet)}</p><time>${ago(h.ts)}</time></div>`; }).join('')}</div>
    <div class="btn-row" style="justify-content:flex-end;margin-top:.6rem"><button class="btn btn-sm btn-quiet" type="button" data-act="clear-history">${icon('trash')} Clear history</button></div>`;
}
function runScan() {
  const mode = S.detMode;
  let res, input;
  if (mode === 'call' && S.callStyle === 'checklist') {
    if (!Object.keys(S.callAnswers).length) { toast('Answer at least one question first.', 'alert'); return; }
    res = analyzeChecklist(S.callAnswers);
    const summary = D.callQuestions.map((q) => `${q.q} ${S.callAnswers[q.id] || 'no answer'}`).join('\n');
    input = { mode: 'call', text: 'Phone call checklist answers:\n' + summary, from: '', subject: '', snippet: 'Phone call checklist' };
  } else {
    const ta = $('#detText'); if (!ta) return;
    const text = ta.value.trim();
    if (text.length < 4) { toast('Paste or type the message first.', 'alert'); ta.focus(); return; }
    const from = ($('#detFrom') && $('#detFrom').value.trim()) || '';
    const subject = ($('#detSubject') && $('#detSubject').value.trim()) || '';
    res = analyze((subject ? subject + '\n' : '') + text, { mode, from });
    input = { mode, text, from, subject, snippet: text };
  }
  S.lastResult = res; S.lastInput = input; S.followTurns = [];
  renderDetResult();
  S.profile.scans.unshift({ id: newId(), tier: res.tier, score: res.score, mode, snippet: input.snippet.replace(/\s+/g, ' ').slice(0, 90), ts: Date.now() });
  S.profile.scans = S.profile.scans.slice(0, 15);
  award(5);
  grant('first-scan');
  renderHistory();
  if (window.innerWidth < 960) { const r = $('#detResult'); if (r) r.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
}
async function deepScan() {
  if (!aiReady() || !S.lastInput) return;
  const box = $('#aiOut'); if (!box) return;
  const inp = S.lastInput;
  const modeName = { text: 'text message', email: 'email', call: 'phone call', live: 'phone call transcript' }[inp.mode] || 'message';
  box.innerHTML = `<div class="ai-box"><div class="ai-head"><span class="ai-tag">${icon('spark')} Deep AI scan</span><button class="btn btn-sm btn-ghost" type="button" data-act="ai-stop">${icon('stop')} Stop</button></div><p class="muted"><span class="spinner"></span> Thinking it through. This can take up to a minute.</p></div>`;
  const ctl = S.aiCtl = new AbortController();
  const prompt = `You are Hookline, a careful fraud-prevention analyst helping an ordinary person decide whether a ${modeName} is a scam.

Consider the sender, links, requests for money, codes, or personal info, pressure tactics, impersonation, and whether it could plausibly be legitimate. Be honest when something looks legitimate.

Reply with ONLY a JSON object of this shape:
{"verdict":"scam" | "suspicious" | "legit","risk":0-100,"scamType":"short name, or None","summary":"two plain-language sentences","redFlags":[{"quote":"exact short quote from the message, or empty","why":"one sentence"}],"reassuring":["one sentence each"],"nextSteps":["up to 4 short imperative steps"]}

Sender: ${inp.from || 'not provided'}
${inp.subject ? 'Subject: ' + inp.subject + '\n' : ''}${modeName[0].toUpperCase() + modeName.slice(1)}:
"""
${inp.text.slice(0, 6000)}
"""`;
  try {
    const r = await S.caps.sample.json(prompt, { signal: ctl.signal });
    if (S.aiCtl === ctl) S.aiCtl = null;
    renderAI(r && typeof r === 'object' ? r : {});
  } catch (e) {
    if (S.aiCtl === ctl) S.aiCtl = null;
    const b = $('#aiOut'); if (!b) return;
    const msg = aiErr(e);
    b.innerHTML = msg ? `<div class="banner warn">${icon('alert')}<span>${esc(msg)}</span></div>` : '';
  }
}
function renderAI(r) {
  const box = $('#aiOut'); if (!box) return;
  const v = ['scam', 'suspicious', 'legit'].includes(r.verdict) ? r.verdict : 'suspicious';
  const vt = { scam: ['Scam', 'pill-danger'], suspicious: ['Suspicious', 'pill-warn'], legit: ['Probably legit', 'pill-safe'] }[v];
  const risk = clamp(Math.round(Number(r.risk) || 0), 0, 100);
  const arr = (x) => Array.isArray(x) ? x : [];
  const flags = arr(r.redFlags).slice(0, 8), reass = arr(r.reassuring).slice(0, 5), steps = arr(r.nextSteps).slice(0, 4);
  const type = r.scamType && String(r.scamType).toLowerCase() !== 'none' ? String(r.scamType) : vt[0];
  box.innerHTML = `<div class="ai-box">
    <div class="ai-head"><span class="ai-tag">${icon('spark')} Deep AI scan</span><span class="pill ${vt[1]}">${vt[0]} · ${risk}/100</span></div>
    <p class="ai-verdict">${esc(type.slice(0, 80))}</p>
    ${r.summary ? `<p>${esc(String(r.summary).slice(0, 600))}</p>` : ''}
    ${flags.length ? `<div><b>What stood out</b><ul>${flags.map((f) => `<li>${f && f.quote ? `<q>${esc(String(f.quote).slice(0, 160))}</q> ` : ''}${esc(String((f && f.why) || f || '').slice(0, 240))}</li>`).join('')}</ul></div>` : ''}
    ${reass.length ? `<div><b>Reassuring signs</b><ul>${reass.map((x) => `<li>${esc(String(x).slice(0, 240))}</li>`).join('')}</ul></div>` : ''}
    ${steps.length ? `<div><b>Next steps</b><ul>${steps.map((x) => `<li>${esc(String(x).slice(0, 240))}</li>`).join('')}</ul></div>` : ''}
    <div class="chat-log" id="chatLog"></div>
    <form id="followForm" class="followup"><input id="followQ" type="text" maxlength="300" placeholder="Ask a follow-up, like “What if I already clicked?”" aria-label="Ask a follow-up question"><button class="btn btn-primary" type="submit">Ask</button></form>
    <p class="small muted">AI can make mistakes. When money is involved, check with the company directly.</p>
  </div>`;
  const inp = S.lastInput;
  S.aiContext = `You are Hookline's scam-safety assistant. The person checked this ${inp.mode === 'email' ? 'email' : inp.mode === 'text' ? 'text message' : 'phone call'}:
"""
${inp.text.slice(0, 4000)}
"""
The analysis concluded: ${vt[0]}, risk ${risk}/100. ${String(r.summary || '').slice(0, 400)}
Answer their follow-up questions in under 120 words, plainly and calmly. Recommend verifying through official channels, and never ask them for personal information.`;
  S.followTurns = [];
}
async function followUp() {
  const inp = $('#followQ'); if (!inp || !aiReady()) return;
  const q = inp.value.trim(); if (!q) return;
  inp.value = '';
  if (!S.followTurns.length) S.followTurns.push({ role: 'user', content: S.aiContext });
  S.followTurns.push({ role: 'user', content: q });
  const log = $('#chatLog');
  const me = document.createElement('div'); me.className = 'me'; me.textContent = q; log.appendChild(me);
  const bot = document.createElement('div'); bot.className = 'bot'; bot.textContent = 'Thinking…'; log.appendChild(bot);
  try {
    const { text } = await S.caps.sample(S.followTurns.slice(-12), { cache: false, onText: ({ text: t }) => { bot.textContent = t; } });
    S.followTurns.push({ role: 'assistant', content: text });
  } catch (e) {
    bot.textContent = (e && e.text) || aiErr(e) || 'Stopped.';
    S.followTurns.pop();
  }
}

/* Speech: dictation and live call listening */
const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
let rec = null;
const LIVE_ALERTS = {
  payment: 'They asked for gift cards, crypto, or a wire. Hang up.',
  codeask: 'They want a verification code. Never share it.',
  creds: 'They’re asking for passwords or personal info.',
  remote: 'They want access to your device. Don’t install anything.',
  secrecy: 'They told you to keep quiet or stay on the line. That’s a scam tactic.',
  threat: 'They’re using threats to scare you.',
  family: 'A family emergency story. Ask for your safe word.'
};
function micBlockedTip(where) {
  const el = $('#' + where); if (!el) return;
  el.innerHTML = `<div class="dictate-tip">${icon('mic')}<span><b>The microphone is blocked here.</b> You can still talk instead of typing: click in the text box, then press <kbd>Win</kbd> + <kbd>H</kbd> on Windows, press <kbd>Fn</kbd> twice on a Mac, or tap the mic on your phone’s keyboard.</span></div>`;
}
function startDictation(btn) {
  if (rec) { stopListening(); return; }
  if (!SR) { micBlockedTip('dictateTip'); return; }
  const ta = $('#detText'); if (!ta) return;
  try { rec = new SR(); } catch (e) { rec = null; micBlockedTip('dictateTip'); return; }
  S.recMode = 'dictate';
  rec.lang = navigator.language || 'en-US'; rec.interimResults = true; rec.continuous = true;
  const base = ta.value ? ta.value.replace(/\s*$/, ' ') : '';
  let finalText = '';
  rec.onresult = (ev) => {
    let interim = '';
    for (let i = ev.resultIndex; i < ev.results.length; i++) { const r = ev.results[i]; if (r.isFinal) finalText += r[0].transcript + ' '; else interim += r[0].transcript; }
    ta.value = base + finalText + interim; updateCount();
  };
  rec.onerror = (ev) => { if (['not-allowed', 'service-not-allowed', 'audio-capture'].includes(ev.error)) micBlockedTip('dictateTip'); stopListening(); };
  rec.onend = () => stopListening();
  try { rec.start(); btn.classList.add('rec'); S.recBtn = btn; } catch (e) { rec = null; micBlockedTip('dictateTip'); }
}
function toggleLive() {
  if (rec && S.recMode === 'live') { stopListening(); return; }
  if (rec) stopListening();
  if (!SR) { micBlockedTip('liveTip'); return; }
  try { rec = new SR(); } catch (e) { rec = null; micBlockedTip('liveTip'); return; }
  S.recMode = 'live';
  S.live = { text: '', seen: new Set(), wanted: true };
  rec.lang = navigator.language || 'en-US'; rec.interimResults = true; rec.continuous = true;
  const btn = $('.live-btn'); if (btn) { btn.classList.add('on'); btn.querySelector('span').textContent = 'Listening… tap to stop'; }
  $('#liveText').innerHTML = '<span class="muted">Listening…</span>';
  rec.onresult = (ev) => {
    let interim = ''; let changed = false;
    for (let i = ev.resultIndex; i < ev.results.length; i++) { const r = ev.results[i]; if (r.isFinal) { S.live.text += r[0].transcript.trim() + '. '; changed = true; } else interim += r[0].transcript; }
    const box = $('#liveText'); if (box) { box.innerHTML = esc(S.live.text) + (interim ? `<span class="interim">${esc(interim)}</span>` : ''); box.scrollTop = box.scrollHeight; }
    if (changed) {
      const res = analyze(S.live.text, { mode: 'live' });
      S.lastResult = res; S.lastInput = { mode: 'live', text: S.live.text, from: '', subject: '', snippet: S.live.text };
      renderDetResult(res);
      res.ids.forEach((id) => {
        if (LIVE_ALERTS[id] && !S.live.seen.has(id)) {
          S.live.seen.add(id);
          const a = $('#liveAlerts'); if (a) a.insertAdjacentHTML('afterbegin', `<div class="live-alert">${icon('alert')}<span>${esc(LIVE_ALERTS[id])}</span></div>`);
        }
      });
    }
  };
  rec.onerror = (ev) => { if (['not-allowed', 'service-not-allowed', 'audio-capture'].includes(ev.error)) { S.live.wanted = false; micBlockedTip('liveTip'); } };
  rec.onend = () => { if (S.recMode === 'live' && S.live && S.live.wanted && rec) { try { rec.start(); return; } catch (e) { /* fall through */ } } stopListening(); };
  try { rec.start(); } catch (e) { micBlockedTip('liveTip'); stopListening(); }
}
function stopListening() {
  if (rec) { const r = rec; rec = null; try { r.onend = null; r.onresult = null; r.stop(); } catch (e) { /* ignore */ } }
  if (S.live) S.live.wanted = false;
  if (S.recBtn) { S.recBtn.classList.remove('rec'); S.recBtn = null; }
  if (S.recMode === 'live') {
    const btn = $('.live-btn'); if (btn) { btn.classList.remove('on'); btn.querySelector('span').textContent = 'Start listening'; }
    if (S.live && S.live.text.length > 10 && S.route === 'detect') {
      S.profile.scans.unshift({ id: newId(), tier: S.lastResult ? S.lastResult.tier : 'safe', score: S.lastResult ? S.lastResult.score : 0, mode: 'live', snippet: S.live.text.slice(0, 90), ts: Date.now() });
      S.profile.scans = S.profile.scans.slice(0, 15); saveProfile(); renderHistory();
    }
  }
  S.recMode = null;
}

/* ================= Learn ================= */
function interestScore(tags) { return (tags || []).filter((t) => S.profile.interests.includes(t)).length; }
function renderLearn() {
  if (S.article) return renderArticle(S.article);
  if (S.aiArticle) return renderSavedAi(S.aiArticle);
  const cats = ['All', 'Saved'].concat(Array.from(new Set(D.articles.map((a) => a.cat))));
  view(`<div class="page-head"><div><p class="eyebrow">Learn</p><h1>Scam awareness library</h1><p>Short, practical reads by Hookline’s AI editor, based on public FTC and FBI guidance. Need something specific? Have the AI write a new article on any topic.</p></div></div>
  <section class="stack"><div class="section-head"><h2>Trend desk</h2><p>Recent warnings from federal agencies</p></div><div class="desk">${D.alerts.map(alertCard).join('')}</div></section>
  <section class="section"><div class="section-head"><h2>Articles</h2></div>
    <div class="filters"><div class="chips" id="learnCats">${cats.map((c) => `<button type="button" class="chip ${S.learnCat === c ? 'on' : ''}" data-act="learn-cat" data-v="${esc(c)}">${esc(c)}</button>`).join('')}</div>
    <div class="search">${icon('search')}<input id="learnSearch" type="search" placeholder="Search articles" value="${esc(S.learnQuery)}" aria-label="Search articles"></div></div>
    <div class="art-grid" id="artGrid"></div>
  </section>
  <section class="section ai-writer ai-only">
    <div class="stack-sm"><span class="ai-tag">${icon('spark')} AI article writer</span><h2>Write me an article about…</h2><p class="muted">Pick a topic or type your own. Hookline drafts a fresh, plain-language article in under a minute.</p></div>
    <form id="aiWriteForm" class="row"><label class="sr-only" for="aiTopic">Article topic</label><input id="aiTopic" type="text" maxlength="140" placeholder="e.g. Fake concert ticket sellers on social media"><button class="btn btn-primary" type="submit">${icon('spark')} Write it</button></form>
    <div class="chips">${['Crypto ATM scams', 'Fake charity calls after disasters', 'Rental listing scams', 'Student loan forgiveness scams', 'Fake Marketplace buyers', 'Medicare enrollment calls'].map((t) => `<button type="button" class="chip" data-act="ai-topic" data-v="${esc(t)}">${esc(t)}</button>`).join('')}</div>
    <div id="aiWriteOut"></div>
  </section>
  <section class="section" id="myAiArts"></section>`);
  renderArtGrid(); renderMyAi();
}
function renderArtGrid() {
  const el = $('#artGrid'); if (!el) return;
  const q = S.learnQuery.toLowerCase(); const p = S.profile;
  let list = D.articles.filter((a) => S.learnCat === 'All' || (S.learnCat === 'Saved' ? p.savedArticles.includes(a.id) : a.cat === S.learnCat));
  if (q) list = list.filter((a) => (a.title + ' ' + a.dek + ' ' + a.body).toLowerCase().includes(q));
  if (S.learnCat === 'All' && !q) list = list.slice().sort((a, b) => interestScore(b.tags) - interestScore(a.tags));
  if (!list.length) { el.innerHTML = `<div class="panel empty" style="grid-column:1/-1">${icon('book')}<p>${S.learnCat === 'Saved' ? 'Articles you save show up here.' : 'No articles match that search.'}</p></div>`; return; }
  el.innerHTML = list.map((a) => `<button class="art-card" type="button" data-act="open-article" data-id="${a.id}"><div class="top"><span class="pill pill-accent">${esc(a.cat)}</span>${p.savedArticles.includes(a.id) ? icon('bookmark') : ''}</div><h3>${esc(a.title)}</h3><p>${esc(a.dek)}</p><div class="foot"><span>${a.mins} min read</span>${p.readArticles.includes(a.id) ? `<span class="done">${icon('check')} Finished</span>` : ''}</div></button>`).join('');
}
function renderMyAi() {
  const el = $('#myAiArts'); if (!el) return;
  const list = S.profile.aiArticles;
  if (!list.length) { el.innerHTML = ''; return; }
  el.innerHTML = `<div class="section-head"><h2>Your AI library</h2><p>Articles you generated and saved</p></div><div class="art-grid">${list.map((a) => `<button class="art-card" type="button" data-act="open-ai-article" data-id="${esc(a.id)}"><div class="top"><span class="ai-tag">${icon('spark')} AI article</span></div><h3>${esc(a.title)}</h3><div class="foot"><span>Saved ${ago(a.ts)}</span></div></button>`).join('')}</div>`;
}
function renderArticle(id) {
  const a = D.articles.find((x) => x.id === id);
  if (!a) { S.article = null; renderLearn(); return; }
  const p = S.profile; const saved = p.savedArticles.includes(id), read = p.readArticles.includes(id);
  const next = D.articles.filter((x) => x.id !== id).sort((x, y) => (y.cat === a.cat) - (x.cat === a.cat) || interestScore(y.tags) - interestScore(x.tags)).slice(0, 3);
  view(`<div class="reader-progress" id="readProg"></div><article class="reader">
    <button class="btn btn-quiet" type="button" data-act="back-learn" style="justify-self:start">${icon('arrowL')} All articles</button>
    <header class="reader-head"><span class="pill pill-accent" style="justify-self:start">${esc(a.cat)}</span><h1>${esc(a.title)}</h1><p class="dek">${esc(a.dek)}</p>
      <div class="reader-meta"><span>${a.mins} min read</span><span class="ai-tag">${icon('spark')} Written with AI · Hookline editorial</span>
      <button class="btn btn-sm ${saved ? 'btn-primary' : 'btn-ghost'}" type="button" data-act="save-article" data-id="${a.id}">${icon('bookmark')} ${saved ? 'Saved' : 'Save'}</button></div></header>
    <div class="prose">${md(a.body)}</div>
    <div class="reader-end">${read ? `<span class="pill pill-safe">${icon('check')} Finished</span>` : '<span>Done reading?</span>'}<div class="btn-row">${read ? '' : `<button class="btn btn-primary" type="button" data-act="finish-article" data-id="${a.id}">${icon('check')} Mark as finished · +15 XP</button>`}<a class="btn btn-ghost" href="#quiz">Test yourself</a></div></div>
    <div class="stack-sm"><h3>Read next</h3><div class="list-links">${next.map(artLink).join('')}</div></div>
  </article>`);
}
function renderSavedAi(id) {
  const a = S.profile.aiArticles.find((x) => x.id === id);
  if (!a) { S.aiArticle = null; renderLearn(); return; }
  view(`<div class="reader-progress" id="readProg"></div><article class="reader">
    <button class="btn btn-quiet" type="button" data-act="back-learn" style="justify-self:start">${icon('arrowL')} Library</button>
    <header class="reader-head"><span class="ai-tag">${icon('spark')} AI-generated article</span><h1>${esc(a.title)}</h1><div class="reader-meta"><span>Saved ${ago(a.ts)}</span><button class="btn btn-sm btn-ghost" type="button" data-act="del-ai-article" data-id="${esc(a.id)}">${icon('trash')} Delete</button></div></header>
    <div class="prose">${md(a.body)}</div>
    <p class="small muted">AI-generated. Double-check important details with official sources such as ReportFraud.ftc.gov.</p>
  </article>`);
}
function splitTitle(text) {
  const lines = String(text).split(/\r?\n/);
  const i = lines.findIndex((l) => l.trim());
  if (i >= 0 && /^#\s+/.test(lines[i].trim())) return { title: lines[i].trim().replace(/^#\s+/, '').slice(0, 140), body: lines.slice(i + 1).join('\n').trim() };
  return { title: '', body: String(text).trim() };
}
async function aiWrite(topicArg) {
  if (!aiReady()) return;
  const topicEl = $('#aiTopic');
  const topic = String(topicArg || (topicEl && topicEl.value) || '').trim();
  if (topic.length < 3) { toast('Type a topic first.', 'alert'); return; }
  if (topicEl) topicEl.value = topic;
  const out = $('#aiWriteOut'); if (!out) return;
  if (S.aiCtl) { try { S.aiCtl.abort(); } catch (e) { /* ignore */ } }
  const ctl = S.aiCtl = new AbortController();
  out.innerHTML = `<div class="ai-out stack"><div class="btn-row" style="justify-content:space-between"><span class="ai-tag" id="aiWriteState">${icon('spark')} Writing…</span><span class="btn-row" id="aiWriteBtns"><button class="btn btn-sm btn-ghost" type="button" data-act="ai-stop">${icon('stop')} Stop</button></span></div><div class="prose" id="aiProse"><p class="muted"><span class="spinner"></span> Drafting your article. This usually takes 20 to 60 seconds.</p></div></div>`;
  const prompt = `Write a scam-awareness article for a general audience about: "${topic}".
Format: the first line is "# " followed by a short headline. Then 4 to 6 short sections with "## " subheadings, plain paragraphs, and "- " bullet lists where they help. 350 to 500 words. Warm, plain language with no jargon. End with a "## What to do" section. Mention official resources like ReportFraud.ftc.gov only where relevant. Don't invent statistics, dates, or news events; describe trends generally.`;
  const paint = (text) => { const el = $('#aiProse'); if (!el) return; const { title, body } = splitTitle(text); el.innerHTML = (title ? `<h2 style="font-size:1.6rem">${esc(title)}</h2>` : '') + md(body); };
  try {
    const { text, truncated } = await S.caps.sample(prompt, { signal: ctl.signal, cache: false, onText: ({ text: t }) => paint(t) });
    if (S.aiCtl === ctl) S.aiCtl = null;
    paint(text);
    const { title, body } = splitTitle(text);
    S.lastAiArticle = { id: newId(), title: title || topic, body: body.slice(0, 9000), ts: Date.now() };
    const st = $('#aiWriteState'); if (st) st.innerHTML = `${icon('spark')} AI article${truncated ? ' (cut short)' : ''}`;
    const b = $('#aiWriteBtns'); if (b) b.innerHTML = `<button class="btn btn-sm btn-primary" type="button" data-act="ai-save">${icon('bookmark')} Save to my library</button>`;
  } catch (e) {
    if (S.aiCtl === ctl) S.aiCtl = null;
    const msg = aiErr(e);
    const el = $('#aiProse');
    if (el && !(e && e.text)) el.innerHTML = msg ? `<p class="muted">${esc(msg)}</p>` : '<p class="muted">Stopped.</p>';
    const st = $('#aiWriteState'); if (st) st.innerHTML = `${icon('spark')} ${e && e.code === 'cancelled' ? 'Stopped' : 'Interrupted'}`;
    const b = $('#aiWriteBtns'); if (b) b.innerHTML = '';
  }
}

/* ================= Quiz ================= */
function clearQuizTimer() { if (S.qz && S.qz.timer) { clearInterval(S.qz.timer); S.qz.timer = null; } }
function renderQuiz() {
  if (S.qz && S.qz.loading) return renderQuizLoading();
  if (S.qz && S.qz.done) return renderQuizResults();
  if (S.qz) return renderQuestion();
  const q = S.profile.quiz;
  const acc = q.answered ? Math.round(100 * q.correct / q.answered) + '%' : '—';
  view(`<div class="quiz-wrap">
    <div class="page-head"><div><p class="eyebrow">Quiz</p><h1>Scam or legit?</h1><p>Read real-world style messages and decide. After each answer, Hookline highlights exactly which clues gave it away.</p></div></div>
    <div class="stat-strip"><div><b>${q.rounds}</b><span>rounds played</span></div><div><b>${acc}</b><span>accuracy</span></div><div><b>${q.best}/10</b><span>best classic round</span></div><div><b>${q.bestStreak}</b><span>best streak</span></div></div>
    <div class="mode-cards">
      <button class="mode-card" type="button" data-act="quiz-start" data-mode="classic">${icon('quiz', 'big')}<h3>Classic round</h3><p>10 messages from the Hookline bank: texts, emails, and calls.</p><span class="pill pill-accent">+10 XP per right answer</span></button>
      <button class="mode-card" type="button" data-act="quiz-start" data-mode="speed">${icon('bolt', 'big')}<h3>Lightning round</h3><p>5 messages, 15 seconds each. Trust your gut.</p><span class="pill">Timed</span></button>
      <button class="mode-card ai-only" type="button" data-act="quiz-start" data-mode="ai">${icon('spark', 'big')}<h3>Fresh AI round</h3><p>5 brand-new messages written by AI, different every time.</p><span class="pill pill-accent">New every time</span></button>
    </div>
    <p class="kbd-hint">Tip: press <kbd>S</kbd> for scam, <kbd>L</kbd> for legit, and <kbd>Enter</kbd> for the next message.</p>
  </div>`);
}
function pickClassic(n) {
  const scams = shuffle(D.quiz.filter((x) => x.scam)), legit = shuffle(D.quiz.filter((x) => !x.scam));
  const nl = Math.max(2, Math.round(n * 0.4));
  return shuffle(scams.slice(0, n - nl).concat(legit.slice(0, nl)));
}
function quizStart(mode) {
  if (mode === 'ai') return startAIQuiz();
  const items = mode === 'speed' ? pickClassic(5) : pickClassic(10);
  S.qz = { mode, items, i: 0, answers: [], streak: 0, done: false, timer: null };
  renderQuestion();
}
function renderQuizLoading() {
  view(`<div class="quiz-wrap"><div class="panel empty" style="padding:3rem 1rem"><span class="spinner" style="width:2rem;height:2rem"></span><h2>Writing fresh messages…</h2><p>The AI is drafting 5 new texts, emails, and calls. This takes 10 to 40 seconds.</p><button class="btn btn-ghost" type="button" data-act="quiz-quit">Cancel</button></div></div>`);
}
function toQuizItem(o) {
  if (!o || typeof o !== 'object') return null;
  const msg = String(o.msg || '').replace(/[[\]|]/g, ' ').slice(0, 700).trim();
  if (msg.length < 10) return null;
  const scam = o.scam === true || o.scam === 'true';
  const found = [];
  (Array.isArray(o.flags) ? o.flags : []).map((f) => String(f).replace(/[[\]|]/g, ' ').trim()).filter((f) => f.length >= 3 && f.length < 160).forEach((f) => {
    const i = msg.indexOf(f);
    if (i >= 0 && !found.some((x) => i < x.e && i + f.length > x.s)) found.push({ s: i, e: i + f.length });
  });
  found.sort((a, b) => a.s - b.s);
  let marked = '', pos = 0;
  found.forEach((r) => { marked += msg.slice(pos, r.s) + `[[${scam ? '' : '+'}${msg.slice(r.s, r.e)}|${scam ? 'A clue this is a scam' : 'A sign this is legitimate'}]]`; pos = r.e; });
  marked += msg.slice(pos);
  return { ch: ['text', 'email', 'call'].includes(o.ch) ? o.ch : 'text', from: String(o.from || 'Unknown').slice(0, 60), subject: String(o.subject || '').slice(0, 120), msg: marked, scam, type: String(o.type || '').slice(0, 60), why: String(o.why || '').slice(0, 400) };
}
async function startAIQuiz() {
  if (!aiReady()) return;
  const ctl = S.aiCtl = new AbortController();
  S.qz = { mode: 'ai', loading: true };
  renderQuizLoading();
  const prompt = `Create 5 realistic practice messages for a scam-spotting quiz. Use 3 scams and 2 legitimate messages in random order, mixing text messages, emails, and phone call transcripts. Use fictional names, fictional companies, and 555 phone numbers. Vary the scam types (for example delivery, bank, job, family emergency, investment, tech support, marketplace).
Reply with ONLY a JSON array of 5 objects shaped like:
{"ch":"text" | "email" | "call","from":"sender","subject":"email subject or empty","msg":"the message, 1 to 4 sentences","scam":true | false,"type":"short label","why":"one or two sentence explanation","flags":["exact short quotes copied from msg that are the key clues"]}`;
  try {
    const arr = await S.caps.sample.json(prompt, { signal: ctl.signal, cache: false });
    if (S.aiCtl === ctl) S.aiCtl = null;
    const items = (Array.isArray(arr) ? arr : []).map(toQuizItem).filter(Boolean).slice(0, 5);
    if (items.length < 3) throw { code: 'invalid_json' };
    if (S.route !== 'quiz' || !S.qz || !S.qz.loading) return;
    S.qz = { mode: 'ai', items, i: 0, answers: [], streak: 0, done: false, timer: null };
    renderQuestion();
  } catch (e) {
    if (S.aiCtl === ctl) S.aiCtl = null;
    const msg = aiErr(e); if (msg) toast(msg, 'alert');
    S.qz = null; if (S.route === 'quiz') renderQuiz();
  }
}
function renderQuestion() {
  const qz = S.qz; const it = qz.items[qz.i]; const ans = qz.answers[qz.i]; const n = qz.items.length;
  const dots = qz.items.map((_, k) => `<i class="${qz.answers[k] ? (qz.answers[k].ok ? 'ok' : 'bad') : k === qz.i ? 'cur' : ''}"></i>`).join('');
  let below;
  if (ans) {
    const { clues } = parseMarked(it.msg, true);
    below = `<div class="feedback ${ans.ok ? 'ok' : 'bad'}"><h3>${icon(ans.ok ? 'check' : 'x')} ${ans.ok ? 'Correct!' : ans.timeout ? 'Time’s up' : 'Not quite'}</h3>
      <p><b>This one is ${it.scam ? 'a scam' : 'legit'}</b>${it.type ? ' · ' + esc(it.type) : ''}. ${esc(it.why)}</p>
      ${clues.length ? `<ul class="clue-list">${clues.map((c) => `<li class="${c.good ? 'good' : ''}"><span class="dot"></span><span><b>“${esc(c.text)}”</b> ${esc(c.why)}</span></li>`).join('')}</ul>` : ''}</div>
      <button class="btn btn-primary btn-lg btn-block" type="button" data-act="quiz-next" id="quizNext">${qz.i === n - 1 ? 'See results' : 'Next message'} ${icon('arrowR')}</button>`;
  } else {
    below = `<div class="answer-row"><button class="btn btn-danger" type="button" data-act="quiz-answer" data-v="scam">${icon('alert')} It’s a scam</button><button class="btn btn-safe" type="button" data-act="quiz-answer" data-v="legit">${icon('check')} It’s legit</button></div>`;
  }
  view(`<div class="quiz-wrap">
    <div class="q-top"><button class="btn btn-quiet" type="button" data-act="quiz-quit">${icon('x')} Quit</button><div class="q-dots" aria-hidden="true">${dots}</div><span class="mono small">${qz.i + 1} / ${n}${qz.mode === 'speed' && !ans ? ' · <b id="qTimer">15</b>s' : ''}</span></div>
    ${mockMessage(it, !!ans)}
    ${below}
  </div>`);
  if (ans) { const b = $('#quizNext'); if (b) b.focus({ preventScroll: true }); }
  if (qz.mode === 'speed' && !ans) {
    clearQuizTimer();
    const deadline = Date.now() + 15000;
    qz.timer = setInterval(() => {
      const left = Math.max(0, Math.ceil((deadline - Date.now()) / 1000));
      const t = $('#qTimer'); if (t) t.textContent = left;
      if (left <= 0) quizAnswer(null, true);
    }, 250);
  }
}
function quizAnswer(v, timeout) {
  const qz = S.qz; if (!qz || qz.done || !qz.items || qz.answers[qz.i]) return;
  clearQuizTimer();
  const it = qz.items[qz.i];
  const ok = !timeout && v === (it.scam ? 'scam' : 'legit');
  qz.answers[qz.i] = { v, ok, timeout: !!timeout };
  const q = S.profile.quiz;
  q.answered++;
  if (ok) { q.correct++; qz.streak++; } else qz.streak = 0;
  q.streak = qz.streak; q.bestStreak = Math.max(q.bestStreak, qz.streak);
  if (ok) award(10); else saveProfile();
  if (qz.streak >= 5) grant('streak-5');
  renderQuestion();
}
function quizNext() {
  const qz = S.qz; if (!qz || !qz.answers[qz.i]) return;
  if (qz.i < qz.items.length - 1) { qz.i++; renderQuestion(); window.scrollTo(0, 0); return; }
  qz.done = true;
  const score = qz.answers.filter((a) => a.ok).length;
  const q = S.profile.quiz; q.rounds++;
  if (qz.mode === 'classic') { q.best = Math.max(q.best, score); if (score === 10) grant('quiz-ace'); }
  saveProfile();
  renderQuizResults();
}
function renderQuizResults() {
  const qz = S.qz; const n = qz.items.length; const score = qz.answers.filter((a) => a.ok).length; const pct = score / n;
  const C = 2 * Math.PI * 52;
  const msg = pct === 1 ? 'Perfect. Scammers would have a hard time with you.' : pct >= 0.8 ? 'Sharp eye. You caught almost everything.' : pct >= 0.5 ? 'Solid start. Review the clues below to level up.' : 'Scams are designed to fool people. Read the clues below and try again.';
  view(`<div class="quiz-wrap"><div class="q-results">
    <svg class="score-ring" viewBox="0 0 120 120" role="img" aria-label="${score} of ${n} correct"><circle cx="60" cy="60" r="52" fill="none" stroke="var(--line)" stroke-width="10"/><circle cx="60" cy="60" r="52" fill="none" stroke="var(--accent)" stroke-width="10" stroke-linecap="round" stroke-dasharray="${(C * pct).toFixed(1)} ${C.toFixed(1)}" transform="rotate(-90 60 60)"/><text x="60" y="58" text-anchor="middle" font-family="IBM Plex Mono, monospace" font-size="26" font-weight="600" fill="var(--ink)">${score}/${n}</text><text x="60" y="78" text-anchor="middle" font-size="10" fill="var(--ink-2)">correct</text></svg>
    <h2>${esc(msg)}</h2>
    <p class="muted">${qz.mode === 'ai' ? 'Fresh AI round' : qz.mode === 'speed' ? 'Lightning round' : 'Classic round'} · +${score * 10} XP</p>
    <div class="btn-row" style="justify-content:center"><button class="btn btn-primary btn-lg" type="button" data-act="quiz-start" data-mode="${qz.mode}">${icon('refresh')} Play again</button><button class="btn btn-ghost btn-lg" type="button" data-act="quiz-home">Quiz home</button></div>
  </div>
  <div class="panel stack-sm"><h3>Your answers</h3><ul class="clue-list">${qz.items.map((it, k) => `<li class="${qz.answers[k] && qz.answers[k].ok ? 'good' : ''}"><span class="dot"></span><span><b>${qz.answers[k] && qz.answers[k].ok ? 'Right' : 'Missed'}:</b> ${esc(it.from)} · ${it.scam ? 'Scam' : 'Legit'}${it.type ? ' (' + esc(it.type) + ')' : ''}</span></li>`).join('')}</ul></div></div>`);
}

/* ================= Feed (shorts) ================= */
const P = { id: null, i: 0, timer: null, paused: false, el: null, obs: null };
function rankedShorts() {
  const p = S.profile; const seed = hashStr(todayKey());
  return seededShuffle(D.shorts, seed).map((s, k) => ({ s, sc: interestScore(s.tags) * 3 - (p.watched.includes(s.id) ? 4 : 0) + (p.liked.includes(s.id) ? 1 : 0) - k * 0.1 }))
    .sort((a, b) => b.sc - a.sc).map((x) => x.s);
}
function feedList() { return S.feedTab === 'saved' ? D.shorts.filter((s) => S.profile.saved.includes(s.id)) : rankedShorts(); }
function sceneDur(sc) { const words = String(sc.say || '').split(/\s+/).filter(Boolean).length; return clamp(1400 + words * 400, 3400, 8500); }
function sceneHtml(sc, s) {
  switch (sc.k) {
    case 'hook': return `<div class="sc"><p class="sc-kicker">${esc(s.title)}</p><h3>${esc(sc.big)}</h3></div>`;
    case 'sms': return `<div class="sc"><p class="sc-kicker">New message</p><div class="sc-phone"><p class="ph-from">${esc(sc.from)}</p><div class="ph-msg">${esc(sc.text)}</div></div></div>`;
    case 'call': return `<div class="sc"><div class="sc-call"><div class="ring">${icon('phone')}</div><p class="who">${esc(sc.caller)}</p><p class="sc-kicker">Incoming call</p><p class="line">${esc(sc.line)}</p></div></div>`;
    case 'list': return `<div class="sc"><p class="sc-kicker">${esc(sc.title)}</p><ul class="sc-list">${sc.items.map((t) => `<li>${icon('alert')}<span>${esc(t)}</span></li>`).join('')}</ul></div>`;
    case 'stat': return `<div class="sc sc-stat"><b>${esc(sc.value)}</b><p class="sub">${esc(sc.label)}</p></div>`;
    case 'rule': return `<div class="sc"><p class="sc-kicker">${esc(sc.pre)}</p><h3>${esc(sc.big)}</h3><p class="sub">${esc(sc.sub)}</p></div>`;
    default: return `<div class="sc sc-end">${hookMark('mark')}<h3>Pause. Verify. Then act.</h3>${sc.say && sc.say !== 'Pause. Verify. Then act.' ? `<p class="sub">${esc(sc.say)}</p>` : ''}</div>`;
  }
}
function shortHtml(s) {
  const p = S.profile; const liked = p.liked.includes(s.id), saved = p.saved.includes(s.id);
  const tag = (D.interests.find((i) => i.id === s.tags[0]) || {}).label || 'Scam awareness';
  return `<div class="short-slot" data-id="${s.id}">
    <div class="short paused" style="--h:${s.hue}" data-act="short-tap" data-id="${s.id}" role="group" aria-label="${esc(s.title)}">
      <div class="short-prog">${s.scenes.map(() => '<span><i></i></span>').join('')}</div>
      <div class="short-top"><span class="logo">${hookMark('ic')}</span> Hookline · ${esc(tag)}</div>
      ${s.scenes.map((sc) => sceneHtml(sc, s)).join('')}
      <div class="short-bottom"><b>${esc(s.title)}</b><a href="https://www.youtube.com/results?search_query=${encodeURIComponent(s.yt)}" target="_blank" rel="noopener noreferrer">${icon('ext')} More shorts on YouTube</a></div>
      <div class="short-paused"><span>${icon('tri')}</span></div>
    </div>
    <div class="short-actions">
      <button class="act-btn ${liked ? 'on' : ''}" type="button" data-act="like" data-id="${s.id}" aria-pressed="${liked}"><span class="circ">${icon('heart')}</span><span>Like</span></button>
      <button class="act-btn save ${saved ? 'on' : ''}" type="button" data-act="save-short" data-id="${s.id}" aria-pressed="${saved}"><span class="circ">${icon('bookmark')}</span><span>Save</span></button>
      <button class="act-btn" type="button" data-act="share-short" data-id="${s.id}"><span class="circ">${icon('share')}</span><span>Share</span></button>
      <button class="act-btn" type="button" data-act="discuss-short" data-id="${s.id}"><span class="circ">${icon('chat')}</span><span>Discuss</span></button>
    </div>
  </div>`;
}
function renderFeed() {
  const list = feedList();
  view(`<div class="feed-page">
    <div class="feed-bar"><div class="stack-sm" style="gap:.15rem"><p class="eyebrow">My feed</p><h2>Scam-awareness shorts</h2></div>
      <div class="btn-row"><div class="seg" role="tablist" aria-label="Feed">${[['foryou', 'For you'], ['saved', 'Saved (' + S.profile.saved.length + ')']].map(([v, l]) => `<button type="button" role="tab" aria-selected="${S.feedTab === v}" class="${S.feedTab === v ? 'on' : ''}" data-act="feed-tab" data-v="${v}">${l}</button>`).join('')}</div>
      <button class="btn btn-ghost btn-sm" type="button" data-act="sound" id="soundBtn">${icon(S.sound ? 'vol' : 'mute')} ${S.sound ? 'Narration on' : 'Narration off'}</button></div></div>
    ${list.length ? `<div class="feed-scroller" id="feedScroller">${list.map(shortHtml).join('')}</div><p class="small muted" style="text-align:center">Scroll for the next short. Tap the right side to skip ahead, the left side to go back, the middle to pause.</p>` : `<div class="panel empty">${icon('bookmark')}<p><b>No saved shorts yet.</b><br>Tap Save on any short to keep it here.</p><button class="btn btn-primary" type="button" data-act="feed-tab" data-v="foryou">Browse shorts</button></div>`}
  </div>`);
  setupFeedObserver();
}
function setupFeedObserver() {
  const sc = $('#feedScroller'); if (!sc) return;
  if (P.obs) P.obs.disconnect();
  P.obs = new IntersectionObserver((entries) => {
    entries.forEach((en) => { if (en.isIntersecting && en.intersectionRatio >= 0.6) playShort(en.target.dataset.id); });
  }, { root: sc, threshold: [0.6] });
  $$('.short-slot', sc).forEach((el) => P.obs.observe(el));
  if (S.feedJump) {
    const el = sc.querySelector(`.short-slot[data-id="${S.feedJump}"]`);
    if (el && sc.firstElementChild) sc.scrollTop = el.offsetTop - sc.firstElementChild.offsetTop;
    S.feedJump = null;
  }
}
function speak(text) {
  if (!S.sound || !text || !('speechSynthesis' in window)) return;
  try { window.speechSynthesis.cancel(); const u = new SpeechSynthesisUtterance(text); u.rate = 1.02; u.lang = 'en-US'; window.speechSynthesis.speak(u); } catch (e) { /* speech unavailable */ }
}
function hush() { try { if ('speechSynthesis' in window) window.speechSynthesis.cancel(); } catch (e) { /* ignore */ } }
function playShort(id) {
  if (P.id === id && !P.paused) return;
  stopShort();
  P.id = id; P.i = 0; P.paused = false;
  P.el = $(`.short-slot[data-id="${id}"] .short`);
  if (P.el) showScene(0);
}
function showScene(i) {
  const s = D.shorts.find((x) => x.id === P.id); if (!s || !P.el) return;
  clearTimeout(P.timer);
  P.i = i;
  $$('.sc', P.el).forEach((el, k) => el.classList.toggle('active', k === i));
  const segs = $$('.short-prog span', P.el);
  const dur = sceneDur(s.scenes[i]);
  segs.forEach((sg, k) => { sg.classList.remove('run'); sg.classList.toggle('done', k < i); });
  const cur = segs[i];
  if (cur) { cur.style.setProperty('--dur', dur + 'ms'); void cur.offsetWidth; cur.classList.add('run'); }
  P.el.classList.remove('paused'); P.paused = false;
  speak(s.scenes[i].say);
  P.timer = setTimeout(nextScene, dur);
}
function nextScene() {
  const s = D.shorts.find((x) => x.id === P.id); if (!s) return;
  if (P.i < s.scenes.length - 1) showScene(P.i + 1);
  else { markWatched(s.id); showScene(0); }
}
function prevScene() { showScene(Math.max(0, P.i - 1)); }
function togglePause() {
  if (!P.el) return;
  if (P.paused) { showScene(P.i); return; }
  clearTimeout(P.timer); P.paused = true; P.el.classList.add('paused'); hush();
}
function stopShort() {
  clearTimeout(P.timer); hush();
  if (P.el) { P.el.classList.add('paused'); $$('.short-prog span', P.el).forEach((sg) => sg.classList.remove('run')); }
  P.id = null; P.el = null; P.paused = false;
}
function stopFeed() { stopShort(); if (P.obs) { P.obs.disconnect(); P.obs = null; } }
function markWatched(id) {
  if (S.profile.watched.includes(id)) return;
  S.profile.watched.push(id);
  award(3);
  if (S.profile.watched.length >= 8) grant('watcher');
}
function toggleList(list, id) { const i = list.indexOf(id); if (i >= 0) list.splice(i, 1); else list.push(id); return i < 0; }

/* ================= Community ================= */
const catLabel = (id) => (D.forumCats.find((c) => c.id === id) || { label: 'General' }).label;
function buildThreads() {
  const posts = [], replies = {}, helpful = {};
  S.forum.forEach((doc, uid) => {
    if (!doc || typeof doc !== 'object') return;
    (Array.isArray(doc.posts) ? doc.posts : []).forEach((p) => {
      if (p && p.id && p.title) posts.push({ id: String(p.id), uid, key: uid + '~' + p.id, cat: String(p.cat || 'general'), title: String(p.title).slice(0, 120), body: String(p.body || '').slice(0, 2000), ts: Number(p.ts) || 0 });
    });
    (Array.isArray(doc.replies) ? doc.replies : []).forEach((r) => {
      if (r && r.id && r.parent) (replies[r.parent] = replies[r.parent] || []).push({ id: String(r.id), uid, key: uid + '~' + r.id, body: String(r.body || '').slice(0, 1200), ts: Number(r.ts) || 0 });
    });
    (Array.isArray(doc.helpful) ? doc.helpful : []).forEach((k) => { helpful[k] = (helpful[k] || 0) + 1; });
  });
  posts.forEach((p) => {
    p.replies = (replies[p.key] || []).sort((a, b) => a.ts - b.ts);
    p.replies.forEach((r) => { r.helpful = helpful['r:' + r.key] || 0; });
    p.helpful = helpful['p:' + p.key] || 0;
    p.last = Math.max(p.ts, ...p.replies.map((r) => r.ts));
  });
  return posts;
}
function myForumDoc() {
  const cur = clone(S.forum.get(S.uid) || {});
  ['posts', 'replies', 'helpful'].forEach((k) => { if (!Array.isArray(cur[k])) cur[k] = []; });
  return cur;
}
function canPost(what) {
  if (!S.caps.db) { promptSignIn(what); return false; }
  if (S.session !== 'account' || !S.uid) { promptSignIn(what); return false; }
  if (S.canWrite === false) { toast('You have view-only access, so you can read but not post.', 'alert'); return false; }
  return true;
}
function dbErr(e) {
  const c = e && e.code;
  if (c === 'quota_exceeded') toast('Hookline’s storage is full right now. Try again later.', 'alert');
  else if (c === 'invalid_argument') { S.canWrite = false; toast('Your access is view-only, so this couldn’t be saved.', 'alert'); }
  else toast('Couldn’t save that. Check your connection and try again.', 'alert');
}
function writeForumDoc(uid, mutate) {
  const run = async () => {
    const base = uid === S.uid ? myForumDoc() : clone(S.forum.get(uid) || {});
    ['posts', 'replies', 'helpful'].forEach((k) => { if (!Array.isArray(base[k])) base[k] = []; });
    mutate(base);
    try { await S.caps.db.doc('forum/' + uid).set(base); return true; } catch (e) { dbErr(e); return false; }
  };
  const p = S.forumQ.then(run, run);
  S.forumQ = p.catch(() => false);
  return p;
}
function renderCommunity() {
  if (S.thread) return renderThread();
  view(`<div class="page-head"><div><p class="eyebrow">Community</p><h1>Ask the community</h1><p>Got a text or call that feels off? Ask people who’ve seen it before, and share what you’ve learned to help someone else.</p></div><button class="btn btn-primary btn-lg" type="button" data-act="new-post">${icon('plus')} Ask a question</button></div>
  <div class="comm-layout">
    <nav class="cat-list" id="catList" aria-label="Topics"></nav>
    <div>
      <div class="comm-tools"><div class="search">${icon('search')}<input id="commSearch" type="search" placeholder="Search questions" value="${esc(S.commQuery)}" aria-label="Search questions"></div>
      <div class="chips">${[['latest', 'Latest'], ['helpful', 'Most helpful'], ['open', 'Unanswered']].map(([v, l]) => `<button type="button" class="chip ${S.commSort === v ? 'on' : ''}" data-act="comm-sort" data-v="${v}">${l}</button>`).join('')}</div></div>
      <div id="commBanner"></div>
      <div class="thread-list" id="threadList"></div>
    </div>
  </div>`);
  updateCommunity();
}
function updateCommunity() {
  if (S.route !== 'community') return;
  if (S.thread) { updateThread(); return; }
  const listEl = $('#threadList'); if (!listEl) return;
  const threads = buildThreads();
  const counts = { all: threads.length }; threads.forEach((t) => { counts[t.cat] = (counts[t.cat] || 0) + 1; });
  $('#catList').innerHTML = [{ id: 'all', label: 'All topics' }].concat(D.forumCats).map((c) => `<button type="button" class="${S.commCat === c.id ? 'on' : ''}" data-act="comm-cat" data-v="${c.id}">${esc(c.label)} <span class="n">${counts[c.id] || 0}</span></button>`).join('');
  let banner = '';
  if (!S.capsReady) banner = '';
  else if (!S.caps.db) banner = `<div class="banner warn">${icon('alert')}<span>You need to have an account to read and post in the community. <button class="btn btn-sm btn-ghost" type="button" data-act="connect-account">Connect account</button></span></div>`;
  else if (S.session !== 'account') banner = `<div class="banner">${icon('user')}<span>You can read questions here. You need to have an account to ask or reply. <button class="btn btn-sm btn-ghost" type="button" data-act="connect-account">Connect account</button></span></div>`;
  $('#commBanner').innerHTML = banner;
  if (!S.capsReady || (S.caps.db && !S.forumReady && !S.forumErr)) { listEl.innerHTML = `<p class="muted"><span class="spinner"></span> Loading questions…</p>`; return; }
  const q = S.commQuery.toLowerCase();
  let list = threads.filter((t) => S.commCat === 'all' || t.cat === S.commCat);
  if (q) list = list.filter((t) => (t.title + ' ' + t.body + ' ' + t.replies.map((r) => r.body).join(' ')).toLowerCase().includes(q));
  if (S.commSort === 'open') list = list.filter((t) => !t.replies.length);
  list.sort(S.commSort === 'helpful' ? (a, b) => b.helpful - a.helpful || b.last - a.last : (a, b) => b.last - a.last);
  if (!list.length) {
    listEl.innerHTML = `<div class="panel empty">${icon('chat')}<p><b>${threads.length ? 'No questions match.' : 'No questions yet.'}</b><br>${threads.length ? 'Try another topic or search.' : 'Be the first to ask about a message that felt off.'}</p><button class="btn btn-primary" type="button" data-act="new-post">${icon('plus')} Ask a question</button></div>`;
    return;
  }
  listEl.innerHTML = list.map((t) => `<button class="thread-item" type="button" data-act="open-thread" data-key="${esc(t.key)}"><div class="main"><div class="byline"><img data-uavatar="${esc(t.uid)}" src="${DEFAULT_AVATAR}" alt=""><b data-uname="${esc(t.uid)}">Member</b><span>· ${ago(t.ts)}</span><span class="pill">${esc(catLabel(t.cat))}</span>${t.replies.length ? '<span class="pill pill-safe">Answered</span>' : ''}</div><h3>${esc(t.title)}</h3><p>${esc(t.body)}</p></div><div class="thread-stats"><span>${icon('chat')} ${t.replies.length}</span><span>${icon('thumb')} ${t.helpful}</span></div></button>`).join('');
  hydrateNames(listEl);
}
function renderThread() {
  view(`<div class="thread-view">
    <button class="btn btn-quiet" type="button" data-act="back-community" style="justify-self:start">${icon('arrowL')} All questions</button>
    <div id="threadBody" class="thread-view"></div>
    <div class="composer"><label class="label" for="replyText">Your reply</label><textarea id="replyText" maxlength="1200" placeholder="Share what you know. Don’t post personal details."></textarea>
      <div class="btn-row"><button class="btn btn-primary" type="button" data-act="send-reply">${icon('chat')} Post reply</button><button class="btn btn-ghost ai-only" type="button" data-act="ai-answer">${icon('spark')} Get an AI answer</button></div></div>
    <div id="aiAnswer"></div>
  </div>`);
  updateThread();
}
function updateThread() {
  const el = $('#threadBody'); if (!el) return;
  const t = buildThreads().find((x) => x.key === S.thread);
  if (!t) { el.innerHTML = `<div class="panel empty">${icon('chat')}<p>${S.forumReady ? 'This question was removed.' : 'Loading…'}</p></div>`; return; }
  const mine = myForumDoc().helpful;
  const canRm = (uid) => uid === S.uid || S.isOwner;
  el.innerHTML = `<article class="post">
    <div class="byline"><img data-uavatar="${esc(t.uid)}" src="${DEFAULT_AVATAR}" alt=""><b data-uname="${esc(t.uid)}">Member</b><span>· ${ago(t.ts)}</span><span class="pill">${esc(catLabel(t.cat))}</span></div>
    <h2>${esc(t.title)}</h2><div class="body">${esc(t.body)}</div>
    <div class="post-actions"><button class="btn btn-sm btn-ghost helpful ${mine.includes('p:' + t.key) ? 'on' : ''}" type="button" data-act="helpful" data-key="p:${esc(t.key)}">${icon('thumb')} Helpful · ${t.helpful}</button>${canRm(t.uid) ? `<button class="btn btn-sm btn-quiet" type="button" data-act="remove-post" data-uid="${esc(t.uid)}" data-id="${esc(t.id)}">${icon('trash')} Remove</button>` : ''}</div>
  </article>
  <h3>${t.replies.length} ${t.replies.length === 1 ? 'reply' : 'replies'}</h3>
  <div class="replies">${t.replies.map((r) => `<div class="reply"><div class="byline"><img data-uavatar="${esc(r.uid)}" src="${DEFAULT_AVATAR}" alt=""><b data-uname="${esc(r.uid)}">Member</b><span>· ${ago(r.ts)}</span></div><div class="body">${esc(r.body)}</div><div class="post-actions"><button class="btn btn-sm btn-ghost helpful ${mine.includes('r:' + r.key) ? 'on' : ''}" type="button" data-act="helpful" data-key="r:${esc(r.key)}">${icon('thumb')} Helpful · ${r.helpful}</button>${canRm(r.uid) ? `<button class="btn btn-sm btn-quiet" type="button" data-act="remove-reply" data-uid="${esc(r.uid)}" data-id="${esc(r.id)}">${icon('trash')} Remove</button>` : ''}</div></div>`).join('') || '<p class="muted">No replies yet. Know something about this? Help them out below.</p>'}</div>`;
  hydrateNames(el);
}
function openComposer(prefill = {}) {
  if (!canPost('ask a question')) return;
  openModal(`${modalHead('Ask the community', 'Describe what happened. Members and the AI can help you figure out if it’s a scam.')}
    <div class="modal-body">
      <div class="banner warn">${icon('lock')}<span>Don’t post your full name, phone number, account numbers, or photos of checks or IDs. Replace personal details with [removed].</span></div>
      <div class="field"><label for="npCat">Topic</label><select id="npCat">${D.forumCats.map((c) => `<option value="${c.id}" ${prefill.cat === c.id ? 'selected' : ''}>${esc(c.label)}</option>`).join('')}</select></div>
      <div class="field"><label for="npTitle">Your question</label><input id="npTitle" type="text" maxlength="120" placeholder="e.g. Got a text about an unpaid toll. Is it real?" value="${esc(prefill.title || '')}"></div>
      <div class="field"><label for="npBody">Details</label><textarea id="npBody" maxlength="2000" placeholder="What did the message or caller say? What did they ask you to do?"></textarea></div>
    </div>
    <div class="modal-foot"><button class="btn btn-quiet" type="button" data-act="close-modal">Cancel</button><button class="btn btn-primary" type="button" data-act="submit-post">Post question</button></div>`);
}
async function submitPost(btn) {
  const cat = $('#npCat').value, title = $('#npTitle').value.trim(), body = $('#npBody').value.trim();
  if (title.length < 8) { toast('Write a question of at least a few words.', 'alert'); return; }
  if (body.length < 10) { toast('Add a few details so people can help.', 'alert'); return; }
  if (PII_RE.test(title + ' ' + body)) { toast('That looks like a Social Security or card number. Remove it before posting.', 'alert'); return; }
  btn.disabled = true;
  const id = newId();
  const ok = await writeForumDoc(S.uid, (d) => { d.posts.push({ id, cat, title, body, ts: Date.now() }); d.posts = d.posts.slice(-60); });
  btn.disabled = false;
  if (!ok) return;
  closeModal();
  award(20, 'Asked the community');
  S.thread = S.uid + '~' + id;
  if (S.route !== 'community') navigate('community', { thread: S.thread }); else renderThread();
}
async function sendReply(btn) {
  if (!canPost('reply')) return;
  const ta = $('#replyText'); const body = ta.value.trim();
  if (body.length < 3) { toast('Write a reply first.', 'alert'); return; }
  if (PII_RE.test(body)) { toast('That looks like a Social Security or card number. Remove it before posting.', 'alert'); return; }
  btn.disabled = true;
  const parent = S.thread;
  const ok = await writeForumDoc(S.uid, (d) => { d.replies.push({ id: newId(), parent, body, ts: Date.now() }); d.replies = d.replies.slice(-200); });
  btn.disabled = false;
  if (!ok) return;
  ta.value = '';
  award(10, 'Helped the community');
  grant('helper');
}
async function toggleHelpful(key) {
  if (!canPost('mark answers helpful')) return;
  const owner = key.slice(2).split('~')[0];
  if (owner === S.uid) { toast('You can’t mark your own post as helpful.', 'alert'); return; }
  await writeForumDoc(S.uid, (d) => { toggleList(d.helpful, key); d.helpful = d.helpful.slice(-500); });
}
async function removeForum(kind, uid, id) {
  if (uid !== S.uid && !S.isOwner) return;
  const ok = await writeForumDoc(uid, (d) => {
    if (kind === 'post') d.posts = d.posts.filter((p) => String(p.id) !== id);
    else d.replies = d.replies.filter((r) => String(r.id) !== id);
  });
  if (!ok) return;
  toast(kind === 'post' ? 'Question removed' : 'Reply removed');
  if (kind === 'post' && S.thread === uid + '~' + id) { S.thread = null; renderCommunity(); }
}
async function aiAnswer() {
  if (!aiReady()) return;
  const t = buildThreads().find((x) => x.key === S.thread); if (!t) return;
  const out = $('#aiAnswer'); if (!out) return;
  const ctl = S.aiCtl = new AbortController();
  out.innerHTML = `<div class="reply ai"><div class="byline"><span class="ai-tag">${icon('spark')} Hookline AI</span><button class="btn btn-sm btn-quiet" type="button" data-act="ai-stop">${icon('stop')} Stop</button></div><div class="body" id="aiAnsBody"><span class="spinner"></span> Thinking…</div></div>`;
  const prompt = `A member of a scam-awareness community asked the question below. Write a calm, helpful answer in 120 to 200 words. Say whether it sounds like a scam and why, what they should do next, and point to official resources (ReportFraud.ftc.gov, IdentityTheft.gov, or the number on the back of their card) where relevant. Don't claim more certainty than you have. Plain text, no headings.

Question: ${t.title}
Details: ${t.body.slice(0, 1800)}`;
  try {
    await S.caps.sample(prompt, { signal: ctl.signal, onText: ({ text }) => { const b = $('#aiAnsBody'); if (b) b.textContent = text; } });
    if (S.aiCtl === ctl) S.aiCtl = null;
    const b = $('#aiAnsBody'); if (b) b.insertAdjacentHTML('afterend', '<p class="small muted">Only you see this AI answer. It can make mistakes.</p>');
  } catch (e) {
    if (S.aiCtl === ctl) S.aiCtl = null;
    const b = $('#aiAnsBody'); if (b && !(e && e.text)) b.textContent = aiErr(e) || 'Stopped.';
  }
}

/* ================= Reports ================= */
function openReport(pre = {}) {
  if (!canPost('report a scam')) return;
  const p = S.profile;
  const channels = ['Text message', 'Phone call', 'Email', 'Social media', 'Website or ad', 'In person'];
  openModal(`${modalHead('Report a scam', 'Warn people near you. Reports appear on the Hookline home page for 30 days.')}
    <div class="modal-body">
      <div class="field-row">
        <div class="field"><label for="rpChannel">How did it reach you?</label><select id="rpChannel">${channels.map((c) => `<option ${pre.channel === c ? 'selected' : ''}>${c}</option>`).join('')}</select></div>
        <div class="field"><label for="rpType">Type of scam</label><select id="rpType">${D.scamTypes.map((c) => `<option ${pre.type === c ? 'selected' : ''}>${esc(c)}</option>`).join('')}</select></div>
      </div>
      <div class="field-row">
        <div class="field"><label for="rpState">State</label><select id="rpState">${stateOptions(p.state)}</select></div>
        <div class="field"><label for="rpCity">City or town <span class="muted">(optional)</span></label><input id="rpCity" type="text" maxlength="60" value="${esc(p.city)}"></div>
      </div>
      <div class="field"><label for="rpSender">Number, email, or site it came from <span class="muted">(optional)</span></label><input id="rpSender" type="text" maxlength="80" placeholder="e.g. +1 (209) 555-0182"><span class="hint">Scammers often fake caller ID, so this may not be their real number.</span></div>
      <div class="field"><label for="rpSummary">What happened?</label><textarea id="rpSummary" maxlength="400" placeholder="e.g. A text said I owed $3.95 in tolls and linked to a fake payment site."></textarea><span class="hint">Leave out your own name, account numbers, and other personal details.</span></div>
      <label class="check"><input type="checkbox" id="rpLost"> I lost money</label>
    </div>
    <div class="modal-foot"><button class="btn btn-quiet" type="button" data-act="close-modal">Cancel</button><button class="btn btn-primary" type="button" data-act="submit-report">${icon('flag')} Post report</button></div>`);
}
async function submitReport(btn) {
  const state = $('#rpState').value, summary = $('#rpSummary').value.trim();
  if (!state) { toast('Choose a state so neighbors can see it.', 'alert'); return; }
  if (summary.length < 10) { toast('Describe what happened in a sentence or two.', 'alert'); return; }
  if (PII_RE.test(summary)) { toast('That looks like a Social Security or card number. Remove it first.', 'alert'); return; }
  const item = { id: newId(), channel: $('#rpChannel').value, type: $('#rpType').value, state, city: $('#rpCity').value.trim().slice(0, 60), sender: $('#rpSender').value.trim().slice(0, 80), summary: summary.slice(0, 400), lost: $('#rpLost').checked, ts: Date.now() };
  btn.disabled = true;
  const ok = await writeReports(S.uid, (items) => { items.push(item); return items.slice(-50); });
  btn.disabled = false;
  if (!ok) return;
  closeModal();
  award(25, 'Warned your neighbors');
  grant('watchdog');
}
function writeReports(uid, mutate) {
  const run = async () => {
    const cur = clone(S.reports.get(uid) || {});
    const items = mutate(Array.isArray(cur.items) ? cur.items : []);
    try { await S.caps.db.doc('reports/' + uid).set({ items }); return true; } catch (e) { dbErr(e); return false; }
  };
  const p = S.reportQ.then(run, run);
  S.reportQ = p.catch(() => false);
  return p;
}

/* ================= Profile ================= */
function renderProfile() {
  const p = S.profile; const lv = levelOf(p.xp);
  const acct = S.session === 'account';
  const name = acct ? ((S.me && S.me.name) || 'Your account') : 'Guest';
  const avatar = acct && S.me ? S.me.avatarUrl : DEFAULT_AVATAR;
  const acc = p.quiz.answered ? Math.round(100 * p.quiz.correct / p.quiz.answered) + '%' : '—';
  const savedShorts = D.shorts.filter((s) => p.saved.includes(s.id));
  const savedArts = D.articles.filter((a) => p.savedArticles.includes(a.id));
  view(`<section class="panel profile-head">
    <img src="${esc(avatar)}" alt="">
    <div class="who"><p class="eyebrow">${S.cloud ? 'Account connected · progress syncs automatically' : 'Account not connected · progress saves on this device'}</p><h1>${esc(name)}</h1>
      ${S.cloud ? '' : `<div class="btn-row"><button class="btn btn-primary btn-sm" type="button" data-act="connect-account">${icon('user')} Connect account</button><span class="small muted">Syncs your progress and lets you post in the community.</span></div>`}
      <div class="btn-row"><span class="pill pill-accent">${icon('award')} ${esc(lv.name)}</span><span class="mono small muted">${p.xp} XP${lv.next ? ' · ' + (lv.next - p.xp) + ' to ' + esc(lv.nextName) : ''}</span></div>
      <div class="xpbar"><i style="width:${Math.round(lv.pct * 100)}%"></i></div></div>
  </section>
  <div class="stat-strip section"><div><b>${p.scans.length}</b><span>checks run</span></div><div><b>${acc}</b><span>quiz accuracy</span></div><div><b>${p.readArticles.length}</b><span>articles finished</span></div><div><b>${p.watched.length}</b><span>shorts watched</span></div></div>
  <div class="profile-grid section">
    <div class="stack">
      <section class="panel stack"><div class="section-head"><h2>Badges</h2><span class="mono small muted">${p.badges.length} / ${BADGES.length}</span></div>
        <div class="badges">${BADGES.map((b) => `<div class="badge ${p.badges.includes(b.id) ? '' : 'locked'}"><span class="medal">${icon(b.ic)}</span><b>${esc(b.name)}</b><span>${esc(b.desc)}</span></div>`).join('')}</div></section>
      <section class="panel stack"><h2>Saved for later</h2>
        ${savedShorts.length || savedArts.length || p.aiArticles.length ? `<div class="list-links">
          ${savedShorts.map((s) => `<button class="list-link" type="button" data-act="open-short" data-id="${s.id}">${icon('play')}<div><span class="eyebrow">Short</span><h4>${esc(s.title)}</h4></div>${icon('arrowR', 'go')}</button>`).join('')}
          ${savedArts.map((a) => `<button class="list-link" type="button" data-act="open-article" data-id="${a.id}">${icon('book')}<div><span class="eyebrow">Article</span><h4>${esc(a.title)}</h4></div>${icon('arrowR', 'go')}</button>`).join('')}
          ${p.aiArticles.map((a) => `<button class="list-link" type="button" data-act="open-ai-article" data-id="${esc(a.id)}">${icon('spark')}<div><span class="eyebrow">AI article</span><h4>${esc(a.title)}</h4></div>${icon('arrowR', 'go')}</button>`).join('')}
        </div>` : `<p class="muted">Save shorts and articles and they’ll wait for you here.</p>`}</section>
      <section class="panel stack"><h2>Recent checks</h2><div id="detHistory"></div></section>
    </div>
    <div class="stack">
      <section class="panel stack"><div class="section-head"><h2>Preferences</h2><button class="btn btn-sm btn-ghost" type="button" data-act="edit-prefs">Edit</button></div>
        <div class="stack-sm"><p><span class="muted">Area:</span> ${p.state ? esc((p.city ? p.city + ', ' : '') + stateName(p.state)) : 'Not set'}</p>
        <p><span class="muted">Interests:</span> ${p.interests.length ? esc(p.interests.map((i) => (D.interests.find((x) => x.id === i) || {}).label).filter(Boolean).join(', ')) : 'Not set'}</p></div></section>
      <section class="panel stack"><span class="ai-tag">${icon('key')} Family Shield</span><h2>Family safe word</h2><p class="muted">Agree on a word your family uses to prove it’s really them on the phone. An AI voice clone won’t know it.</p>
        <div class="safe-word" id="safeWord">${p.safeWord ? esc(p.safeWord) : 'Not set yet'}</div>
        <div class="btn-row"><button class="btn btn-primary" type="button" data-act="gen-safe">${icon('refresh')} ${p.safeWord ? 'New word' : 'Generate one'}</button>${p.safeWord ? `<button class="btn btn-ghost" type="button" data-act="copy-safe">${icon('copy')} Copy</button>` : ''}</div>
        <p class="small muted">Share it in person, not by text, and never post it online.</p></section>
      <section class="panel stack"><h2>Help lines</h2>${resourcesHtml()}</section>
    </div>
  </div>`);
  renderHistory();
}
function resourcesHtml() {
  return `<div class="res-list">${D.resources.map((r) => `<div class="res-row"><div><span class="nm">${esc(r.name)}</span><span class="val">${esc(r.value)}</span></div>${r.url ? `<a class="btn btn-sm btn-ghost" href="${r.url}" target="_blank" rel="noopener noreferrer">${icon('ext')} Open</a>` : `<button class="btn btn-sm btn-ghost" type="button" data-act="copy" data-v="${esc(r.copy)}">${icon('copy')} Copy</button>`}</div>`).join('')}</div>`;
}

/* ================= Got scammed? ================= */
const SOS_OPTS = [
  ['card', 'I paid with a credit or debit card'],
  ['bank', 'I sent a bank transfer, wire, Zelle, Venmo, or Cash App payment'],
  ['gift', 'I bought gift cards and shared the numbers'],
  ['crypto', 'I sent cryptocurrency or used a Bitcoin ATM'],
  ['pass', 'I shared a password or a verification code'],
  ['ssn', 'I shared my Social Security number or an ID'],
  ['remote', 'I let someone access my computer or phone'],
  ['click', 'I only clicked a link or replied']
];
function openSOS() {
  openModal(`${modalHead('Got scammed? Let’s act fast.', 'Check everything that happened. You’ll get a step-by-step plan in the right order.')}
    <div class="modal-body">
      <div class="sos-opts" id="sosOpts">${SOS_OPTS.map(([v, l]) => `<label><input type="checkbox" value="${v}"> ${l}</label>`).join('')}</div>
      <div id="sosPlan"></div>
    </div>
    <div class="modal-foot"><button class="btn btn-quiet" type="button" data-act="close-modal">Close</button><button class="btn btn-danger" type="button" data-act="sos-plan">Build my plan</button></div>`, { wide: true });
}
function buildPlan() {
  const sel = new Set($$('#sosOpts input:checked').map((i) => i.value));
  const steps = [['Stop all contact', 'Don’t reply or send more money, and ignore promises of refunds or “recovery” help.']];
  if (sel.has('remote')) steps.push(['Disconnect your device', 'Turn off Wi-Fi or unplug the network cable, uninstall the remote access app, and run a security scan. Use a different device for the next steps.']);
  if (sel.has('bank')) steps.push(['Call your bank or payment app now', 'Ask them to stop or reverse the transfer and flag the recipient. For wires, ask about a recall. Every minute counts.']);
  if (sel.has('card')) steps.push(['Call your card issuer', 'Use the number on the back of your card. Dispute the charge and ask for a new card number.']);
  if (sel.has('gift')) steps.push(['Contact the gift card company', 'Call the number on the back of the card or use the brand’s official site. Report the card numbers and keep your receipts.']);
  if (sel.has('crypto')) steps.push(['Report the crypto transaction', 'Contact the exchange or ATM operator you used, and report it at ic3.gov with wallet addresses and transaction IDs.']);
  if (sel.has('pass')) steps.push(['Lock down your accounts', 'Change that password and anywhere you reused it, starting with email. Turn on two-step verification and sign out other sessions.']);
  if (sel.has('ssn')) steps.push(['Protect your identity', 'Freeze your credit with Equifax, Experian, and TransUnion (it’s free) and get a recovery plan at IdentityTheft.gov.']);
  if (sel.has('click')) steps.push(['Watch for follow-ups', 'If you didn’t enter anything, you’re probably fine. Delete the message and block the sender. If you typed info into a page, change those passwords now.']);
  steps.push(['Report it', 'File at ReportFraud.ftc.gov, and at ic3.gov for online scams. Forward scam texts to 7726. Some banks ask for a police report too.']);
  steps.push(['Tell someone you trust', 'It happens to careful people every day. Talking it through helps you spot follow-up scams.']);
  $('#sosPlan').innerHTML = `<div class="stack"><h3>Your plan</h3><div class="plan">${steps.map(([t, d]) => `<div class="plan-step"><div><b>${esc(t)}</b><span>${esc(d)}</span></div></div>`).join('')}</div><h3>Contacts</h3>${resourcesHtml()}</div>`;
  $('#sosPlan').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

/* ================= Actions ================= */
const ACT = {
  'close-modal': () => closeModal(),
  sos: () => openSOS(),
  'sos-plan': () => buildPlan(),
  copy: (el) => copyText(el.dataset.v),
  'signin-guest': () => continueAsGuest(),
  'connect-account': () => connectFromButton(),
  'toggle-chip': (el) => {
    const wrap = el.parentElement;
    if (wrap.dataset.single) $$('.chip', wrap).forEach((c) => { c.classList.toggle('on', c === el); c.setAttribute('aria-pressed', c === el); });
    else { el.classList.toggle('on'); el.setAttribute('aria-pressed', el.classList.contains('on')); }
  },
  'save-prefs': () => savePrefs(),
  'edit-prefs': () => openPrefs(true),
  report: () => openReport(),
  'submit-report': (el) => submitReport(el),
  'remove-report': async (el) => {
    const uid = el.dataset.uid, id = el.dataset.id;
    if (uid !== S.uid && !S.isOwner) return;
    const ok = await writeReports(uid, (items) => items.filter((r) => String(r.id) !== id));
    if (ok) toast('Report removed');
  },
  'qs-example': () => { const ex = D.examples[Math.floor(Math.random() * 4)]; const ta = $('#qsText'); if (ta) { ta.value = ex.text; ta.focus(); } },
  daily: (el) => {
    const it = dailyItem(); const ok = el.dataset.v === (it.scam ? 'scam' : 'legit');
    S.profile.daily = { day: todayKey(), ok };
    if (ok) award(10, 'Daily challenge'); else saveProfile();
    const sec = $('#dailySec'); if (sec) sec.innerHTML = dailyHtml();
  },
  'open-short': (el) => { S.feedTab = S.profile.saved.includes(el.dataset.id) && S.route === 'profile' ? 'saved' : 'foryou'; S.feedJump = el.dataset.id; navigate('feed'); },
  'open-article': (el) => navigate('learn', { article: el.dataset.id }),
  'det-mode': (el) => { stopListening(); S.detMode = el.dataset.mode; $$('.seg [data-act="det-mode"]').forEach((b) => { const on = b === el; b.classList.toggle('on', on); b.setAttribute('aria-selected', on); }); renderDetInput(); },
  'call-style': (el) => { S.callStyle = el.dataset.v; renderDetInput(); },
  yn: (el) => { S.callAnswers[el.dataset.q] = el.dataset.v; $$(`.yn[data-q="${el.dataset.q}"] button`).forEach((b) => b.classList.toggle('on', b === el)); },
  'det-check': () => runScan(),
  'det-clear': () => { S.callAnswers = {}; S.lastResult = null; S.lastInput = null; renderDetInput(); renderDetResult(); },
  mic: (el) => startDictation(el),
  'live-toggle': () => toggleLive(),
  'deep-scan': () => deepScan(),
  'ai-stop': () => { if (S.aiCtl) { try { S.aiCtl.abort(); } catch (e) { /* ignore */ } } },
  'report-from-scan': () => {
    const r = S.lastResult; if (!r) return;
    const ch = { text: 'Text message', email: 'Email', call: 'Phone call', live: 'Phone call' }[r.mode] || 'Text message';
    const tmap = { 'Toll or ticket text scam': 'Toll or ticket text', 'Package delivery scam': 'Package delivery', 'Tech support scam': 'Tech support', 'Family emergency (grandparent) scam': 'Family emergency / voice clone', 'Job or task scam': 'Job or task scam', 'Investment scam': 'Investment / crypto', 'Wrong-number investment scam': 'Investment / crypto', 'Romance scam': 'Romance', 'Prize or refund scam': 'Prize or sweepstakes', 'Impostor scam': 'Government impostor', 'Phishing attempt': 'Phishing email' };
    openReport({ channel: ch, type: tmap[r.type] || 'Other' });
  },
  'copy-result': () => {
    const r = S.lastResult; if (!r) return;
    copyText(`Hookline check: ${TIERS[r.tier].label} (${r.score}/100 scam risk). ${r.hits.length ? 'Red flags: ' + r.hits.map((h) => h.label).join('; ') + '. ' : ''}${r.advice[0]}`);
  },
  'learn-cat': (el) => { S.learnCat = el.dataset.v; $$('#learnCats .chip').forEach((c) => c.classList.toggle('on', c === el)); renderArtGrid(); },
  'back-learn': () => navigate('learn'),
  'save-article': (el) => { const on = toggleList(S.profile.savedArticles, el.dataset.id); saveProfile(); el.classList.toggle('btn-primary', on); el.classList.toggle('btn-ghost', !on); el.innerHTML = `${icon('bookmark')} ${on ? 'Saved' : 'Save'}`; toast(on ? 'Saved to your profile' : 'Removed from saved'); },
  'finish-article': (el) => {
    const id = el.dataset.id;
    if (!S.profile.readArticles.includes(id)) { S.profile.readArticles.push(id); award(15, 'Article finished'); if (S.profile.readArticles.length >= 5) grant('reader'); }
    renderArticle(id);
  },
  'ai-topic': (el) => aiWrite(el.dataset.v),
  'ai-save': () => {
    const a = S.lastAiArticle; if (!a) return;
    if (!S.profile.aiArticles.some((x) => x.id === a.id)) { S.profile.aiArticles.unshift(a); S.profile.aiArticles = S.profile.aiArticles.slice(0, 8); saveProfile(); }
    const b = $('#aiWriteBtns'); if (b) b.innerHTML = `<span class="pill pill-safe">${icon('check')} Saved</span>`;
    renderMyAi(); toast('Saved to your AI library');
  },
  'open-ai-article': (el) => navigate('learn', { aiArticle: el.dataset.id }),
  'del-ai-article': (el) => { S.profile.aiArticles = S.profile.aiArticles.filter((a) => a.id !== el.dataset.id); saveProfile(); toast('Article deleted'); navigate('learn'); },
  'quiz-start': (el) => { clearQuizTimer(); quizStart(el.dataset.mode); window.scrollTo(0, 0); },
  'quiz-answer': (el) => quizAnswer(el.dataset.v, false),
  'quiz-next': () => quizNext(),
  'quiz-quit': () => { clearQuizTimer(); if (S.aiCtl) { try { S.aiCtl.abort(); } catch (e) { /* ignore */ } } S.qz = null; renderQuiz(); },
  'quiz-home': () => { S.qz = null; renderQuiz(); },
  'feed-tab': (el) => { stopFeed(); S.feedTab = el.dataset.v; renderFeed(); },
  sound: (el) => {
    S.sound = !S.sound; store.set('hl.sound', S.sound);
    el.innerHTML = `${icon(S.sound ? 'vol' : 'mute')} ${S.sound ? 'Narration on' : 'Narration off'}`;
    if (S.sound && P.id && !P.paused) { const s = D.shorts.find((x) => x.id === P.id); if (s) speak(s.scenes[P.i].say); } else hush();
  },
  'short-tap': (el, e) => {
    if (e.target.closest('a')) return;
    const id = el.dataset.id;
    if (P.id !== id) { playShort(id); return; }
    const rect = el.getBoundingClientRect(); const x = (e.clientX - rect.left) / rect.width;
    if (x < 0.28) prevScene(); else if (x > 0.72) nextScene(); else togglePause();
  },
  like: (el) => { const on = toggleList(S.profile.liked, el.dataset.id); el.classList.toggle('on', on); el.setAttribute('aria-pressed', on); saveProfile(); },
  'save-short': (el) => { const on = toggleList(S.profile.saved, el.dataset.id); el.classList.toggle('on', on); el.setAttribute('aria-pressed', on); saveProfile(); toast(on ? 'Saved to your feed' : 'Removed from saved', 'bookmark'); },
  'share-short': (el) => {
    const s = D.shorts.find((x) => x.id === el.dataset.id); if (!s) return;
    const rule = s.scenes.find((x) => x.k === 'rule');
    copyText(`${s.title}: ${rule ? rule.big + ' ' + rule.sub : ''} (Scam tip from Hookline)`);
  },
  'discuss-short': (el) => { const s = D.shorts.find((x) => x.id === el.dataset.id); navigate('community'); openComposer({ title: s ? `About “${s.title}”` : '' }); },
  'new-post': () => openComposer(),
  'submit-post': (el) => submitPost(el),
  'comm-cat': (el) => { S.commCat = el.dataset.v; updateCommunity(); },
  'comm-sort': (el) => { S.commSort = el.dataset.v; $$('[data-act="comm-sort"]').forEach((c) => c.classList.toggle('on', c === el)); updateCommunity(); },
  'open-thread': (el) => { S.thread = el.dataset.key; renderThread(); window.scrollTo(0, 0); },
  'back-community': () => { S.thread = null; if (S.aiCtl) { try { S.aiCtl.abort(); } catch (e) { /* ignore */ } } renderCommunity(); },
  helpful: (el) => toggleHelpful(el.dataset.key),
  'send-reply': (el) => sendReply(el),
  'ai-answer': () => aiAnswer(),
  'remove-post': (el) => removeForum('post', el.dataset.uid, el.dataset.id),
  'remove-reply': (el) => removeForum('reply', el.dataset.uid, el.dataset.id),
  'gen-safe': () => {
    const pick = (a) => a[Math.floor(Math.random() * a.length)];
    S.profile.safeWord = `${pick(D.safeWords.a)}-${pick(D.safeWords.b)}-${Math.floor(10 + Math.random() * 90)}`;
    saveProfile(); grant('safe-word'); renderProfile();
  },
  'copy-safe': () => copyText(S.profile.safeWord),
  'clear-history': (el) => {
    // Two taps, since the viewer frame has no confirm() dialog.
    if (el.dataset.armed !== '1') {
      el.dataset.armed = '1'; el.classList.add('btn-danger'); el.innerHTML = `${icon('trash')} Tap again to clear`;
      setTimeout(() => { if (el.isConnected && el.dataset.armed === '1') { el.dataset.armed = ''; el.classList.remove('btn-danger'); el.innerHTML = `${icon('trash')} Clear history`; } }, 4000);
      return;
    }
    S.profile.scans = []; saveProfile(); renderHistory(); toast('History cleared');
  },
  'ai-brief': () => aiBrief()
};

document.addEventListener('click', (e) => {
  const routeLink = e.target.closest('a[data-route]');
  if (routeLink) { if (routeLink.dataset.route === S.route) { e.preventDefault(); navigate(S.route); } return; }
  const el = e.target.closest('[data-act]');
  if (!el) return;
  const fn = ACT[el.dataset.act];
  if (fn) fn(el, e);
});
document.addEventListener('submit', (e) => {
  e.preventDefault();
  const id = e.target.id;
  if (id === 'quickScan') {
    const text = ($('#qsText').value || '').trim();
    if (text.length < 4) { toast('Paste the message you want to check.', 'alert'); return; }
    const ex = D.examples.find((x) => x.text === text);
    S.detMode = ex ? ex.mode : 'text'; S.callStyle = 'describe';
    S.pendingScan = { text, from: ex ? ex.from : '', subject: ex ? ex.subject || '' : '' };
    navigate('detect');
  } else if (id === 'detForm') runScan();
  else if (id === 'aiWriteForm') aiWrite();
  else if (id === 'followForm') followUp();
  else if (id === 'prefsForm') savePrefs();
});
document.addEventListener('input', (e) => {
  const id = e.target.id;
  if (id === 'detText') updateCount();
  else if (id === 'learnSearch') { S.learnQuery = e.target.value; renderArtGrid(); }
  else if (id === 'commSearch') { S.commQuery = e.target.value; updateCommunity(); }
});
document.addEventListener('change', (e) => {
  if (e.target.id === 'detExample' && e.target.value !== '') {
    const ex = D.examples[Number(e.target.value)];
    if (ex.mode !== S.detMode) { S.detMode = ex.mode; S.callStyle = 'describe'; renderDetect(); }
    $('#detText').value = ex.text;
    if ($('#detFrom')) $('#detFrom').value = ex.from || '';
    if ($('#detSubject')) $('#detSubject').value = ex.subject || '';
    updateCount();
    const sel = $('#detExample'); if (sel) sel.value = '';
  }
});
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') { closeModal(); return; }
  const tag = (e.target.tagName || '').toLowerCase();
  if (['input', 'textarea', 'select'].includes(tag) || !$('#modal').hidden || !$('#auth').hidden) return;
  if (S.route === 'quiz' && S.qz && S.qz.items && !S.qz.done) {
    const answered = !!S.qz.answers[S.qz.i];
    if (!answered && (e.key === 's' || e.key === 'S')) quizAnswer('scam', false);
    else if (!answered && (e.key === 'l' || e.key === 'L')) quizAnswer('legit', false);
    else if (answered && e.key === 'Enter' && tag !== 'button') { e.preventDefault(); quizNext(); }
  } else if (S.route === 'feed' && P.el) {
    if (e.key === ' ') { e.preventDefault(); togglePause(); }
    else if (e.key === 'ArrowRight') nextScene();
    else if (e.key === 'ArrowLeft') prevScene();
  }
});
window.addEventListener('hashchange', () => { const r = hashRoute(); if (r !== S.route) navigate(r); });
window.addEventListener('scroll', () => {
  const p = $('#readProg'); if (!p) return;
  const h = document.documentElement; const max = h.scrollHeight - h.clientHeight;
  p.style.width = (max > 0 ? Math.min(100, (h.scrollTop / max) * 100) : 0) + '%';
}, { passive: true });
document.addEventListener('visibilitychange', () => { if (document.hidden && P.el && !P.paused) togglePause(); });

/* ================= Boot ================= */
function boot() {
  S.profile = normalize(store.get('hl.profile.guest', null));
  S.sound = !!store.get('hl.sound', false);
  S.route = hashRoute();
  // A returning visitor skips the welcome screen; whether progress syncs is decided once the account check finishes.
  S.session = S.session ? 'pending' : null;
  updateHeader();
  render();
  if (!S.session) showAuth();
  initCaps();
}
boot();
})();
