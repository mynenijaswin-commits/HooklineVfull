// Hookline server: accounts, saved progress, the community board, and scam reports.
// No packages to install. Needs Node.js 22.5 or newer. Start it with:  node server.js
'use strict';

const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { promisify } = require('node:util');
const { DatabaseSync } = require('node:sqlite');

const scrypt = promisify(crypto.scrypt);
const PORT = Number(process.env.PORT) || 3000;
const PUBLIC_DIR = path.join(__dirname, 'public');
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const SESSION_DAYS = 30;
const DAY = 86400000;

/* ---------- Database ---------- */
fs.mkdirSync(DATA_DIR, { recursive: true });
const db = new DatabaseSync(path.join(DATA_DIR, 'hookline.db'));
db.exec(`
  PRAGMA journal_mode = WAL;
  PRAGMA foreign_keys = ON;
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY, username TEXT NOT NULL UNIQUE COLLATE NOCASE, display_name TEXT NOT NULL,
    pass_hash TEXT NOT NULL, is_admin INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL);
  CREATE TABLE IF NOT EXISTS sessions (
    token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, expires_at INTEGER NOT NULL);
  CREATE TABLE IF NOT EXISTS profiles (
    user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE, data TEXT NOT NULL, updated_at INTEGER NOT NULL);
  CREATE TABLE IF NOT EXISTS posts (
    id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    cat TEXT NOT NULL, title TEXT NOT NULL, body TEXT NOT NULL, created_at INTEGER NOT NULL);
  CREATE TABLE IF NOT EXISTS replies (
    id INTEGER PRIMARY KEY, post_id INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, body TEXT NOT NULL, created_at INTEGER NOT NULL);
  CREATE TABLE IF NOT EXISTS helpful (
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, target TEXT NOT NULL, PRIMARY KEY (user_id, target));
  CREATE TABLE IF NOT EXISTS reports (
    id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    channel TEXT NOT NULL, type TEXT NOT NULL, state TEXT NOT NULL, city TEXT NOT NULL DEFAULT '',
    sender TEXT NOT NULL DEFAULT '', summary TEXT NOT NULL, lost INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL);
  CREATE INDEX IF NOT EXISTS replies_post ON replies(post_id);
  CREATE INDEX IF NOT EXISTS reports_time ON reports(created_at);
  CREATE TABLE IF NOT EXISTS report_replies (
    id INTEGER PRIMARY KEY, report_id INTEGER NOT NULL REFERENCES reports(id) ON DELETE CASCADE,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, body TEXT NOT NULL, created_at INTEGER NOT NULL);
  CREATE INDEX IF NOT EXISTS report_replies_report ON report_replies(report_id);
`);
db.prepare('DELETE FROM sessions WHERE expires_at < ?').run(Date.now());

/* ---------- Validation ---------- */
const FORUM_CATS = ['calls', 'texts', 'email', 'shopping', 'money', 'help', 'general'];
const CHANNELS = ['Text message', 'Phone call', 'Email', 'Social media', 'Website or ad', 'In person'];
const STATES = 'AL AK AZ AR CA CO CT DE DC FL GA HI ID IL IN IA KS KY LA ME MD MA MI MN MS MO MT NE NV NH NJ NM NY NC ND OH OK OR PA RI SC SD TN TX UT VT VA WA WV WI WY'.split(' ');
const PII_RE = /\b\d{3}-\d{2}-\d{4}\b|\b(?:\d[ -]?){15,16}\b/;
const clean = (v, max) => String(v == null ? '' : v).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '').trim().slice(0, max);

class HttpError extends Error { constructor(status, message) { super(message); this.status = status; } }
const fail = (status, message) => { throw new HttpError(status, message); };

/* ---------- Passwords and sessions ---------- */
async function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const key = await scrypt(password, salt, 64);
  return `scrypt$${salt.toString('hex')}$${key.toString('hex')}`;
}
async function checkPassword(password, stored) {
  const [scheme, saltHex, keyHex] = String(stored).split('$');
  if (scheme !== 'scrypt' || !saltHex || !keyHex) return false;
  const key = await scrypt(password, Buffer.from(saltHex, 'hex'), 64);
  const expected = Buffer.from(keyHex, 'hex');
  return expected.length === key.length && crypto.timingSafeEqual(expected, key);
}
const sha256 = (s) => crypto.createHash('sha256').update(s).digest('hex');
function parseCookies(req) {
  const out = {};
  String(req.headers.cookie || '').split(';').forEach((part) => {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  });
  return out;
}
const isHttps = (req) => req.headers['x-forwarded-proto'] === 'https' || !!req.socket.encrypted;
function sessionCookie(req, token, maxAgeSec) {
  return `hl_session=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${maxAgeSec}${isHttps(req) ? '; Secure' : ''}`;
}
function startSession(req, res, userId) {
  const token = crypto.randomBytes(32).toString('base64url');
  db.prepare('INSERT INTO sessions (token_hash, user_id, expires_at) VALUES (?, ?, ?)').run(sha256(token), userId, Date.now() + SESSION_DAYS * DAY);
  res.setHeader('Set-Cookie', sessionCookie(req, token, SESSION_DAYS * 86400));
}
function currentUser(req) {
  const token = parseCookies(req).hl_session;
  if (!token) return null;
  const row = db.prepare(`SELECT u.id, u.username, u.display_name, u.is_admin, s.expires_at FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = ?`).get(sha256(token));
  if (!row || row.expires_at < Date.now()) return null;
  return row;
}
const publicUser = (u) => ({ id: u.id, username: u.username, name: u.display_name, isAdmin: !!u.is_admin });
function requireUser(req) { const u = currentUser(req); if (!u) fail(401, 'You need to have an account to do this.'); return u; }

/* ---------- Rate limits (in memory) ---------- */
const buckets = new Map();
function limit(key, max, windowMs, message) {
  const now = Date.now();
  const hits = (buckets.get(key) || []).filter((t) => now - t < windowMs);
  if (hits.length >= max) fail(429, message);
  hits.push(now); buckets.set(key, hits);
}
const clientIp = (req) => String(req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim();
// Separate limits per kind of post, so asking a question and then reporting a scam right away both work.
const limitCreate = (user, kind) => {
  limit(`create-burst:${kind}:${user.id}`, 1, 5000, 'Slow down a little, then try again.');
  limit(`create-hour:${kind}:${user.id}`, 30, 3600000, 'Youâ€™ve posted a lot this hour. Try again later.');
};

/* ---------- Live updates (server-sent events) ---------- */
const listeners = new Set();
function broadcast(topic) { for (const res of listeners) res.write(`event: ${topic}\ndata: ${Date.now()}\n\n`); }
setInterval(() => { for (const res of listeners) res.write(': ping\n\n'); }, 25000).unref();

/* ---------- Request helpers ---------- */
function send(res, status, body) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(body));
}
function readJson(req, maxBytes = 300000) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', (c) => { size += c.length; if (size > maxBytes) { reject(new HttpError(413, 'Thatâ€™s too much data.')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      try { const v = JSON.parse(Buffer.concat(chunks).toString('utf8')); resolve(v && typeof v === 'object' ? v : {}); }
      catch (e) { reject(new HttpError(400, 'The request wasnâ€™t valid.')); }
    });
    req.on('error', reject);
  });
}

/* ---------- API ---------- */
function forumPayload(user) {
  const names = new Map(db.prepare('SELECT id, display_name FROM users').all().map((u) => [u.id, u.display_name]));
  const counts = new Map(db.prepare('SELECT target, COUNT(*) AS n FROM helpful GROUP BY target').all().map((r) => [r.target, r.n]));
  const replies = new Map();
  for (const r of db.prepare('SELECT id, post_id, user_id, body, created_at FROM replies ORDER BY created_at').all()) {
    if (!replies.has(r.post_id)) replies.set(r.post_id, []);
    replies.get(r.post_id).push({ id: r.id, body: r.body, ts: r.created_at, author: { id: r.user_id, name: names.get(r.user_id) || 'Member' }, helpful: counts.get('r:' + r.id) || 0 });
  }
  const threads = db.prepare('SELECT id, user_id, cat, title, body, created_at FROM posts ORDER BY created_at DESC LIMIT 500').all().map((p) => ({
    id: p.id, cat: p.cat, title: p.title, body: p.body, ts: p.created_at,
    author: { id: p.user_id, name: names.get(p.user_id) || 'Member' }, helpful: counts.get('p:' + p.id) || 0, replies: replies.get(p.id) || []
  }));
  const mine = user ? db.prepare('SELECT target FROM helpful WHERE user_id = ?').all(user.id).map((r) => r.target) : [];
  return { threads, mine };
}

const routes = {
  'GET /api/me': (req) => { const u = currentUser(req); return { user: u ? publicUser(u) : null }; },

  'POST /api/signup': async (req, res, body) => {
    limit('auth:' + clientIp(req), 20, 900000, 'Too many attempts. Wait 15 minutes and try again.');
    const username = clean(body.username, 40);
    const name = clean(body.name, 40) || username;
    const password = String(body.password || '');
    if (!/^[A-Za-z0-9_]{3,20}$/.test(username)) fail(400, 'Usernames are 3â€“20 letters, numbers, or underscores.');
    if (password.length < 8 || password.length > 128) fail(400, 'Passwords need at least 8 characters.');
    if (password.toLowerCase().includes(username.toLowerCase())) fail(400, 'Donâ€™t put your username in your password.');
    if (db.prepare('SELECT 1 FROM users WHERE username = ?').get(username)) fail(409, 'That username is taken. Try another.');
    const isFirst = !db.prepare('SELECT 1 FROM users LIMIT 1').get();
    const hash = await hashPassword(password);
    const { lastInsertRowid } = db.prepare('INSERT INTO users (username, display_name, pass_hash, is_admin, created_at) VALUES (?, ?, ?, ?, ?)').run(username, name, hash, isFirst ? 1 : 0, Date.now());
    const id = Number(lastInsertRowid);
    if (body.profile && typeof body.profile === 'object') {
      const data = JSON.stringify(body.profile);
      if (data.length <= 200000) db.prepare('INSERT INTO profiles (user_id, data, updated_at) VALUES (?, ?, ?)').run(id, data, Date.now());
    }
    startSession(req, res, id);
    return { user: publicUser(db.prepare('SELECT * FROM users WHERE id = ?').get(id)) };
  },

  'POST /api/login': async (req, res, body) => {
    limit('auth:' + clientIp(req), 20, 900000, 'Too many attempts. Wait 15 minutes and try again.');
    const u = db.prepare('SELECT * FROM users WHERE username = ?').get(clean(body.username, 40));
    // Check a password even for unknown usernames so response time doesn't reveal which usernames exist.
    const ok = await checkPassword(String(body.password || ''), u ? u.pass_hash : 'scrypt$00$00');
    if (!u || !ok) fail(401, 'That username and password donâ€™t match.');
    startSession(req, res, u.id);
    return { user: publicUser(u) };
  },

  'POST /api/logout': (req, res) => {
    const token = parseCookies(req).hl_session;
    if (token) db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(sha256(token));
    res.setHeader('Set-Cookie', sessionCookie(req, '', 0));
    return { ok: true };
  },

  'GET /api/profile': (req) => {
    const u = requireUser(req);
    const row = db.prepare('SELECT data, updated_at FROM profiles WHERE user_id = ?').get(u.id);
    return { profile: row ? JSON.parse(row.data) : null, updatedAt: row ? row.updated_at : 0 };
  },

  'PUT /api/profile': (req, res, body) => {
    const u = requireUser(req);
    if (!body.profile || typeof body.profile !== 'object' || Array.isArray(body.profile)) fail(400, 'Missing profile.');
    const data = JSON.stringify(body.profile);
    if (data.length > 200000) fail(413, 'Your saved data is too large.');
    const now = Date.now();
    db.prepare('INSERT INTO profiles (user_id, data, updated_at) VALUES (?, ?, ?) ON CONFLICT(user_id) DO UPDATE SET data = excluded.data, updated_at = excluded.updated_at').run(u.id, data, now);
    return { ok: true, updatedAt: now };
  },

  'GET /api/forum': (req) => forumPayload(currentUser(req)),

  'POST /api/posts': (req, res, body) => {
    const u = requireUser(req);
    const cat = FORUM_CATS.includes(body.cat) ? body.cat : 'general';
    const title = clean(body.title, 120), text = clean(body.body, 2000);
    if (title.length < 8) fail(400, 'Write a question of at least a few words.');
    if (text.length < 10) fail(400, 'Add a few details so people can help.');
    if (PII_RE.test(title + ' ' + text)) fail(400, 'That looks like a Social Security or card number. Remove it before posting.');
    limitCreate(u, 'post');
    const { lastInsertRowid } = db.prepare('INSERT INTO posts (user_id, cat, title, body, created_at) VALUES (?, ?, ?, ?, ?)').run(u.id, cat, title, text, Date.now());
    broadcast('forum');
    return { id: Number(lastInsertRowid) };
  },

  'POST /api/replies': (req, res, body) => {
    const u = requireUser(req);
    const postId = Number(body.postId), text = clean(body.body, 1200);
    if (!db.prepare('SELECT 1 FROM posts WHERE id = ?').get(postId)) fail(404, 'That question was removed.');
    if (text.length < 3) fail(400, 'Write a reply first.');
    if (PII_RE.test(text)) fail(400, 'That looks like a Social Security or card number. Remove it before posting.');
    limitCreate(u, 'reply');
    const { lastInsertRowid } = db.prepare('INSERT INTO replies (post_id, user_id, body, created_at) VALUES (?, ?, ?, ?)').run(postId, u.id, text, Date.now());
    broadcast('forum');
    return { id: Number(lastInsertRowid) };
  },

  'POST /api/helpful': (req, res, body) => {
    const u = requireUser(req);
    const m = /^(p|r):(\d+)$/.exec(String(body.target || ''));
    if (!m) fail(400, 'Unknown item.');
    const row = db.prepare(m[1] === 'p' ? 'SELECT user_id FROM posts WHERE id = ?' : 'SELECT user_id FROM replies WHERE id = ?').get(Number(m[2]));
    if (!row) fail(404, 'That was removed.');
    if (row.user_id === u.id) fail(400, 'You canâ€™t mark your own post as helpful.');
    const target = m[1] + ':' + m[2];
    const had = db.prepare('SELECT 1 FROM helpful WHERE user_id = ? AND target = ?').get(u.id, target);
    if (had) db.prepare('DELETE FROM helpful WHERE user_id = ? AND target = ?').run(u.id, target);
    else db.prepare('INSERT INTO helpful (user_id, target) VALUES (?, ?)').run(u.id, target);
    broadcast('forum');
    return { on: !had };
  },

  'GET /api/reports': () => {
    const names = new Map(db.prepare('SELECT id, display_name FROM users').all().map((u) => [u.id, u.display_name]));
    const rows = db.prepare('SELECT * FROM reports WHERE created_at >= ? ORDER BY created_at DESC LIMIT 1000').all(Date.now() - 60 * DAY);
    const replies = new Map();
    for (const r of db.prepare('SELECT id, report_id, user_id, body, created_at FROM report_replies ORDER BY created_at').all()) {
      if (!replies.has(r.report_id)) replies.set(r.report_id, []);
      replies.get(r.report_id).push({ id: r.id, uid: r.user_id, author: names.get(r.user_id) || 'Member', body: r.body, ts: r.created_at });
    }
    return { reports: rows.map((r) => ({ id: r.id, uid: r.user_id, author: names.get(r.user_id) || 'Member', channel: r.channel, type: r.type, state: r.state, city: r.city, sender: r.sender, summary: r.summary, lost: !!r.lost, ts: r.created_at, replies: replies.get(r.id) || [] })) };
  },

  'POST /api/report-replies': (req, res, body) => {
    const u = requireUser(req);
    const reportId = Number(body.reportId), text = clean(body.body, 1200);
    if (!db.prepare('SELECT 1 FROM reports WHERE id = ?').get(reportId)) fail(404, 'That report was removed.');
    if (text.length < 3) fail(400, 'Write a reply first.');
    if (PII_RE.test(text)) fail(400, 'That looks like a Social Security or card number. Remove it before posting.');
    limitCreate(u, 'report-reply');
    const { lastInsertRowid } = db.prepare('INSERT INTO report_replies (report_id, user_id, body, created_at) VALUES (?, ?, ?, ?)').run(reportId, u.id, text, Date.now());
    broadcast('reports');
    return { id: Number(lastInsertRowid) };
  },

  'POST /api/reports': (req, res, body) => {
    const u = requireUser(req);
    const state = String(body.state || '');
    const summary = clean(body.summary, 400);
    if (!STATES.includes(state)) fail(400, 'Choose a state so neighbors can see it.');
    if (summary.length < 10) fail(400, 'Describe what happened in a sentence or two.');
    if (PII_RE.test(summary)) fail(400, 'That looks like a Social Security or card number. Remove it first.');
    limitCreate(u, 'report');
    const channel = CHANNELS.includes(body.channel) ? body.channel : 'Text message';
    const { lastInsertRowid } = db.prepare('INSERT INTO reports (user_id, channel, type, state, city, sender, summary, lost, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)')
      .run(u.id, channel, clean(body.type, 40) || 'Other', state, clean(body.city, 60), clean(body.sender, 80), summary, body.lost ? 1 : 0, Date.now());
    broadcast('reports');
    return { id: Number(lastInsertRowid) };
  }
};

// Owners (and the admin, the first account created) can delete posts, replies, and reports.
// URL name -> [table, live-update topic]. Only these tables can ever be named in the DELETE queries below.
const deletable = { posts: ['posts', 'forum'], replies: ['replies', 'forum'], reports: ['reports', 'reports'], 'report-replies': ['report_replies', 'reports'] };
function handleDelete(req, kind, id) {
  const [table, topic] = deletable[kind];
  const u = requireUser(req);
  const row = db.prepare(`SELECT user_id FROM ${table} WHERE id = ?`).get(id);
  if (!row) fail(404, 'That was already removed.');
  if (row.user_id !== u.id && !u.is_admin) fail(403, 'You can only remove your own posts.');
  db.prepare(`DELETE FROM ${table} WHERE id = ?`).run(id);
  if (table === 'posts' || table === 'replies') db.prepare('DELETE FROM helpful WHERE target = ?').run((table === 'posts' ? 'p:' : 'r:') + id);
  broadcast(topic);
  return { ok: true };
}

/* ---------- Static files ---------- */
const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.json': 'application/json', '.webmanifest': 'application/manifest+json' };
function serveStatic(req, res, pathname) {
  const rel = pathname === '/' ? 'index.html' : decodeURIComponent(pathname).replace(/^\/+/, '');
  const file = path.resolve(PUBLIC_DIR, rel);
  if (!file.startsWith(PUBLIC_DIR + path.sep)) { res.writeHead(403); return res.end('Forbidden'); }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404, { 'Content-Type': 'text/plain' }); return res.end('Not found'); }
    res.writeHead(200, { 'Content-Type': TYPES[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    res.end(data);
  });
}

/* ---------- Server ---------- */
const SECURITY_HEADERS = {
  'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'",
  'X-Content-Type-Options': 'nosniff',
  'Referrer-Policy': 'same-origin',
  'X-Frame-Options': 'DENY'
};

const server = http.createServer(async (req, res) => {
  for (const [k, v] of Object.entries(SECURITY_HEADERS)) res.setHeader(k, v);
  const { pathname } = new URL(req.url, 'http://localhost');
  try {
    if (!pathname.startsWith('/api/')) {
      if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); return res.end(); }
      return serveStatic(req, res, pathname);
    }
    if (pathname === '/api/events' && req.method === 'GET') {
      res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-store', Connection: 'keep-alive' });
      res.write(': connected\n\n');
      listeners.add(res);
      req.on('close', () => listeners.delete(res));
      return;
    }
    // Every change must come from the Hookline page itself (blocks cross-site form tricks).
    if (req.method !== 'GET' && req.headers['x-hookline'] !== '1') fail(403, 'Blocked request.');
    const del = /^\/api\/(posts|replies|reports|report-replies)\/(\d+)$/.exec(pathname);
    if (del && req.method === 'DELETE') return send(res, 200, handleDelete(req, del[1], Number(del[2])));
    const handler = routes[req.method + ' ' + pathname];
    if (!handler) fail(404, 'Not found.');
    const body = req.method === 'GET' ? {} : await readJson(req);
    send(res, 200, await handler(req, res, body));
  } catch (e) {
    if (e instanceof HttpError) return send(res, e.status, { error: e.message });
    console.error(e);
    send(res, 500, { error: 'Something went wrong on the server. Try again.' });
  }
});

server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.log(`\n  Hookline is already running at http://localhost:${PORT}\n  (It may be running in the background.) You can close this window.\n`);
    process.exit(0);
  }
  throw err;
});
server.listen(PORT, () => {
  console.log(`\n  Hookline is running at http://localhost:${PORT}\n  Keep this window open. Press Ctrl+C to stop.\n`);
  // start.bat sets OPEN_BROWSER so the page opens only once the server is ready.
  if (process.env.OPEN_BROWSER === '1' && process.platform === 'win32') {
    require('node:child_process').exec(`start "" http://localhost:${PORT}`);
  }
});
